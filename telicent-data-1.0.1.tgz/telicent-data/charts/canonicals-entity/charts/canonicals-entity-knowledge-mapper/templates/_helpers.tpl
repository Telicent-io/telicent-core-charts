{{/*
Expand the name of the chart.
*/}}
{{- define "canonicals-entity-knowledge-mapper.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "canonicals-entity-knowledge-mapper.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "canonicals-entity-knowledge-mapper.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "canonicals-entity-knowledge-mapper.labels" -}}
helm.sh/chart: {{ include "canonicals-entity-knowledge-mapper.chart" . }}
{{ include "canonicals-entity-knowledge-mapper.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
telicent.io/type: mapper
telicent.io/component-of: canonicals-entity
{{- end }}

{{/*
Selector labels
*/}}
{{- define "canonicals-entity-knowledge-mapper.selectorLabels" -}}
app.kubernetes.io/name: {{ include "canonicals-entity-knowledge-mapper.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}


{{- define "canonicals-entity-knowledge-mapper.kafkaAuthConfigSecretName" }}
{{- if .Values.global.kafka.existingConfigSecretName }}
{{- .Values.global.kafka.existingConfigSecretName }}
{{- else }}
{{- include "canonicals-entity-knowledge-mapper.fullname" . }}-kafka-config
{{- end }}
{{- end }}

{{/*
The Kafka topics to create, derived from the mapper's source and target topics.
*/}}
{{- define "canonicals-entity-knowledge-mapper.kafkaTopics" -}}
{{- list .Values.configuration.sourceTopic .Values.configuration.targetTopic | compact -}}
{{- end }}