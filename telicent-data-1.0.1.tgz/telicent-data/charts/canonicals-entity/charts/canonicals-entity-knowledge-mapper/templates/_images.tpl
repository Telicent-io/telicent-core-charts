{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Returns the version
*/}}
{{- define "canonicals-entity-knowledge-mapper.version" -}}
{{- .Values.image.tag | default .Chart.AppVersion }}
{{- end -}}

{{/*
Returns the image registry
*/}}
{{- define "canonicals-entity-knowledge-mapper.imageRegistry" -}}
{{- .Values.image.registry }}
{{- end -}}

{{/*
Returns the image
*/}}
{{- define "canonicals-entity-knowledge-mapper.image" -}}
{{- printf "%s/%s:%s" (include "canonicals-entity-knowledge-mapper.imageRegistry" .) .Values.image.repository (include "canonicals-entity-knowledge-mapper.version" .) }}
{{- end -}}
