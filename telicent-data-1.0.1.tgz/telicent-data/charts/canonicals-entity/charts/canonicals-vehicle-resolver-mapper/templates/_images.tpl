{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Returns the version
*/}}
{{- define "canonicals-vehicle-resolver-mapper.version" -}}
{{- .Values.image.tag | default .Chart.AppVersion }}
{{- end -}}

{{/*
Returns the image registry
*/}}
{{- define "canonicals-vehicle-resolver-mapper.imageRegistry" -}}
{{- .Values.global.imageRegistry | default .Values.image.registry }}
{{- end -}}

{{/*
Returns the image
*/}}
{{- define "canonicals-vehicle-resolver-mapper.image" -}}
{{- printf "%s/%s:%s" (include "canonicals-vehicle-resolver-mapper.imageRegistry" .) .Values.image.repository (include "canonicals-vehicle-resolver-mapper.version" .) }}
{{- end -}}
