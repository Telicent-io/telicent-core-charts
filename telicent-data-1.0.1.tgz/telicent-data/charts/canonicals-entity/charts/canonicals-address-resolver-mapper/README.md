# Canonicals Address Resolver

## Parameters

### Global Parameters

Contains global parameters. Not explicitly used in this chart, added to maintain consistency across Telicent charts.
These parameters can be referenced in sub-charts as `.Values.global.<parameter-name>`.

| Name                             | Description                                                                   | Value                                            |
| -------------------------------- | ----------------------------------------------------------------------------- | ------------------------------------------------ |
| `global.imageRegistry`           | Global image registry                                                         | `""`                                             |
| `global.imagePullSecrets`        | Global registry secret names as an array                                      | `[]`                                             |
| `global.enterprise`              | Enable enterprise mode, adding additional features and configurations         | `false`                                          |
| `global.groupsClaim`             | Key used to retrieve groups from the OIDC provider                            | `groups`                                         |
| `global.jwksUrl`                 | Endpoint exposing multiple public keys represented as JWKs (JSON Web Key Set) | `https://{yourAuthdomain}/.well-known/jwks.json` |
| `global.istioNamespace`          | Namespace in which Istio is deployed                                          | `istio-system`                                   |
| `global.istioServiceAccountName` | Name of the Istio service account                                             | `istio-ingress`                                  |
| `global.istioGatewayName`        | Name of the Istio Gateway Resource (LB operating at the edge of the mesh)     | `ingress-gateway`                                |

### Kafka Parameters

| Name                                    | Description                                                                                                       | Value                                          |
| --------------------------------------- | ----------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| `global.kafka.bootstrapServers`         | Comma separated list containing Kafka bootstrap servers                                                           | `kafka-bootstrap.kafka.svc.cluster.local:9092` |
| `global.kafka.existingConfigSecretName` | Name of an existing secret containing Kafka configuration (preferred over individual settings below for security) | `""`                                           |
| `global.kafka.username`                 | Username for Kafka authentication                                                                                 | `""`                                           |
| `global.kafka.password`                 | Password for Kafka authentication                                                                                 | `""`                                           |
| `global.kafka.protocol`                 | Protocol used for Kafka communication                                                                             | `SASL_SSL`                                     |
| `global.kafka.mechanism`                | SASL mechanism used for Kafka authentication                                                                      | `SCRAM-SHA-512`                                |
| `global.existingTruststoreSecretName`   | Name of an existing secret containing the truststore                                                              | `""`                                           |
| `global.truststore.mountPath`           | The mount path for the truststore in the container                                                                | `/app/config/truststore`                       |

### Deployment Parameters

| Name           | Description                  | Value |
| -------------- | ---------------------------- | ----- |
| `replicaCount` | Number of replicas to deploy | `1`   |

### Image Parameters

| Name                | Description                                                              | Value                                          |
| ------------------- | ------------------------------------------------------------------------ | ---------------------------------------------- |
| `image.registry`    | Container image registry                                                 | `098669589541.dkr.ecr.eu-west-2.amazonaws.com` |
| `image.repository`  | Container image name                                                     | `canonicals-address-resolver`                  |
| `image.tag`         | Container image tag. If not set, a tag is generated using the appVersion | `""`                                           |
| `image.pullPolicy`  | Container image pull policy                                              | `IfNotPresent`                                 |
| `image.pullSecrets` | Specify registry secret names as an array                                | `[]`                                           |

### Common Parameters

| Name               | Description                                                            | Value |
| ------------------ | ---------------------------------------------------------------------- | ----- |
| `imagePullSecrets` | Global Docker registry secret names as an array                        | `[]`  |
| `nameOverride`     | String to partially override fullname (will maintain the release name) | `""`  |
| `fullnameOverride` | String to fully override the generated release name                    | `""`  |

### Service Account Parameters

| Name                         | Description                                                                                                       | Value  |
| ---------------------------- | ----------------------------------------------------------------------------------------------------------------- | ------ |
| `serviceAccount.create`      | Specifies whether a service account should be created                                                             | `true` |
| `serviceAccount.automount`   | Automatically mount a ServiceAccount's API credentials?                                                           | `true` |
| `serviceAccount.annotations` | Additional custom annotations for the ServiceAccount                                                              | `{}`   |
| `serviceAccount.name`        | Name of the ServiceAccount to use. If not set and create is true, a name is generated using the fullname template | `""`   |

### Pod Parameters

| Name                 | Description                            | Value |
| -------------------- | -------------------------------------- | ----- |
| `podAnnotations`     | Additional custom annotations for pods | `{}`  |
| `podLabels`          | Additional custom labels for pods      | `{}`  |
| `podSecurityContext` | Set pods' Security Context             | `{}`  |
| `securityContext`    | Set containers' Security Context       | `{}`  |

### Traffic Exposure Parameters

| Name           | Description  | Value       |
| -------------- | ------------ | ----------- |
| `service.type` | Service type | `ClusterIP` |
| `service.port` | Service port | `8000`      |

### Resource Parameters

| Name        | Description                                  | Value |
| ----------- | -------------------------------------------- | ----- |
| `resources` | Set containers' resource requests and limits | `{}`  |

### Autoscaling Parameters

| Name                                         | Description                       | Value   |
| -------------------------------------------- | --------------------------------- | ------- |
| `autoscaling.enabled`                        | Enable Horizontal Pod Autoscaler  | `false` |
| `autoscaling.minReplicas`                    | Minimum number of replicas        | `1`     |
| `autoscaling.maxReplicas`                    | Maximum number of replicas        | `100`   |
| `autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization percentage | `80`    |

### Volume Parameters

| Name           | Description                                                 | Value |
| -------------- | ----------------------------------------------------------- | ----- |
| `volumes`      | Additional volumes on the output Deployment definition      | `[]`  |
| `volumeMounts` | Additional volumeMounts on the output Deployment definition | `[]`  |

### Node Selection Parameters

| Name           | Description                     | Value |
| -------------- | ------------------------------- | ----- |
| `nodeSelector` | Node labels for pods assignment | `{}`  |
| `tolerations`  | Tolerations for pods assignment | `[]`  |
| `affinity`     | Affinity for pods assignment    | `{}`  |

### Reference Data Parameters

The resolver needs two artefacts at runtime: the reference CSV
(uprn,address,postcode,latitude,longitude) and the pre-built index folder produced by
scripts/prepare_reference.py. The image ships both at /app/data/reference
and the configuration defaults point there. To use a different reference
set, fill a volume once (e.g. a one-off Job running prepare_reference.py),
set existingClaimName, and point configuration.canonicalCsvPath and
configuration.preparedDirPath at the mount.

| Name                              | Description                                                                                                               | Value             |
| --------------------------------- | ------------------------------------------------------------------------------------------------------------------------- | ----------------- |
| `referenceData.existingClaimName` | Name of an existing PersistentVolumeClaim holding the reference CSV and prepared index folder; mounted read-only when set | `""`              |
| `referenceData.mountPath`         | Where the reference-data volume is mounted in the container                                                               | `/data/reference` |

### Configuration Parameters

Contains configuration parameters specific to the application

| Name                             | Description                                                                             | Value                               |
| -------------------------------- | --------------------------------------------------------------------------------------- | ----------------------------------- |
| `configuration.kafkaConfigMode`  | Kafka configuration mode (toml, json, properties)                                       | `toml`                              |
| `configuration.canonicalCsvPath` | Path (inside the container) of the reference CSV; sets AR_CANONICAL_CSV                 | `/app/data/reference/canonical.csv` |
| `configuration.preparedDirPath`  | Path (inside the container) of the pre-built index folder; sets AR_PREPARED_DIR         | `/app/data/reference/prepared`      |
| `configuration.uriBase`          | Base for minted address/resolution URIs; sets AR_URI_BASE (empty uses the code default) | `""`                                |
