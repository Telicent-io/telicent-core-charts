{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Create the name of the environment variables config map
*/}}
{{- define "auth.envConfigMapName" -}}
{{- if .Values.configMap.existingEnvConfigMap }}
{{- .Values.configMap.existingEnvConfigMap }}
{{- else }}
{{- printf "tc-%s-%s" .Chart.Name "env" }}
{{- end }}
{{- end }}

{{/*
Create the name of the startup/seed clients config map
*/}}
{{- define "auth.clientsConfigMapName" -}}
{{- if .Values.bootstrap.clients.existingConfigMap }}
{{- .Values.bootstrap.clients.existingConfigMap }}
{{- else }}
{{- printf "tc-%s-%s" .Chart.Name "clients" }}
{{- end }}
{{- end }}

{{/*
Create the name of the startup/seed groups config map
*/}}
{{- define "auth.groupsConfigMapName" -}}
{{- if .Values.bootstrap.groups.existingConfigMap }}
{{- .Values.bootstrap.groups.existingConfigMap }}
{{- else }}
{{- printf "tc-%s-%s" .Chart.Name "groups" }}
{{- end }}
{{- end }}

{{/*
Create the name of the startup/seed service accounts config map
*/}}
{{- define "auth.serviceAccountsConfigMapName" -}}
{{- printf "tc-%s-%s" .Chart.Name "service-accounts" }}
{{- end }}

{{/*
Create the name of the startup/seed organisations config map
*/}}
{{- define "auth.organisationsConfigMapName" -}}
{{- if .Values.bootstrap.organisations.existingConfigMap }}
{{- .Values.bootstrap.organisations.existingConfigMap }}
{{- else }}
{{- printf "tc-%s-%s" .Chart.Name "organisations" }}
{{- end }}
{{- end }}
