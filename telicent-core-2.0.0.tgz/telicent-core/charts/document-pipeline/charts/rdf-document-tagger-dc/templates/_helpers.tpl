{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "rdf-document-tagger.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Allow the release namespace to be overridden.
*/}}
{{- define "rdf-document-tagger.namespace" -}}
{{- if .Values.namespaceOverride -}}
{{- .Values.namespaceOverride -}}
{{- else -}}
{{- .Release.Namespace -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "rdf-document-tagger.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "rdf-document-tagger.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "rdf-document-tagger.labels" -}}
helm.sh/chart: {{ include "rdf-document-tagger.chart" . }}
telicent.io/resource: "true"
{{ include "rdf-document-tagger.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "rdf-document-tagger.selectorLabels" -}}
app.kubernetes.io/name: {{ include "rdf-document-tagger.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "rdf-document-tagger.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "rdf-document-tagger.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
********************
*** DC Tagger ***
********************
*/}}

{{/*
Fullname
*/}}
{{- define "dc-tagger.fullname" -}}
{{ printf "%s-%s" (include "rdf-document-tagger.fullname" .) "dc-tagger" }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "dc-tagger.selectorLabels" -}}
app.kubernetes.io/name: {{ include "rdf-document-tagger.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: dc-tagger
{{- end }}

{{/*
Common labels
*/}}
{{- define "dc-tagger.labels" -}}
app.kubernetes.io/component: dc-tagger
app: dc-tagger
{{ include "rdf-document-tagger.labels" . }}
{{- end }}
