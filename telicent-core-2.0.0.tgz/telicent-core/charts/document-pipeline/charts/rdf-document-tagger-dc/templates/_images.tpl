{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Returns the version
*/}}
{{- define "rdf-document-tagger.version" -}}
{{ .Values.image.tag | default .Chart.AppVersion  }}
{{- end -}}

{{/*
Returns the image registry
*/}}
{{- define "rdf-document-tagger.imageRegistry" -}}
{{- .Values.global.imageRegistry | default .Values.image.registry }}
{{- end -}}

{{/*
Returns the image
*/}}
{{- define "rdf-document-tagger.image" -}}
{{- printf "%s/%s:%s" (include "rdf-document-tagger.imageRegistry" .) .Values.image.repository  (include "rdf-document-tagger.version" .) }}
{{- end -}}
