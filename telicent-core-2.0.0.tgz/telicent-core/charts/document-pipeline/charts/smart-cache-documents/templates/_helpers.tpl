{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "smart-cache-documents.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Allow the release namespace to be overridden.
*/}}
{{- define "smart-cache-documents.namespace" -}}
{{- if .Values.namespaceOverride -}}
{{- .Values.namespaceOverride -}}
{{- else -}}
{{- .Release.Namespace -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "smart-cache-documents.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "smart-cache-documents.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "smart-cache-documents.labels" -}}
helm.sh/chart: {{ include "smart-cache-documents.chart" . }}
telicent.io/resource: "true"
{{ include "smart-cache-documents.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "smart-cache-documents.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "smart-cache-documents.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "smart-cache-documents.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
*********************
*** HTTP Ingestor ***
*********************
*/}}

{{/*
Fullname
*/}}

{{- define "http-ingester.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "http-ingester"}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "http-ingester.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: http-ingester
{{- end }}

{{/*
Common labels
*/}}
{{- define "http-ingester.labels" -}}
app.kubernetes.io/component: http-ingester
app: http-ingester
{{ include "smart-cache-documents.labels" . }}
{{- end }}

{{/*
*************************
*** Content Extractor ***
*************************
*/}}

{{/*
Fullname
*/}}

{{- define "content-extractor.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "content-extractor"}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "content-extractor.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: content-extractor
{{- end }}

{{/*
Common labels
*/}}
{{- define "content-extractor.labels" -}}
app.kubernetes.io/component: content-extractor
app: content-extractor
{{ include "smart-cache-documents.labels" . }}
{{- end }}

{{/*
***********************
*** Content Indexer ***
***********************
*/}}

{{/*
Fullname
*/}}

{{- define "content-indexer.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "content-indexer"}}
{{- end }}

{{- define "content-indexer.name" -}}
{{ printf "%s-%s" (include "smart-cache-documents.name" .) "content-indexer"}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "content-indexer.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: content-indexer
{{- end }}

{{/*
Common labels
*/}}
{{- define "content-indexer.labels" -}}
app.kubernetes.io/component: content-indexer
app: content-indexer
{{ include "smart-cache-documents.labels" . }}
{{- end }}

{{/*
*************************
*** Catalogue Updater ***
*************************
*/}}

{{/*
Fullname
*/}}

{{- define "catalogue-updater.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "catalogue-updater"}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "catalogue-updater.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: catalogue-updater
{{- end }}

{{/*
Common labels
*/}}
{{- define "catalogue-updater.labels" -}}
app.kubernetes.io/component: catalogue-updater
app: catalogue-updater
{{ include "smart-cache-documents.labels" . }}
{{- end }}

{{/*
**********************
*** Content Tagger ***
**********************
*/}}

{{/*
Fullname
*/}}
{{- define "content-tagger.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "content-tagger "}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "content-tagger.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: content-tagger
{{- end }}

{{/*
Common labels
*/}}
{{- define "content-tagger.labels" -}}
app.kubernetes.io/component: content-tagger
app: content-tagger
{{ include "smart-cache-documents.labels" . }}
{{- end }}

{{/*
************************
*** Entity Extractor ***
************************
*/}}

{{/*
Fullname
*/}}
{{- define "entity-extractor.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "entity-extractor" }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "entity-extractor.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: entity-extractor
{{- end }}

{{/*
Common labels
*/}}
{{- define "entity-extractor.labels" -}}
app.kubernetes.io/component: entity-extractor
app: entity-extractor
{{ include "smart-cache-documents.labels" . }}
{{- end }}
