{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "pipeline-entity-extraction.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Allow the release namespace to be overridden.
*/}}
{{- define "pipeline-entity-extraction.namespace" -}}
{{- if .Values.namespaceOverride -}}
{{- .Values.namespaceOverride -}}
{{- else -}}
{{- .Release.Namespace -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "pipeline-entity-extraction.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "pipeline-entity-extraction.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "pipeline-entity-extraction.labels" -}}
helm.sh/chart: {{ include "pipeline-entity-extraction.chart" . }}
telicent.io/resource: "true"
{{ include "pipeline-entity-extraction.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "pipeline-entity-extraction.selectorLabels" -}}
app.kubernetes.io/name: {{ include "pipeline-entity-extraction.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "pipeline-entity-extraction.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "pipeline-entity-extraction.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
************************
*** Entity Extractor ***
************************
*/}}

{{/*
Fullname
*/}}
{{- define "entity-extractor.fullname" -}}
{{ printf "%s-%s" (include "pipeline-entity-extraction.fullname" .) "entity-extractor" }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "entity-extractor.selectorLabels" -}}
app.kubernetes.io/name: {{ include "pipeline-entity-extraction.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: entity-extractor
{{- end }}

{{/*
Common labels
*/}}
{{- define "entity-extractor.labels" -}}
app.kubernetes.io/component: entity-extractor
app: entity-extractor
{{ include "pipeline-entity-extraction.labels" . }}
{{- end }}
