{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Returns the version
*/}}
{{- define "pipeline-entity-extraction.version" -}}
{{ .Values.image.tag | default .Chart.AppVersion  }}
{{- end -}}

{{/*
Returns the image registry
*/}}
{{- define "pipeline-entity-extraction.imageRegistry" -}}
{{- .Values.global.imageRegistry | default .Values.image.registry }}
{{- end -}}

{{/*
Returns the image
*/}}
{{- define "pipeline-entity-extraction.image" -}}
{{- printf "%s/%s:%s" (include "pipeline-entity-extraction.imageRegistry" .) .Values.image.repository  (include "pipeline-entity-extraction.version" .) }}
{{- end -}}
