{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "search.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Allow the release namespace to be overridden.
*/}}
{{- define "search.namespace" -}}
{{- if .Values.namespaceOverride -}}
{{- .Values.namespaceOverride -}}
{{- else -}}
{{- .Release.Namespace -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "search.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "search.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "search.selectorLabels" -}}
app.kubernetes.io/name: {{ include "search.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "search.labels" -}}
helm.sh/chart: {{ include "search.chart" . }}
{{ include "search.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ include "search.version" . | quote }}
app: {{ include "search.name" . }}
telicent.io/resource: "true"
{{- range $key, $value := .Values.commonLabels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use (based on the fullname).
*/}}
{{- define "search.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "search.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- .Values.serviceAccount.name | default "default" }}
{{- end }}
{{- end }}

{{/*
Name of the PersistentVolumeClaim holding the Distribution Lifecycle state file (based on the fullname).
This claim is unique to this release and MUST NOT be shared with the *Search Projector*, or any other service, as the
lifecycle state file cannot be written by more than one process.
*/}}
{{- define "search.lifecycleStateClaimName" -}}
{{- if .Values.distributionLifecycle.persistence.existingClaim }}
{{- .Values.distributionLifecycle.persistence.existingClaim }}
{{- else }}
{{- printf "%s-lifecycle-state" (include "search.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Absolute path of the Distribution Lifecycle state file, which lives on the persistent volume.
*/}}
{{- define "search.lifecycleStateFile" -}}
{{- printf "%s/%s" (trimSuffix "/" .Values.distributionLifecycle.persistence.mountPath) .Values.distributionLifecycle.stateFileName }}
{{- end }}

{{/*
Guards against configurations that would allow more than one process to write the lifecycle state file.
*/}}
{{- define "search.validateDistributionLifecycle" -}}
{{- if .Values.distributionLifecycle.routeToNamedGraphs }}
{{- if gt (int .Values.replicas) 1 }}
{{- fail "distributionLifecycle.routeToNamedGraphs requires replicas to be 1; the Distribution Lifecycle state file cannot be shared between processes" }}
{{- end }}
{{- if not .Values.distributionLifecycle.stateFileName }}
{{- fail "distributionLifecycle.stateFileName must be set when distributionLifecycle.routeToNamedGraphs is enabled" }}
{{- end }}
{{- if not .Values.distributionLifecycle.persistence.mountPath }}
{{- fail "distributionLifecycle.persistence.mountPath must be set when distributionLifecycle.routeToNamedGraphs is enabled" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create the name of the service to use (based on the fullname).
*/}}
{{- define "search.serviceName" -}}
{{- if .Values.service.name }}
{{- .Values.service.name -}}
{{- else }}
{{- include "search.fullname" . }}
{{- end }}
{{- end }}
