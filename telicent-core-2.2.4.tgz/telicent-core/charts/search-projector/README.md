# Telicent Package for Search Projector

The **Projector** is responsible for ingesting and indexing data into the search engine, ensuring that Search has up-to-date information to serve queries.

## Introduction

This chart bootstraps Telicent Search Projector deployment on a [Kubernetes](https://kubernetes.io) cluster using
the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.23+
- Helm 3.9+

## Installing the Chart

To install the chart with the release name `my-release`:

```console
helm install my-release ./charts/telicent-core/charts/search-projector
```

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```console
helm delete my-release
```
The command removes all the Kubernetes components associated with the chart and deletes the release.

## Automating README and schema generation

To obtain the latest version of the generator script run:
```shell
.dev/metadata-updater.sh
```
Then run the following from the project root directory:
```bash
.dev/readme-generator-for-helm --config=charts/search-projector/readme.config \
 --values=charts/search-projector/values.yaml \
 --readme=charts/search-projector/README.md \
 --schema=charts/search-projector/values.schema.json
```

## Configuration and installation details

### Resource requests and limits

These are inside the `resources` value (check parameter table). Setting requests is essential for production workloads
and these should be adapted to your specific use case.

### Sidecars and Init Containers

If you have a need for additional containers to run within the same pod (e.g. an additional metrics or logging
exporter), you can do so via the `sidecars` config parameter.
Define your container according to the Kubernetes container spec.

```yaml
sidecars:
- name: your-image-name
  image: your-image
  imagePullPolicy: Always
  ports:
  - name: portname
    containerPort: 1234
```

Similarly, you can add extra init containers using the `initContainers` parameter.

```yaml
initContainers:
- name: your-image-name
  image: your-image
  imagePullPolicy: Always
  ports:
  - name: portname
    containerPort: 1234
```

### Setting Pod's affinity

This chart allows you to set your custom affinity using the `affinity` parameter.
Find more information about Pod's affinity in
the [kubernetes documentation](https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity).

### Distribution Lifecycle Management

Distribution Lifecycle Management is turned on with a single flag:

```yaml
distributionLifecycle:
  routeToNamedGraphs: true
```

This sets `ROUTE_TO_NAMED_GRAPHS=true`, `DISTRIBUTION_LIFECYCLE_ENABLED=true` and points
`DISTRIBUTION_LIFECYCLE_STATE_FILE` at a file on a persistent volume, provisioned by this chart as a
`PersistentVolumeClaim` named `<fullname>-lifecycle-state`. Provide your own volume instead with
`distributionLifecycle.persistence.existingClaim`.

The lifecycle state file only supports a single writer, which has two consequences:

- The **Search** and **Search Projector** charts must each be given their own volume. The claims created by the two
  charts are named after their respective releases so they are distinct by default; if you set `existingClaim`, make
  sure you do not point both services at the same claim.
- Because the state store code is not designed to handle multiple processes sharing the same state file, only one 
  replica is supported while the feature is enabled. The chart fails to render if `replicas` is greater
  than 1, and switches the deployment strategy to `Recreate` so that the outgoing pod releases the state file before
  the incoming pod starts.

## Parameters

### Global Parameters

Contains global parameters; these parameters are mirrored within the Telicent core umbrella chart.
Note: Only global parameters used within this chart will be listed below.

| Name                                    | Description                                               | Value                                          |
| --------------------------------------- | --------------------------------------------------------- | ---------------------------------------------- |
| `global.imageRegistry`                  | Global image registry                                     | `""`                                           |
| `global.imagePullSecrets`               | Global registry secret names as an array                  | `[]`                                           |
| `global.kafka.bootstrapServers`         | Comma separated list containing Kafka bootstrap servers   | `kafka-bootstrap.kafka.svc.cluster.local:9092` |
| `global.kafka.existingConfigSecretName` | Name of an existing secret containing Kafka configuration | `""`                                           |
| `global.kafka.username`                 | Username for Kafka authentication                         | `your.kafka.username.here`                     |
| `global.kafka.password`                 | Password for Kafka authentication                         | `your.kafka.password.here`                     |
| `global.kafka.protocol`                 | Protocol used for Kafka communication                     | `SASL_SSL`                                     |
| `global.kafka.mechanism`                | SASL mechanism used for Kafka authentication              | `SCRAM-SHA-512`                                |
| `global.truststore.existingSecret`      | Name of an existing secret containing the truststore      | `""`                                           |
| `global.truststore.mountPath`           | The mount path for the truststore in the container        | `/app/config/truststore`                       |

### Application Parameters - Java

Contains Java configuration parameters to be used by the *Search Projector* application

| Name                  | Description                                                                | Value                                                                                                                                                                                                                                  |
| --------------------- | -------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `java.jvmOptions`     | JVM options for the application                                            | `-XX:InitialRAMPercentage=20 -XX:MaxRAMPercentage=80 -XX:MinHeapFreeRatio=20 -XX:MaxHeapFreeRatio=40 -XX:-ShrinkHeapInSteps -XX:InitialCodeCacheSize=8m -XX:ReservedCodeCacheSize=64m -XX:MetaspaceSize=32m -XX:MaxMetaspaceSize=128m` |
| `java.mallocArenaMax` | glibc malloc arena cap used to limit native memory fragmentation/retention | `2`                                                                                                                                                                                                                                    |

### Application Parameters - Elastic/OpenSearch and Secret

The following contains connection details to an Elastic/OpenSearch service, on which the application relies.
It is recommended to store sensitive information including passwords in a Kubernetes secret and not in Helm values.
For Quick Start purposes, a secret named `tc-auth-usr-elastic-search-projector` will be created if one is not set.

| Name                              | Description                                                                                             | Value                          |
| --------------------------------- | ------------------------------------------------------------------------------------------------------- | ------------------------------ |
| `elastic.host`                    | Elastic/OpenSearch host                                                                                 | `https://your.opensearch.host` |
| `elastic.port`                    | Elastic/OpenSearch cluster port                                                                         | `443`                          |
| `elastic.opensearchCompatibility` | Enable OpenSearch compatibility                                                                         | `true`                         |
| `elastic.index`                   | Elastic/OpenSearch index to be used                                                                     | `search`                       |
| `elastic.labelsIndex`             | Elastic/OpenSearch index to store security labels.                                                      | `labels`                       |
| `elastic.topic`                   | Topic to consume messages from                                                                          | `knowledge`                    |
| `elastic.dlqTopic`                | Dead-letter topic for failed messages                                                                   | `knowledge.dlq`                |
| `elastic.actionsTopic`            | Topic used to synchronise actions between the *Search Projector* and the *Search API* applications.     | `actions`                      |
| `elastic.indexBatchSize`          | Number of documents to index in a single batch operation                                                | `500`                          |
| `elastic.entityProjection`        | Name of the entity projection to be used, leave blank for default which is suitable for most use cases. | `""`                           |
| `elastic.existingSecret`          | Name of an existing secret. The secret must contain 2 keys: 'username', 'password'                      | `""`                           |
| `elastic.username`                | OpenSearch/Elastic username                                                                             | `""`                           |
| `elastic.password`                | OpenSearch/Elastic user password                                                                        | `""`                           |

### Application Parameters - Distribution Lifecycle Management

Distribution Lifecycle Management routes ingested data into named graphs keyed by the distribution URI and reacts to
distribution lifecycle events, for example removing every indexed document belonging to a deleted distribution.
It is disabled by default; the surrounding ecosystem that emits distribution lifecycle events must be in place
before enabling it.
When enabled the application persists its lifecycle tracking state to a file, which requires a persistent volume.
The state file is not designed to be shared between processes, so the *Search Projector* and the *Search API* MUST
each be given their own volume. For the same reason only a single replica is supported while this feature is enabled.

| Name                                              | Description                                                                                                             | Value                         |
| ------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- | ----------------------------- |
| `distributionLifecycle.routeToNamedGraphs`        | Enable Distribution Lifecycle Management                                                                                | `false`                       |
| `distributionLifecycle.stateFileName`             | Name of the file used to persist lifecycle tracking state, created within 'distributionLifecycle.persistence.mountPath' | `distribution-lifecycle.json` |
| `distributionLifecycle.persistence.existingClaim` | Name of an existing PersistentVolumeClaim used to store the lifecycle state file                                        | `""`                          |
| `distributionLifecycle.persistence.storageClass`  | Storage class of the created PersistentVolumeClaim. Left unset, the cluster default is used                             | `""`                          |
| `distributionLifecycle.persistence.accessModes`   | Access modes of the created PersistentVolumeClaim                                                                       | `["ReadWriteOnce"]`           |
| `distributionLifecycle.persistence.size`          | Size of the created PersistentVolumeClaim                                                                               | `128Mi`                       |
| `distributionLifecycle.persistence.mountPath`     | Path at which the lifecycle state volume is mounted in the container                                                    | `/app/state`                  |
| `distributionLifecycle.persistence.annotations`   | Additional custom annotations for the created PersistentVolumeClaim                                                     | `{}`                          |

### ConfigMap Parameters

Contains configuration parameters specific to the *Search Projector* application

| Name                             | Description                                                                        | Value |
| -------------------------------- | ---------------------------------------------------------------------------------- | ----- |
| `configMap.existingEnvConfigMap` | Name of existing configmap containing *Search Projector* Environment Configuration | `""`  |

### Common Parameters

| Name                | Description                                                            | Value |
| ------------------- | ---------------------------------------------------------------------- | ----- |
| `nameOverride`      | String to partially override fullname (will maintain the release name) | `""`  |
| `fullnameOverride`  | String to fully override the generated release name                    | `""`  |
| `namespaceOverride` | String to fully override all deployed resources namespace              | `""`  |
| `commonLabels`      | Add labels to all the deployed resources                               | `{}`  |

### Deployment Parameters

| Name                   | Description                                                             | Value |
| ---------------------- | ----------------------------------------------------------------------- | ----- |
| `replicas`             | Number of *Search Projector* replicas to deploy                         | `1`   |
| `revisionHistoryLimit` | Number of controller revisions to keep                                  | `5`   |
| `annotations`          | Add extra annotations to the deployment object                          | `{}`  |
| `podLabels`            | Add extra labels to the *Search Projector* pod                          | `{}`  |
| `podAnnotations`       | Add extra annotations to the *Search Projector* pod                     | `{}`  |
| `extraEnvVars`         | Array with extra environment variables to add to *Search Projector* pod | `[]`  |
| `extraVolumes`         | Optionally specify extra list of additional volumes                     | `[]`  |
| `extraVolumeMounts`    | Optionally specify extra list of additional volumeMounts                | `[]`  |
| `initContainers`       | Add init containers to the pod                                          | `[]`  |
| `sidecars`             | Add sidecars to the pod                                                 | `[]`  |

### Deployment Image Parameters

| Name                | Description                                                                       | Value                                |
| ------------------- | --------------------------------------------------------------------------------- | ------------------------------------ |
| `image.registry`    | *Search Projector* image registry                                                 | `quay.io`                            |
| `image.repository`  | *Search Projector* image name                                                     | `telicent/smart-cache-elastic-index` |
| `image.tag`         | *Search Projector* image tag. If not set, a tag is generated using the appVersion | `""`                                 |
| `image.pullPolicy`  | *Search Projector* image pull policy                                              | `IfNotPresent`                       |
| `image.pullSecrets` | Specify registry secret names as an array                                         | `[]`                                 |

### Deployment Resources Parameters - Requests and Limits

| Name        | Description                                 | Value |
| ----------- | ------------------------------------------- | ----- |
| `resources` | Resources for *Search Projector* containers | `{}`  |

### Deployment Security Context Parameters - Default Security Context

| Name                                                | Description                                                             | Value            |
| --------------------------------------------------- | ----------------------------------------------------------------------- | ---------------- |
| `podSecurityContext.runAsUser`                      | Set the provisioning pod's Security Context runAsUser User ID           | `185`            |
| `podSecurityContext.runAsGroup`                     | Set the provisioning pod's Security Context runAsGroup Group ID         | `185`            |
| `podSecurityContext.runAsNonRoot`                   | Set the provisioning pod's Security Context runAsNonRoot                | `true`           |
| `podSecurityContext.fsGroup`                        | Set the provisioning pod's Group ID for the mounted volumes' filesystem | `185`            |
| `podSecurityContext.seccompProfile.type`            | Set the provisioning pod's Security Context seccomp profile             | `RuntimeDefault` |
| `containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser User ID                      | `185`            |
| `containerSecurityContext.runAsGroup`               | Set containers' Security Context runAsGroup Group ID                    | `185`            |
| `containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                           | `true`           |
| `containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation               | `false`          |
| `containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                      | `["ALL"]`        |
| `containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                        | `RuntimeDefault` |

### Deployment Affinity Parameters

| Name           | Description                    | Value |
| -------------- | ------------------------------ | ----- |
| `affinity`     | Affinity for pod assignment    | `{}`  |
| `nodeSelector` | Node labels for pod assignment | `{}`  |
| `tolerations`  | Tolerations for pod assignment | `[]`  |

### Service Account Parameters

| Name                         | Description                                                                           | Value  |
| ---------------------------- | ------------------------------------------------------------------------------------- | ------ |
| `serviceAccount.create`      | Specifies whether a service account should be created                                 | `true` |
| `serviceAccount.name`        | Name of the ServiceAccount to use. If not set, a name is generated using the fullname | `""`   |
| `serviceAccount.annotations` | Additional custom annotations for the ServiceAccount                                  | `{}`   |
| `serviceAccount.automount`   | Automatically mount a ServiceAccount's API credentials                                | `true` |

### Traffic Exposure Parameters

| Name           | Description                                                                         | Value       |
| -------------- | ----------------------------------------------------------------------------------- | ----------- |
| `service.name` | *Search Projector* service name. If not set, a name is generated using the fullname | `""`        |
| `service.type` | *Search Projector* service type                                                     | `ClusterIP` |

### Metrics (Prometheus) Exposure Parameters

| Name                   | Description                     | Value     |
| ---------------------- | ------------------------------- | --------- |
| `metrics.enabled`      | Enable Prometheus metrics       | `true`    |
| `metrics.service.name` | Name for the Prometheus service | `metrics` |
| `metrics.service.port` | Port for the Prometheus service | `9464`    |


## Helm Unit Tests
The `Unit Tests for Helm Chart` workflow runs `helm unittest` against the chart to run all the `*_test.yaml` files founder under `charts/search-projector`.

## Deployment 
### Tests
| Test | Area | What it checks | 
|---|---|---| 
| Should create a Deployment | Basic rendering | Template renders and produces a `Deployment` kind | 
| Should use global imagePullSecrets when set | Pull secrets | `global.imagePullSecrets` appears in `imagePullSecrets[0].name` | 
| Should fall back to image.pullSecrets when global is not set | Pull secrets | `image.pullSecrets` used when `global` is unset | 
| Should build the image from registry, repository and tag | Image | Full `<registry>/<repo>:<tag>` string built correctly | 
| Should fall back to Chart.AppVersion when image.tag is not set | Image | Tag falls back to `Chart.AppVersion` when `image.tag` omitted | 
| Should set the imagePullPolicy from values | Image | `image.pullPolicy` passed through to container |
| Should set a checksum/config annotation| Checksum | `checksum/config` annotation matches a valid sha256 hex pattern | 
| Should set a checksum/secret annotation | Checksum | `checksum/secret` annotation matches a valid sha256 hex pattern  | 
| Should default the pod securityContext| Security | Full `spec.template.spec.securityContext` matches chart defaults (`fsGroup`, `runAsUser`, `runAsGroup` = 185, `runAsNonRoot: true`, `seccompProfile.type: RuntimeDefault`) | 
| Should default the container securityContext | Security | Full container `securityContext` matches defaults (`allowPrivilegeEscalation: false`, `capabilities.drop: [ALL]`, same user/group/nonroot values, `seccompProfile`) | 
| Should not set prometheus annotations when metrics disabled | Prometheus | Annotations absent when `metrics.enabled: false` | 
| Should set prometheus annotations with defaults when metrics enabled | Prometheus | Annotations added when `metrics.enabled: true`|
| Should leave out resources when not set | Resources | `resources` absent when `.Values.resources` is empty | 
| Should set resources when provided | Resources | Full `requests`/`limits` block passes through values provided| 

## Service 
### Tests
 
| Test | What it checks |
|---|---|
| Should create a Service | Template renders and produces a `Service` kind |
| Should set the service type | `service.type`  Only `ClusterIP` is set in `spec.type` |
| Should set the port name to http | The port's `name` is always `http` |
| Should set the app protocol to http | The port's `appProtocol` is always `http`| 
| Should target the http port | `targetPort` is always `http`| 

## Service Account 
### Tests
 
| Test | What it checks |
|---|---|
| Should create a ServiceAccount when enabled | Template renders a `ServiceAccount` kind (default `serviceAccount.create` is truthy) | 
| Should not create a ServiceAccount when disabled | Setting `serviceAccount.create: false` results in no resources being created |
| Should set automountServiceAccountToken to true | Default `serviceAccount.automount` should show as `true` on `automountServiceAccountToken` |
| Should set automountServiceAccountToken to false | Setting `serviceAccount.automount: false` should show `false` |  

## Config Map
### Tests
 
| Test | What it checks |
|---|---|
| Should create a ConfigMap with the generated name when no existingConfigMap given | Checks that configmap is created following `tc-<chart>-env` name | 
| Should use the existingConfigMap name when given | Checks whether existing configmap can be set |

## Authorization Policies
### Tests

| Test | What it checks |
|---|---|
| Should build the principal from release namespace and service account, not a hardcoded value | Checks that the principal substitutes in the release namespace and service account name correctly when `hosts.enableAutoCorrect` is disabled |
| Should apply release-name autocorrect to the service account when enabled | Checks that when `hosts.enableAutoCorrect` is set to true, the release name is correctly prefixed onto the service account in the principal |


## License

Copyright &copy; 2026 Telicent Limited
