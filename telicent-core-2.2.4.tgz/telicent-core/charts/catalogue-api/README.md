# catalogue-api

A read-write API for DCAT catalog metadata (Argus Catalogue API).

This chart deploys the Catalogue API into an existing cluster. It expects an
external triplestore (SPARQL endpoint) and a Telicent auth server.

## Installing

```bash
helm install catalogue-api ./charts/catalogue-api \
  --set triplestore.url=https://triplestore.example.com
```

## Parameters

### Global parameters

| Name                      | Description                                                                                                                                                                                                                          | Value                |
| ------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------- |
| `global.imageRegistry`    | Global image registry override for umbrella charts                                                                                                                                                                                   | `""`                 |
| `global.imagePullSecrets` | Global image pull secrets override for umbrella charts                                                                                                                                                                               | `[]`                 |
| `global.appHostDomain`    | Domain associated with Telicent application/ui services. This value cannot be changed after it is set                                                                                                                                | `""`                 |
| `global.apiHostDomain`    | Domain associated with Telicent Api services. This value cannot be changed after it is set                                                                                                                                           | `""`                 |
| `global.authHostDomain`   | Domain associated with Telicent authentication services, including OIDC providers. This value cannot be changed after it is set                                                                                                      | `""`                 |
| `global.enabled`          | Enable the Catalogue API deployment                                                                                                                                                                                                  | `false`              |
| `hosts.enableAutoCorrect` | Allow for the release name to be automatically pre-fixed to each host value when required (default behavior when installing through the parent chart). Alternatively, the host value will be used as it is, without any modification | `true`               |
| `hosts.auth`              | Auth application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                                     | `auth:8080`          |
| `hosts.traefikProxy`      | Traefik Proxy application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                            | `traefik-proxy:8080` |

### Image

| Name                | Description                                                  | Value                    |
| ------------------- | ------------------------------------------------------------ | ------------------------ |
| `image.registry`    | Container image registry                                     | `quay.io`                |
| `image.repository`  | Container image repository                                   | `telicent/catalogue-api` |
| `image.tag`         | Container image tag (defaults to Chart.appVersion)           | `""`                     |
| `image.digest`      | Image digest (sha256:…) — takes precedence over tag when set | `""`                     |
| `image.pullPolicy`  | Image pull policy                                            | `IfNotPresent`           |
| `image.pullSecrets` | Image pull secrets (merged with global.imagePullSecrets)     | `[]`                     |

### Replicas

| Name       | Description                                                       | Value |
| ---------- | ----------------------------------------------------------------- | ----- |
| `replicas` | Number of API replicas (ignored when autoscaling.enabled is true) | `1`   |

### API

| Name                       | Description                                                                                                                                                                                                                           | Value                        |
| -------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------- |
| `api.logLevel`             | Python logging level for the API                                                                                                                                                                                                      | `INFO`                       |
| `api.rootPath`             | Root path prefix when behind a proxy/ingress (sets API_ROOT_PATH, e.g. /catalogue)                                                                                                                                                    | `/catalogue`                 |
| `api.openapiPath`          | Path served for the OpenAPI schema (sets API_OPENAPI_PATH)                                                                                                                                                                            | `/openapi.json`              |
| `api.disableDocs`          | Disable the Swagger UI (/docs) and OpenAPI schema routes in the ingress policy                                                                                                                                                        | `false`                      |
| `api.corsAllowOrigins`     | Comma-separated list of allowed CORS origins (sets CORS_ALLOW_ORIGINS). Empty omits the variable and the app then fails to start, so this is effectively required.                                                                    | `""`                         |
| `api.sharedSecurityLabel`  | Security label for shared-entity writes: owner, publisher, contact, rights, contributor (sets CATALOG_SHARED_SECURITY_LABEL). "*" is permissive — override per deployment.                                                            | `*`                          |
| `api.defaultSecurityLabel` | Security label for a dataset write when securityLabel is absent from the request (sets CATALOG_DEFAULT_SECURITY_LABEL). "*" is permissive — override per deployment.                                                                  | `*`                          |
| `api.distributionId`       | Distribution id sent as the Distribution-Id header on every CQRS write (sets CATALOG_DISTRIBUTION_ID). SCG requires one on all writes; the catalogue's own metadata belongs to no distribution, so it is written under this fixed id. | `http://telicent.io/catalog` |

### Triplestore (SPARQL)

| Name                                  | Description                                                                                                                                                                                                                            | Value                    |
| ------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| `triplestore.url`                     | SPARQL endpoint base URL (sets SPARQL_URL). Must be https:// unless allowHttp is true. The app has no default and fails to start without it, so this is effectively required for a real deployment.                                    | `https://localhost:3030` |
| `triplestore.allowHttp`               | Allow HTTP (non-TLS) connections to the triplestore (sets SCG_WRAPPER_ALLOW_HTTP). Defaults false: TLS is required unless a deployment opts out. Set true for a service mesh terminating TLS at the sidecar, or for local development. | `false`                  |
| `triplestore.caCertPath`              | Path to a CA certificate (PEM) to trust for the triplestore's TLS certificate, for an internal PKI (sets SCG_WRAPPER_CA_CERT_PATH). Mount the file with extraVolumes/extraVolumeMounts. Leave empty to use the system CA bundle.       | `""`                     |
| `triplestore.maxConnections`          | Connection pool size cap for the triplestore (sets SCG_WRAPPER_MAX_CONNECTIONS). Leave empty for the default of 100.                                                                                                                   | `""`                     |
| `triplestore.maxKeepaliveConnections` | Idle keep-alive connection cap for the triplestore (sets SCG_WRAPPER_MAX_KEEPALIVE_CONNECTIONS). Must not exceed maxConnections. Leave empty for the default of 20.                                                                    | `""`                     |

### Distribution Lifecycle Service (DLS)

| Name                                | Description                                                                                                                                                                                                                       | Value  |
| ----------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------ |
| `lifecycle.url`                     | Distribution Lifecycle Service base URL (sets DLS_URL). Leave empty to run without it: the API starts and serves normally, distributions are never registered, and the four lifecycle actions return 503.                         | `""`   |
| `lifecycle.allowHttp`               | Allow HTTP (non-TLS) connections to the lifecycle service (sets DLS_ALLOW_HTTP). Defaults true for service-mesh deployments, where TLS is terminated at the sidecar. Set false and use an https:// URL to require TLS end to end. | `true` |
| `lifecycle.caCertPath`              | Path to a CA certificate (PEM) to trust for the lifecycle service's TLS certificate, for an internal PKI (sets DLS_CA_CERT_PATH). Mount the file with extraVolumes/extraVolumeMounts. Leave empty to use the system CA bundle.    | `""`   |
| `lifecycle.timeout`                 | Per-request timeout in seconds for calls to the lifecycle service (sets DLS_TIMEOUT). Leave empty for the default of 5.                                                                                                           | `""`   |
| `lifecycle.connectTimeout`          | TCP connect timeout in seconds for the lifecycle service (sets DLS_CONNECT_TIMEOUT). Leave empty for the default of 5.                                                                                                            | `""`   |
| `lifecycle.maxConnections`          | Connection pool size cap for the lifecycle service (sets DLS_MAX_CONNECTIONS). Leave empty for the default of 100.                                                                                                                | `""`   |
| `lifecycle.maxKeepaliveConnections` | Idle keep-alive connection cap for the lifecycle service (sets DLS_MAX_KEEPALIVE_CONNECTIONS). Must not exceed maxConnections. Leave empty for the default of 20.                                                                 | `""`   |

### Auth Server (telicent-core-extensions)

| Name                | Description                                                                                                                                                                                                                                                                                                                                    | Value           |
| ------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------- |
| `auth.allowHttp`    | Allow HTTP (non-TLS) connections to auth-server                                                                                                                                                                                                                                                                                                | `true`          |
| `auth.jwtIssuer`    | Expected JWT issuer claim                                                                                                                                                                                                                                                                                                                      | `""`            |
| `auth.jwtAudience`  | Expected JWT audience claim                                                                                                                                                                                                                                                                                                                    | `telicent_core` |
| `auth.jwtAlgorithm` | JWT signing algorithm (leave empty for default RS256)                                                                                                                                                                                                                                                                                          | `RS256`         |
| `auth.jwtHeader`    | request header containing the users JWT                                                                                                                                                                                                                                                                                                        | `Authorization` |
| `auth.jwksUrl`      | JWKS endpoint URL (leave empty to derive from auth-server URL)                                                                                                                                                                                                                                                                                 | `""`            |
| `auth.requiredRole` | Role required in the JWT to reach the API at all (sets AUTH_REQUIRED_ROLE). Leave empty to use the telicent-core-extensions default of USER, which is what ordinary catalogue users hold. Do not set ADMIN_SYSTEM: this API enforces no role of its own, and requiring one here rejects every ordinary user at JWT validation, on every route. | `""`            |

### Autoscaling

| Name                                         | Description                        | Value   |
| -------------------------------------------- | ---------------------------------- | ------- |
| `autoscaling.enabled`                        | Enable Horizontal Pod Autoscaler   | `false` |
| `autoscaling.minReplicas`                    | Minimum number of replicas         | `2`     |
| `autoscaling.maxReplicas`                    | Maximum number of replicas         | `10`    |
| `autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization for scaling | `70`    |

### Pod Disruption Budget

| Name                               | Description                                           | Value   |
| ---------------------------------- | ----------------------------------------------------- | ------- |
| `podDisruptionBudget.enabled`      | Enable a PodDisruptionBudget (requires replicas >= 2) | `false` |
| `podDisruptionBudget.minAvailable` | Minimum number of available pods during disruption    | `1`     |

### ConfigMap

| Name                             | Description                                                                       | Value |
| -------------------------------- | --------------------------------------------------------------------------------- | ----- |
| `configMap.existingEnvConfigMap` | Name of an existing ConfigMap to use for non-secret env instead of generating one | `""`  |

### Service

| Name                 | Description                                                                                 | Value       |
| -------------------- | ------------------------------------------------------------------------------------------- | ----------- |
| `service.type`       | Kubernetes service type                                                                     | `ClusterIP` |
| `service.port`       | Port the Service exposes (the cluster-facing port)                                          | `8080`      |
| `service.targetPort` | Port the container listens on; must match the port uvicorn binds in the image (EXPOSE 8000) | `8000`      |

### Service Account

| Name                         | Description                                                            | Value  |
| ---------------------------- | ---------------------------------------------------------------------- | ------ |
| `serviceAccount.create`      | Create a ServiceAccount for the workload                               | `true` |
| `serviceAccount.annotations` | Annotations to add to the ServiceAccount                               | `{}`   |
| `serviceAccount.name`        | ServiceAccount name (generated from the chart name if empty)           | `""`   |
| `serviceAccount.automount`   | Automount the ServiceAccount token (the API does not call the K8s API) | `true` |

### Pod Labels and Annotations

| Name             | Description                       | Value |
| ---------------- | --------------------------------- | ----- |
| `podLabels`      | Extra labels applied to Pods      | `{}`  |
| `podAnnotations` | Extra annotations applied to Pods | `{}`  |

### Probes

| Name                              | Description                                                          | Value        |
| --------------------------------- | -------------------------------------------------------------------- | ------------ |
| `startupProbe.httpGet.path`       | HTTP path probed to detect application startup                       | `/readiness` |
| `startupProbe.httpGet.port`       | Port (name or number) probed to detect application startup           | `http`       |
| `startupProbe.failureThreshold`   | Number of failed startup probes before the container is restarted    | `30`         |
| `startupProbe.periodSeconds`      | How often (in seconds) to perform the startup probe                  | `10`         |
| `readinessProbe.httpGet.path`     | HTTP path probed to determine readiness to serve traffic             | `/readiness` |
| `readinessProbe.httpGet.port`     | Port (name or number) probed to determine readiness                  | `http`       |
| `readinessProbe.periodSeconds`    | How often (in seconds) to perform the readiness probe                | `5`          |
| `readinessProbe.timeoutSeconds`   | Seconds after which the readiness probe times out                    | `5`          |
| `readinessProbe.failureThreshold` | Number of failed readiness probes before the Pod is marked not ready | `6`          |
| `livenessProbe.httpGet.path`      | HTTP path probed to determine container liveness                     | `/liveness`  |
| `livenessProbe.httpGet.port`      | Port (name or number) probed to determine container liveness         | `http`       |
| `livenessProbe.periodSeconds`     | How often (in seconds) to perform the liveness probe                 | `15`         |
| `livenessProbe.timeoutSeconds`    | Seconds after which the liveness probe times out                     | `5`          |
| `livenessProbe.failureThreshold`  | Number of failed liveness probes before the container is restarted   | `3`          |

### Deployment Security Context Parameters - Default Security Context

| Name                                                | Description                                                             | Value            |
| --------------------------------------------------- | ----------------------------------------------------------------------- | ---------------- |
| `podSecurityContext.runAsUser`                      | Set the provisioning pod's Security Context runAsUser User ID           | `185`            |
| `podSecurityContext.runAsGroup`                     | Set the provisioning pod's Security Context runAsGroup Group ID         | `185`            |
| `podSecurityContext.runAsNonRoot`                   | Set the provisioning pod's Security Context runAsNonRoot                | `true`           |
| `podSecurityContext.fsGroup`                        | Set the provisioning pod's Group ID for the mounted volumes' filesystem | `185`            |
| `podSecurityContext.seccompProfile.type`            | Set the provisioning pod's Security Context seccomp profile             | `RuntimeDefault` |
| `containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser User ID                      | `185`            |
| `containerSecurityContext.runAsGroup`               | Set containers' Security Context runAsGroup Group ID                    | `185`            |
| `containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                           | `true`           |
| `containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation               | `false`          |
| `containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                      | `["ALL"]`        |
| `containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                        | `RuntimeDefault` |

### Resource requests/limits

| Name        | Description                                    | Value |
| ----------- | ---------------------------------------------- | ----- |
| `resources` | Resource requests/limits for the API container | `{}`  |

### Scheduling

| Name           | Description                       | Value |
| -------------- | --------------------------------- | ----- |
| `nodeSelector` | Node selector for pod scheduling  | `{}`  |
| `tolerations`  | Tolerations for pod scheduling    | `[]`  |
| `affinity`     | Affinity rules for pod scheduling | `{}`  |

### Extra configuration

| Name                | Description                                            | Value |
| ------------------- | ------------------------------------------------------ | ----- |
| `extraEnvVars`      | Additional environment variables for the API container | `[]`  |
| `extraVolumes`      | Additional volumes                                     | `[]`  |
| `extraVolumeMounts` | Additional volume mounts for the API container         | `[]`  |
| `initContainers`    | Additional init containers                             | `[]`  |
| `sidecars`          | Additional sidecar containers                          | `[]`  |

### Override defaults

| Name                   | Description                            | Value |
| ---------------------- | -------------------------------------- | ----- |
| `nameOverride`         | Override the chart name                | `""`  |
| `fullnameOverride`     | Override the full resource name prefix | `""`  |
| `namespaceOverride`    | Override the target namespace          | `""`  |
| `commonLabels`         | Extra labels applied to every resource | `{}`  |
| `revisionHistoryLimit` | Number of old ReplicaSets to retain    | `5`   |
