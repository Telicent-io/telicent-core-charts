# Telicent Package for Auth

**Auth** provides auth capabilities and exposes endpoints for querying user authentication.

## Introduction

This chart bootstraps Auth deployment on a [Kubernetes](https://kubernetes.io) cluster using
the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.23+
- Helm 3.9+

## Installing the Chart

To install the chart with the release name `my-release`:

```console
helm install my-release ./charts/telicent-core/charts/auth
```

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```console
helm delete my-release
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Automating README and schema generation

```bash
.dev/readme-generator-for-helm --config=charts/telicent-core/readme.config \
 --values=charts/telicent-core/charts/auth/values.yaml \
 --readme=charts/telicent-core/charts/auth/README.md \
 --schema=charts/telicent-core/charts/auth/values.schema.json
```

## Configuration and installation details

### Resource requests and limits

These are inside the `resources` value (check parameter table). Setting requests is essential for production workloads
and these should be adapted to your specific use case.

### Sidecars and Init Containers

If you have a need for additional containers to run within the same pod (e.g. an additional metrics or logging
exporter), you can do so via the `sidecars` config parameter.
Define your container according to the Kubernetes container spec.

```yaml
sidecars:
- name: your-image-name
  image: your-image
  imagePullPolicy: Always
  ports:
  - name: portname
    containerPort: 1234
```

Similarly, you can add extra init containers using the `initContainers` parameter.

```yaml
initContainers:
- name: your-image-name
  image: your-image
  imagePullPolicy: Always
  ports:
  - name: portname
    containerPort: 1234
```

### Setting Pod's affinity

This chart allows you to set your custom affinity using the `affinity` parameter.
Find more information about Pod's affinity in
the [kubernetes documentation](https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity).

## Parameters

### Global Parameters

Contains global parameters; these parameters are mirrored within the Telicent core umbrella chart.
Note: Only global parameters used within this chart will be listed below.

| Name                                | Description                                                                                                                                                                            | Value                    |
| ----------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| `global.imageRegistry`              | Global image registry                                                                                                                                                                  | `""`                     |
| `global.imagePullSecrets`           | Global registry secret names as an array                                                                                                                                               | `[]`                     |
| `global.releaseNameTelicentPreview` | Release name used during the Telicent Preview chart installation. Note: ensure the value is correct, otherwise there will be no access to data-catalog, user-portal & paperback-writer | `""`                     |
| `global.enterprise`                 | Enable enterprise mode, adding additional features and configurations                                                                                                                  | `false`                  |
| `global.appHostDomain`              | Domain associated with Telicent application/ui services. This value cannot be changed after it is set                                                                                  | `""`                     |
| `global.apiHostDomain`              | Domain associated with Telicent Api services. This value cannot be changed after it is set                                                                                             | `""`                     |
| `global.authHostDomain`             | Domain associated with Telicent authentication services, including OIDC providers. This value cannot be changed after it is set                                                        | `""`                     |
| `global.truststore.existingSecret`  | Name of an existing secret containing the truststore                                                                                                                                   | `""`                     |
| `global.truststore.mountPath`       | The mount path for the truststore in the container                                                                                                                                     | `/app/config/truststore` |

### Application Parameters - Identity Provider (IDP) and Secret

Contains details pertinent to the OIDC Identity Provider to be used by the *Auth* OAuth application.
It is recommended to store sensitive information including passwords in a Kubernetes secret and not in Helm values.
For Quick Start purposes, a secret named `tc-auth-gen-idp-auth` will be created if one is not set.

| Name                          | Description                                                                                                                                                                                                                          | Value          |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------- |
| `idp.issuerUrl`               | The OpenID Connect issuer URL                                                                                                                                                                                                        | `""`           |
| `idp.authorizationPath`       | The path to use in combination with the issuer URL for authorization                                                                                                                                                                 | `/auth`        |
| `idp.jwksPath`                | The path to use in combination with the issuer URL for JWKS                                                                                                                                                                          | `/keys`        |
| `idp.tokenPath`               | The path to use in combination with the issuer URL for generating tokens                                                                                                                                                             | `/token`       |
| `idp.userinfoPath`            | The path to use in combination with the issuer URL for userinfo                                                                                                                                                                      | `/userinfo`    |
| `idp.requireHttps`            | Require HTTPS for all Identity Provider URLs. Startup fails if any IdP URL is plaintext. Only set to false where TLS to the IdP is terminated by a trusted service mesh.                                                             | `true`         |
| `idp.startupCheckEnabled`     | Verify the Identity Provider JWKS endpoint is reachable at startup                                                                                                                                                                   | `true`         |
| `idp.startupCheckFailOnError` | Abort startup when the Identity Provider JWKS endpoint cannot be reached                                                                                                                                                             | `false`        |
| `idp.logoutMode`              | Upstream logout policy: none (local-only) or rp-initiated (requires discovery end_session_endpoint and a registered return URI)                                                                                                      | `none`         |
| `idp.postLogoutRedirectUri`   | Exact return URI registered under Valid post logout redirect URIs on the upstream IdP client; required for rp-initiated logout                                                                                                       | `""`           |
| `idp.cookieParentDomain`      | Cookie domain scope                                                                                                                                                                                                                  | `.telicent.io` |
| `idp.cookieSecure`            | Enable secure cookies                                                                                                                                                                                                                | `true`         |
| `idp.superUserIdentifier`     | superuser identification (required), in the form '<claim>:<value>' where claim is one of email, sub, userNameAttribute or groups. Set to 'ALL' to make every user a superuser - only ever for local or sandbox use, never production | `""`           |
| `idp.clientName`              | The OAuth Client Name (used for display)                                                                                                                                                                                             | `""`           |
| `idp.usernameClaim`           | The OIDC claim containing the attribute to be used as the username                                                                                                                                                                   | `sub`          |
| `idp.groupsClaim`             | The OIDC claim containing the user's groups, e.g. cognito:groups for Amazon Cognito                                                                                                                                                  | `groups`       |
| `idp.existingSecret`          | Name of an existing secret. The secret must contain 2 keys: 'clientid', 'clientsecret'                                                                                                                                               | `""`           |
| `idp.clientId`                | The OAuth Client ID                                                                                                                                                                                                                  | `""`           |
| `idp.clientSecret`            | The OAuth Client Secret                                                                                                                                                                                                              | `""`           |
| `idp.sessionTtl`              | Default session time-to-live duration (in hours)                                                                                                                                                                                     | `PT2H`         |
| `idp.maxConcurrentSessions`   | Maximum unexpired sessions per user across all clients (positive integer)                                                                                                                                                            | `10`           |
| `idp.sessionIdleTtl`          | Default session idle time-to-live duration (in minutes)                                                                                                                                                                              | `PT30M`        |
| `idp.clientRefreshTokenTtl`   | Client refresh token time-to-live duration (in hours). Total time will not exceed idp.sessionTtl even if this value is higher                                                                                                        | `PT2H`         |
| `idp.clientAccessTokenTtl`    | Client access token time-to-live duration (in minutes)                                                                                                                                                                               | `PT15M`        |

### Application Parameters - ForwardAuth and Secret

When making requests to the `/auth/forward` endpoint (used by reverse proxies), `X-ForwardAuth-Secret` header is required.
The secret associated with that header is defined within this section.
It is recommended to store sensitive information including passwords in a Kubernetes secret and not in Helm values.
For Quick Start purposes, a secret named `tc-auth-gen-forward-auth` will be created if one is not set.

| Name                         | Description                                                         | Value |
| ---------------------------- | ------------------------------------------------------------------- | ----- |
| `forwardAuth.existingSecret` | Name of an existing secret. The secret must contain 1 key: 'header' | `""`  |
| `forwardAuth.header`         | The header value to be associated with the `X-ForwardAuth-Secret`   | `""`  |

### Application Parameters - Server / Proxy Trust

Reverse-proxy trust settings for Tomcat's native forwarded-header handling. The default allow-list trusts only
loopback and RFC1918 private-address proxies. If your ingress/proxy uses a different source range, set this value
explicitly rather than widening it to `.*`.

| Name                                    | Description                                                           | Value                                                                                    |
| --------------------------------------- | --------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| `server.tomcat.remoteIpInternalProxies` | Regex of trusted proxy source addresses for forwarded-header handling | `127\.\d{1,3}\.\d{1,3}\.\d{1,3}|::1|10\..*|192\.168\..*|172\.(1[6-9]|2[0-9]|3[0-1])\..*` |

### Application Parameters - Rate Limiting

Endpoint throttling and authentication backoff controls. Default mode is `off` so the feature can be shipped safely
and enabled per environment after validating behavior. `/oauth2/token` and `/oauth2/authorize` use distributed
per-IP counters only. `/auth/forward` uses local in-memory IP and session counters to keep the forward-auth hot path
off PostgreSQL. `/session/check`, `/session/idtoken` and `/session/logout` consume a distributed per-IP ceiling and,
when a valid session id is present, also consume a local in-memory per-session sub-budget.

| Name                                              | Description                                                                                      | Value          |
| ------------------------------------------------- | ------------------------------------------------------------------------------------------------ | -------------- |
| `rateLimit.mode`                                  | Rate-limit mode. Supported values: off, log-only, enforce                                        | `off`          |
| `rateLimit.failOpenOnBackendError`                | Permit requests if the rate-limit backend is unavailable                                         | `true`         |
| `rateLimit.oauth2TokenRequestsPerMinute`          | Requests per minute per source IP for /oauth2/token                                              | `100`          |
| `rateLimit.oauth2AuthorizeRequestsPerMinute`      | Requests per minute per source IP for /oauth2/authorize                                          | `100`          |
| `rateLimit.authForwardRequestsPerMinute`          | Requests per minute per source IP ceiling for /auth/forward                                      | `3000`         |
| `rateLimit.authForwardSessionRequestsPerMinute`   | Requests per minute per session for /auth/forward                                                | `600`          |
| `rateLimit.sessionCheckRequestsPerMinute`         | Requests per minute per source IP ceiling for /session/check and /session/idtoken                | `240`          |
| `rateLimit.sessionCheckSessionRequestsPerMinute`  | Requests per minute per session for /session/check and /session/idtoken                          | `48`           |
| `rateLimit.sessionLogoutRequestsPerMinute`        | Requests per minute per source IP ceiling for /session/logout                                    | `100`          |
| `rateLimit.sessionLogoutSessionRequestsPerMinute` | Requests per minute per session for /session/logout                                              | `20`           |
| `rateLimit.linearBackoffSeconds`                  | Base linear delay used for failures 2-4                                                          | `5`            |
| `rateLimit.exponentialBackoffBaseSeconds`         | Base delay used from failure 5 onwards                                                           | `30`           |
| `rateLimit.maxBackoffSeconds`                     | Maximum lock duration in seconds                                                                 | `900`          |
| `rateLimit.authBackoffDecaySeconds`               | Reset the accumulated auth failure count after this many quiet seconds                           | `1800`         |
| `rateLimit.authBackoffPromotionThreshold`         | Number of local failures before a known client is promoted into persistent auth backoff tracking | `3`            |
| `rateLimit.cleanupCron`                           | Cron expression for auth backoff cleanup                                                         | `0 30 3 * * *` |
| `rateLimit.cleanupBatchSize`                      | Maximum rows deleted per cleanup pass                                                            | `1000`         |
| `rateLimit.cleanupContinueThreshold`              | Continue cleanup when deleted rows meet this threshold                                           | `50`           |
| `rateLimit.authBackoffRetentionHours`             | Retention window for stale auth backoff rows                                                     | `24`           |

### Application Parameters - Java

Contains Java parameters to be used by the *Auth* application

| Name                  | Description                                                                            | Value                       |
| --------------------- | -------------------------------------------------------------------------------------- | --------------------------- |
| `java.jvmOptions`     | JVM options for the application                                                        | `-XX:MaxRAMPercentage=80.0` |
| `java.spring.profile` | Sets the Spring profile to be used. Options are: default, docker, test, and production | `production`                |

### Application Parameters - Logs

| Name                  | Description                                                                              | Value   |
| --------------------- | ---------------------------------------------------------------------------------------- | ------- |
| `logs.api.level`      | Api package Logging Level. Values include: ERROR, WARN, INFO, DEBUG, TRACE               | `INFO`  |
| `logs.service.level`  | Service package Logging Level. Values include: ERROR, WARN, INFO, DEBUG, TRACE           | `INFO`  |
| `logs.repo.level`     | Repo package Logging Level. Values include: ERROR, WARN, INFO, DEBUG, TRACE              | `WARN`  |
| `logs.security.level` | Security packageLogging Level. Values include: ERROR, WARN, INFO, DEBUG, TRACE           | `WARN`  |
| `logs.oauth2.level`   | Oauth2 package Logging Level. Values include: ERROR, WARN, INFO, DEBUG, TRACE            | `WARN`  |
| `logs.general.level`  | Logging Level for 'io.telicent.auth'. Values include: ERROR, WARN, INFO, DEBUG, TRACE    | `INFO`  |
| `logs.trace.level`    | Logging Level for 'Spring RestTemplate'. Values include: ERROR, WARN, INFO, DEBUG, TRACE | `ERROR` |

### Application Parameters - PostgreSQL and Secret

The following contains connection details to a PostgreSQL instance, on which the application relies.
It is recommended to store sensitive information including passwords in a Kubernetes secret and not in Helm values.
For Quick Start purposes, a secret named `tc-auth-usr-psql-auth` will be created if one is not set.

| Name                                        | Description                                                                        | Value     |
| ------------------------------------------- | ---------------------------------------------------------------------------------- | --------- |
| `postgresSql.uri`                           | PostgreSQL connection URI                                                          | `""`      |
| `postgresSql.existingSecret`                | Name of an existing secret. The secret must contain 2 keys: 'username', 'password' | `""`      |
| `postgresSql.username`                      | PostgreSQL username                                                                | `""`      |
| `postgresSql.password`                      | PostgreSQL password                                                                | `""`      |
| `postgresSql.hikari.maximumPoolSize`        | Maximum number of connections in the pool                                          | `30`      |
| `postgresSql.hikari.minimumIdle`            | Minimum number of idle connections kept warm                                       | `10`      |
| `postgresSql.hikari.connectionTimeout`      | Max wait (ms) for a connection before failing                                      | `5000`    |
| `postgresSql.hikari.validationTimeout`      | Max time (ms) to validate a connection                                             | `3000`    |
| `postgresSql.hikari.idleTimeout`            | Max time (ms) a connection may sit idle before retirement                          | `600000`  |
| `postgresSql.hikari.maxLifetime`            | Max lifetime (ms) of a connection in the pool                                      | `1800000` |
| `postgresSql.hikari.keepaliveTime`          | Interval (ms) between keepalive probes on idle connections                         | `120000`  |
| `postgresSql.hikari.leakDetectionThreshold` | Log a warning if a connection is held longer than this (ms); 0 disables            | `0`       |

### Application Parameters - Bootstrap

Contains configuration to be used to bootstrap a clean instance of the Auth application to a working state.

| Name                                             | Description                                                                                                                                                                           | Value   |
| ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------- |
| `bootstrap.clients.existingConfigMap`            | Name of an existing config map resource containing all required public and confidential clients. If specified, the values for clients.public and clients.confidential will be ignored | `""`    |
| `bootstrap.clients.public`                       | A list of public client objects                                                                                                                                                       | `[]`    |
| `bootstrap.clients.confidential`                 | A list of confidential client objects                                                                                                                                                 | `[]`    |
| `bootstrap.clients.notifications.existingSecret` | Name of an existing secret containing the notifications client secret. The secret must contain 1 key: 'client_secret'                                                                 | `""`    |
| `bootstrap.clients.notifications.clientSecret`   | The notifications API client secret (NOTIFICATIONS_CLIENT_SECRET)                                                                                                                     | `""`    |
| `bootstrap.clients.registry.existingSecret`      | Name of an existing secret containing the registry client secret. The secret must contain 1 key: 'client_secret'                                                                      | `""`    |
| `bootstrap.clients.registry.clientSecret`        | The registry API client secret (REGISTRY_CLIENT_SECRET)                                                                                                                               | `""`    |
| `bootstrap.serviceAccounts`                      | A list of service account objects to seed on startup                                                                                                                                  | `[]`    |
| `bootstrap.groups.existingConfigMap`             | Name of an existing config map containing a list of group objects                                                                                                                     | `""`    |
| `bootstrap.groups.list`                          | A list containing group objects                                                                                                                                                       | `[]`    |
| `bootstrap.organisations.existingConfigMap`      | Name of an existing config map containing a list of organisation objects                                                                                                              | `""`    |
| `bootstrap.organisations.list`                   | A list containing organisation objects. Ignored if bootstrap.organisations.existingConfigMap is set                                                                                   | `[]`    |
| `bootstrap.seedOnce`                             | Apply each category of seed data once rather than on every startup. Entities removed                                                                                                  | `false` |
| `bootstrap.reseedOnChange`                       | Only applies when bootstrap.seedOnce is enabled. Re-apply a category of seed data                                                                                                     | `false` |
| `bootstrap.attributeGroupings.existingConfigMap` | Name of an existing config map containing a list of attribute grouping objects                                                                                                        | `""`    |
| `bootstrap.attributeGroupings.list`              | A list containing attribute grouping objects. Ignored if bootstrap.attributeGroupings.existingConfigMap is set                                                                        | `[]`    |

### ConfigMap Parameters

| Name                             | Description                                                            | Value |
| -------------------------------- | ---------------------------------------------------------------------- | ----- |
| `configMap.existingEnvConfigMap` | Name of existing configmap containing *Auth* Environment Configuration | `""`  |

### Common Parameters

| Name                | Description                                                            | Value |
| ------------------- | ---------------------------------------------------------------------- | ----- |
| `nameOverride`      | String to partially override fullname (will maintain the release name) | `""`  |
| `fullnameOverride`  | String to fully override the generated release name                    | `""`  |
| `namespaceOverride` | String to fully override all deployed resources namespace              | `""`  |
| `commonLabels`      | Add labels to all the deployed resources                               | `{}`  |

### Deployment Parameters

| Name                   | Description                                                 | Value |
| ---------------------- | ----------------------------------------------------------- | ----- |
| `replicas`             | Number of *Auth* replicas to deploy                         | `1`   |
| `revisionHistoryLimit` | Number of controller revisions to keep                      | `5`   |
| `annotations`          | Add extra annotations to the deployment object              | `{}`  |
| `podLabels`            | Add extra labels to the *Auth* pod                          | `{}`  |
| `podAnnotations`       | Add extra annotations to the *Auth* pod                     | `{}`  |
| `extraEnvVars`         | Array with extra environment variables to add to *Auth* pod | `[]`  |
| `extraVolumes`         | Optionally specify extra list of additional volumes         | `[]`  |
| `extraVolumeMounts`    | Optionally specify extra list of additional volumeMounts    | `[]`  |
| `initContainers`       | Add init containers to the pod                              | `[]`  |
| `sidecars`             | Add sidecars to the pod                                     | `[]`  |

### Deployment Image Parameters

| Name                | Description                                                           | Value                           |
| ------------------- | --------------------------------------------------------------------- | ------------------------------- |
| `image.registry`    | *Auth* image registry                                                 | `quay.io`                       |
| `image.repository`  | *Auth* image name                                                     | `telicent/telicent-auth-server` |
| `image.tag`         | *Auth* image tag. If not set, a tag is generated using the appVersion | `""`                            |
| `image.pullPolicy`  | *Auth* image pull policy                                              | `IfNotPresent`                  |
| `image.pullSecrets` | Specify registry secret names as an array                             | `[]`                            |

### Deployment Resources Parameters - Requests and Limits

| Name        | Description                     | Value |
| ----------- | ------------------------------- | ----- |
| `resources` | Resources for *Auth* containers | `{}`  |

### Deployment Security Context Parameters - Default Security Context

| Name                                                | Description                                                             | Value            |
| --------------------------------------------------- | ----------------------------------------------------------------------- | ---------------- |
| `podSecurityContext.runAsUser`                      | Set the provisioning pod's Security Context runAsUser User ID           | `185`            |
| `podSecurityContext.runAsGroup`                     | Set the provisioning pod's Security Context runAsGroup Group ID         | `185`            |
| `podSecurityContext.runAsNonRoot`                   | Set the provisioning pod's Security Context runAsNonRoot                | `true`           |
| `podSecurityContext.fsGroup`                        | Set the provisioning pod's Group ID for the mounted volumes' filesystem | `185`            |
| `podSecurityContext.seccompProfile.type`            | Set the provisioning pod's Security Context seccomp profile             | `RuntimeDefault` |
| `containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser User ID                      | `185`            |
| `containerSecurityContext.runAsGroup`               | Set containers' Security Context runAsGroup Group ID                    | `185`            |
| `containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                           | `true`           |
| `containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation               | `false`          |
| `containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                      | `["ALL"]`        |
| `containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                        | `RuntimeDefault` |

### Deployment Affinity Parameters

| Name           | Description                    | Value |
| -------------- | ------------------------------ | ----- |
| `affinity`     | Affinity for pod assignment    | `{}`  |
| `nodeSelector` | Node labels for pod assignment | `{}`  |
| `tolerations`  | Tolerations for pod assignment | `[]`  |

### Service Account Parameters

| Name                         | Description                                                                           | Value  |
| ---------------------------- | ------------------------------------------------------------------------------------- | ------ |
| `serviceAccount.create`      | Specifies whether a service account should be created                                 | `true` |
| `serviceAccount.name`        | Name of the ServiceAccount to use. If not set, a name is generated using the fullname | `""`   |
| `serviceAccount.annotations` | Additional custom annotations for the ServiceAccount                                  | `{}`   |
| `serviceAccount.automount`   | Automatically mount a ServiceAccount's API credentials                                | `true` |

### Service Mesh (Istio) Parameters

Controls the Istio security resources deployed alongside *Auth*.

| Name                        | Description                                                                    | Value                  |
| --------------------------- | ------------------------------------------------------------------------------ | ---------------------- |
| `istio.security.apiVersion` | The apiVersion used for the Istio security resources (e.g. PeerAuthentication) | `security.istio.io/v1` |

### Traffic Exposure Parameters

| Name           | Description                                                             | Value       |
| -------------- | ----------------------------------------------------------------------- | ----------- |
| `service.name` | *Auth* service name. If not set, a name is generated using the fullname | `""`        |
| `service.port` | *Auth* service port                                                     | `8080`      |
| `service.type` | *Auth* service port                                                     | `ClusterIP` |

### Host(s) Parameters - Contains host information for applications deployed via *telicent-core* chart.

*Auth* interacts directly with other Telicent Applications using their default service/serviceAccount and port.
If either of those details changes, you can use this section to correctly refer to those applications.

| Name                          | Description                                                                                                                                                                                                                          | Value                         |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------- |
| `hosts.enableAutoCorrect`     | Allow for the release name to be automatically pre-fixed to each host value when required (default behavior when installing through the parent chart). Alternatively, the host value will be used as it is, without any modification | `true`                        |
| `hosts.traefikProxy`          | Traefik Proxy application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                            | `traefik-proxy:8080`          |
| `hosts.userPreferences`       | User Preferences host value, If not set a host is generated using service:'user-preferences',port:'8080' and Release namespace & name                                                                                                | `user-preferences:8080`       |
| `hosts.search`                | Search application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                                   | `search:8080`                 |
| `hosts.graph`                 | Graph application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                                    | `graph:8080`                  |
| `hosts.deletionWorker`        | Deletion Worker application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                          | `deletion-worker:8080`        |
| `hosts.statusApi`             | Status Api default host value, as defined by 'service/serviceAccount:port'                                                                                                                                                           | `status:8080`                 |
| `hosts.distributionLifecycle` | Distribution Lifecycle application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                   | `distribution-lifecycle:8080` |
| `hosts.catalogue`             | Catalogue API host value, as defined by 'service/serviceAccount:port'                                                                                                                                                                | `catalogue-api:8080`          |

### Host(s) Preview Parameters - Contains host information for applications deployed via *telicent-preview* chart

Host values will be used as defined in this section, release name cannot be autocorrected, as the release name is unknown.

| Name                                  | Description                                                                                                                                              | Value                          |
| ------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------ |
| `hostsPreview.enableAutoCorrect`      | Prefix 'global.releaseNameTelicentPreview' value to each host value. Alternatively, the host value will be used as it is, without any modification       | `true`                         |
| `hostsPreview.paperbackWriter`        | Paperback Writer application host value, as defined by 'service/serviceAccount:port'                                                                     | `paperback-writer:8080`        |
| `hostsPreview.aiSparqlBuilder`        | AI SPARQL Builder application host value, as defined by 'service/serviceAccount:port'                                                                    | `ai-sparql-builder:8080`       |
| `hostsPreview.notifications`          | Notifications application host value, as defined by 'service/serviceAccount:port'                                                                        | `notifications:8080`           |
| `hostsPreview.notificationsProjector` | Notifications Projector application host value, as defined by 'service/serviceAccount:port'                                                              | `notifications-projector:8080` |
| `hostsPreview.apicurio`               | Apicurio application host value, as defined by 'service/serviceAccount:port'                                                                             | `apicurio:8080`                |
| `hostsPreview.apiBuilder`             | API Builder API default host value, as defined by 'service/serviceAccount:port'                                                                          | `api-builder:8000`             |
| `hostsPreview.theManagement`          | The Management API default host value, as defined by 'service/serviceAccount:port'                                                                       | `the-management:8000`          |
| `hostsPreview.pdp`                    | ABAC PDP (chart telicent-pdp, released as abac-pdp) default host value, as defined by 'service/serviceAccount:port'. Forwards user tokens to /userinfo   | `abac-pdp:3001`                |
| `hostsPreview.erApi`                  | Entity Resolution API (release entity-resolution-api) default host value, as defined by 'service/serviceAccount:port'. Forwards user tokens to /userinfo | `entity-resolution-api:8080`   |
| `hostsPreview.statusApi`              | Status default host value, as defined by 'service/serviceAccount:port'. Forwards user tokens to /userinfo                                                | `status:8080`                  |

## Helm Unit Tests
The `Unit Tests for Helm Chart` workflow runs `helm unittest` against the chart to run all the `*_test.yaml` files founder under `charts/auth/tests`.

## Deployment 
### Tests
| Test | Area | What it checks | 
|---|---|---| 
| Should create a Deployment | Basic rendering | Template renders and produces a `Deployment` kind | 
| Should use global imagePullSecrets when set | Pull secrets | `global.imagePullSecrets` appears in `imagePullSecrets[0].name` | 
| Should fall back to image.pullSecrets when global is not set | Pull secrets | `image.pullSecrets` used when `global` is unset | 
| Should build the image from registry, repository and tag | Image | Full `<registry>/<repo>:<tag>` string built correctly | 
| Should fall back to Chart.AppVersion when image.tag is not set | Image | Tag falls back to `Chart.AppVersion` when `image.tag` omitted | 
| Should set the imagePullPolicy from values | Image | `image.pullPolicy` passed through to container |
| Should set a checksum/config annotation| Checksum | `checksum/config` annotation matches a valid sha256 hex pattern | 
| Should set a checksum/secret annotation | Checksum | `checksum/secret` annotation matches a valid sha256 hex pattern  | 
| Should default the pod securityContext| Security | Full `spec.template.spec.securityContext` matches chart defaults (`fsGroup`, `runAsUser`, `runAsGroup` = 185, `runAsNonRoot: true`, `seccompProfile.type: RuntimeDefault`) | 
| Should default the container securityContext | Security | Full container `securityContext` matches defaults (`allowPrivilegeEscalation: false`, `capabilities.drop: [ALL]`, same user/group/nonroot values, `seccompProfile`) | 
| Should not set prometheus annotations when metrics disabled | Prometheus | Annotations absent when `metrics.enabled: false` | 
| Should set prometheus annotations with defaults when metrics enabled | Prometheus | Annotations added when `metrics.enabled: true`|
| Should leave out resources when not set | Resources | `resources` absent when `.Values.resources` is empty | 
| Should set resources when provided | Resources | Full `requests`/`limits` block passes through values provided| 

## Service 
### Tests
 
| Test | What it checks |
|---|---|
| Should create a Service | Template renders and produces a `Service` kind |
| Should set the service type | `service.type`  Only `ClusterIP` is set in `spec.type` |
| Should set the port name to http | The port's `name` is always `http` |
| Should set the app protocol to http | The port's `appProtocol` is always `http`| 
| Should target the http port | `targetPort` is always `http`| 

## Service Account 
### Tests
 
| Test | What it checks |
|---|---|
| Should create a ServiceAccount when enabled | Template renders a `ServiceAccount` kind (default `serviceAccount.create` is truthy) | 
| Should not create a ServiceAccount when disabled | Setting `serviceAccount.create: false` results in no resources being created |
| Should set automountServiceAccountToken to true | Default `serviceAccount.automount` should show as `true` on `automountServiceAccountToken` |
| Should set automountServiceAccountToken to false | Setting `serviceAccount.automount: false` should show `false` |  

## Config Map
### Tests
 
| Test | What it checks |
|---|---|
| Should create a ConfigMap with the generated name when no existingConfigMap given | Checks that configmap is created following `tc-<chart>-env` name | 
| Should use the existingConfigMap name when given | Checks whether existing configmap can be set |

## Authorization Policies
### Tests

| Test | What it checks |
|---|---|
| Should build the principal from release namespace and service account, not a hardcoded value | Checks that the principal substitutes in the release namespace and service account name correctly when `hosts.enableAutoCorrect` is disabled |
| Should apply release-name autocorrect to the service account when enabled | Checks that when `hosts.enableAutoCorrect` is set to true, the release name is correctly prefixed onto the service account in the principal |
## License

Copyright &copy; 2026 Telicent Limited
