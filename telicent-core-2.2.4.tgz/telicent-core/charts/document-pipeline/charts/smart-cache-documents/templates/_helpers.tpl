{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "smart-cache-documents.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Allow the release namespace to be overridden.
*/}}
{{- define "smart-cache-documents.namespace" -}}
{{- if .Values.namespaceOverride -}}
{{- .Values.namespaceOverride -}}
{{- else -}}
{{- .Release.Namespace -}}
{{- end -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "smart-cache-documents.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "smart-cache-documents.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "smart-cache-documents.labels" -}}
helm.sh/chart: {{ include "smart-cache-documents.chart" . }}
telicent.io/resource: "true"
{{ include "smart-cache-documents.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "smart-cache-documents.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "smart-cache-documents.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "smart-cache-documents.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
*********************
*** HTTP Ingestor ***
*********************
*/}}

{{/*
Fullname
*/}}

{{- define "http-ingester.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "http-ingester"}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "http-ingester.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: http-ingester
{{- end }}

{{/*
Common labels
*/}}
{{- define "http-ingester.labels" -}}
app.kubernetes.io/component: http-ingester
app: http-ingester
{{ include "smart-cache-documents.labels" . }}
{{- end }}

{{/*
*************************
*** Content Extractor ***
*************************
*/}}

{{/*
Fullname
*/}}

{{- define "content-extractor.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "content-extractor"}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "content-extractor.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: content-extractor
{{- end }}

{{/*
Common labels
*/}}
{{- define "content-extractor.labels" -}}
app.kubernetes.io/component: content-extractor
app: content-extractor
{{ include "smart-cache-documents.labels" . }}
{{- end }}

{{/*
***********************
*** Content Indexer ***
***********************
*/}}

{{/*
Fullname
*/}}

{{- define "content-indexer.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "content-indexer"}}
{{- end }}

{{- define "content-indexer.name" -}}
{{ printf "%s-%s" (include "smart-cache-documents.name" .) "content-indexer"}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "content-indexer.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: content-indexer
{{- end }}

{{/*
Common labels
*/}}
{{- define "content-indexer.labels" -}}
app.kubernetes.io/component: content-indexer
app: content-indexer
{{ include "smart-cache-documents.labels" . }}
{{- end }}

{{/*
*************************
*** Catalogue Updater ***
*************************
*/}}

{{/*
Fullname
*/}}

{{- define "catalogue-updater.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "catalogue-updater"}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "catalogue-updater.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: catalogue-updater
{{- end }}

{{/*
Common labels
*/}}
{{- define "catalogue-updater.labels" -}}
app.kubernetes.io/component: catalogue-updater
app: catalogue-updater
{{ include "smart-cache-documents.labels" . }}
{{- end }}

{{/*
**********************
*** Content Tagger ***
**********************
*/}}

{{/*
Fullname
*/}}
{{- define "content-tagger.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "content-tagger "}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "content-tagger.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: content-tagger
{{- end }}

{{/*
Common labels
*/}}
{{- define "content-tagger.labels" -}}
app.kubernetes.io/component: content-tagger
app: content-tagger
{{ include "smart-cache-documents.labels" . }}
{{- end }}

{{/*
************************
*** Entity Extractor ***
************************
*/}}

{{/*
Fullname
*/}}
{{- define "entity-extractor.fullname" -}}
{{ printf "%s-%s" (include "smart-cache-documents.fullname" .) "entity-extractor" }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "entity-extractor.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smart-cache-documents.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: entity-extractor
{{- end }}

{{/*
Common labels
*/}}
{{- define "entity-extractor.labels" -}}
app.kubernetes.io/component: entity-extractor
app: entity-extractor
{{ include "smart-cache-documents.labels" . }}
{{- end }}

{{/*
**************************************
*** Distribution Lifecycle Support ***
**************************************
*/}}

{{/*
Absolute path of the Distribution Lifecycle state file. Every service uses the same path, but each one mounts its own
volume there so that no two processes ever write the same file.
*/}}
{{- define "smart-cache-documents.lifecycleStateFile" -}}
{{- printf "%s/%s" (trimSuffix "/" .Values.distributionLifecycle.persistence.mountPath) .Values.distributionLifecycle.stateFileName }}
{{- end }}

{{/*
Name of the PersistentVolumeClaim holding a service's Distribution Lifecycle state file.
Expects a list of (root context, service component, configured existing claim).
The release prefix is truncated rather than the assembled name so that the service component, which is what makes one
claim distinct from another, always survives the 63 character limit on resource names.
*/}}
{{- define "smart-cache-documents.lifecycleStateClaimName" -}}
{{- $root := index . 0 -}}
{{- $service := index . 1 -}}
{{- $existingClaim := index . 2 -}}
{{- if $existingClaim -}}
{{- $existingClaim -}}
{{- else -}}
{{- $prefix := include "smart-cache-documents.fullname" $root | trunc 29 | trimSuffix "-" -}}
{{- printf "%s-%s-lifecycle-state" $prefix $service -}}
{{- end -}}
{{- end }}

{{- define "http-ingester.lifecycleStateClaimName" -}}
{{- include "smart-cache-documents.lifecycleStateClaimName" (list . "http-ingester" .Values.distributionLifecycle.persistence.existingClaims.httpIngester) }}
{{- end }}

{{- define "content-extractor.lifecycleStateClaimName" -}}
{{- include "smart-cache-documents.lifecycleStateClaimName" (list . "content-extractor" .Values.distributionLifecycle.persistence.existingClaims.contentExtractor) }}
{{- end }}

{{- define "content-indexer.lifecycleStateClaimName" -}}
{{- include "smart-cache-documents.lifecycleStateClaimName" (list . "content-indexer" .Values.distributionLifecycle.persistence.existingClaims.contentIndexer) }}
{{- end }}

{{- define "catalogue-updater.lifecycleStateClaimName" -}}
{{- include "smart-cache-documents.lifecycleStateClaimName" (list . "catalogue-updater" .Values.distributionLifecycle.persistence.existingClaims.catalogueUpdater) }}
{{- end }}

{{/*
Guards against configurations that would allow more than one process to write a lifecycle state file.
*/}}
{{- define "smart-cache-documents.validateDistributionLifecycle" -}}
{{- if and .Values.enabled .Values.distributionLifecycle.routeToNamedGraphs }}
{{- if not .Values.distributionLifecycle.stateFileName }}
{{- fail "distributionLifecycle.stateFileName must be set when distributionLifecycle.routeToNamedGraphs is enabled" }}
{{- end }}
{{- if not .Values.distributionLifecycle.persistence.mountPath }}
{{- fail "distributionLifecycle.persistence.mountPath must be set when distributionLifecycle.routeToNamedGraphs is enabled" }}
{{- end }}
{{- range $service := list "httpIngester" "contentExtractor" "contentIndexer" "catalogueUpdater" }}
{{- if gt (int (index $.Values $service).replicas) 1 }}
{{- fail (printf "distributionLifecycle.routeToNamedGraphs requires %s.replicas to be 1; the Distribution Lifecycle state file cannot be shared between processes" $service) }}
{{- end }}
{{- end }}
{{- $claims := list (include "http-ingester.lifecycleStateClaimName" .) (include "content-extractor.lifecycleStateClaimName" .) (include "content-indexer.lifecycleStateClaimName" .) (include "catalogue-updater.lifecycleStateClaimName" .) }}
{{- if ne (len (uniq $claims)) (len $claims) }}
{{- fail (printf "each service requires its own Distribution Lifecycle volume, but the claims resolved to %s; set distinct distributionLifecycle.persistence.existingClaims, or shorten the release name" (join ", " $claims)) }}
{{- end }}
{{- end }}
{{- end }}
