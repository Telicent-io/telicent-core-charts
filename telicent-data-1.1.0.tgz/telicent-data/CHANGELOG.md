# Changelog

## [1.1.0](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v1.0.1...telicent-data-v1.1.0) (2026-10-05)


### Features

* add canonicals-entity umbrella chart ([#724](https://github.com/Telicent-io/telicent-core-charts/issues/724)) ([0284582](https://github.com/Telicent-io/telicent-core-charts/commit/0284582eb67d8f2d6f449b24ba9e8b3ba895e11a))
* add charts to canonicals-entity umbrella chart ([#727](https://github.com/Telicent-io/telicent-core-charts/issues/727)) ([a016d9c](https://github.com/Telicent-io/telicent-core-charts/commit/a016d9c7ae5b77de387cfe5446c3bc85fcd42a2b))
* update telicent-data chart versions ([#731](https://github.com/Telicent-io/telicent-core-charts/issues/731)) ([e2d5767](https://github.com/Telicent-io/telicent-core-charts/commit/e2d57670f9f092bf7fc088b92e7e2fd0020417d3))

## [1.0.1](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v1.0.0...telicent-data-v1.0.1) (2026-09-01)


### Dependencies

* update can events ([#707](https://github.com/Telicent-io/telicent-core-charts/issues/707)) ([f380ecc](https://github.com/Telicent-io/telicent-core-charts/commit/f380ecc779218ca98a66cf317ca075558b8b5ab0))

## [1.0.0](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.9...telicent-data-v1.0.0) (2026-08-19)


### ⚠ BREAKING CHANGES

* first stable release; mapper and producer subcharts move to their Telicent Core 2.0.0 versions.

### Features

* release telicent-data 1.0.0 ([#689](https://github.com/Telicent-io/telicent-core-charts/issues/689)) ([9d53491](https://github.com/Telicent-io/telicent-core-charts/commit/9d5349198d59a24dbd10e1e54ee4ca122df3c80f))

## [0.3.9](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.8...telicent-data-v0.3.9) (2026-08-19)


### Bug Fixes

* make acled togglable ([#686](https://github.com/Telicent-io/telicent-core-charts/issues/686)) ([548da8d](https://github.com/Telicent-io/telicent-core-charts/commit/548da8dfd565e010be37068d031c7953133a97cf))

## [0.3.8](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.7...telicent-data-v0.3.8) (2026-08-14)


### Features

* new canonicals ontology chart ([#678](https://github.com/Telicent-io/telicent-core-charts/issues/678)) ([5e1369a](https://github.com/Telicent-io/telicent-core-charts/commit/5e1369a86c9241008f7fdd22e4c3385ec7158c69))

## [0.3.7](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.7...telicent-data-v0.3.7) (2026-07-07)


### Bug Fixes

* Add a new `canonicals-event` umbrella chart. ([#637](https://github.com/Telicent-io/telicent-core-charts/issues/637)) ([45f0475](https://github.com/Telicent-io/telicent-core-charts/commit/45f0475f0281b7221b28f0cb46f7f156899b1855))
* add enableSourceRefMode to mapper ([e439d94](https://github.com/Telicent-io/telicent-core-charts/commit/e439d940eb7cb9cd2a21a4fc7c581c09f034ddc4))
* add enableSourceRefMode to mapper ([3b77660](https://github.com/Telicent-io/telicent-core-charts/commit/3b77660721cd02ba9c71c49116d6528c5b48d0a4))
* add new environment variables ([da9510e](https://github.com/Telicent-io/telicent-core-charts/commit/da9510e981b227caecb8782c043731a9fdff48c4))
* bump data chart ([04dd4b9](https://github.com/Telicent-io/telicent-core-charts/commit/04dd4b9b00b7a1fccee8f06311debe86f2ae9573))
* make host domain values required ([69ac812](https://github.com/Telicent-io/telicent-core-charts/commit/69ac812caf209346986d38997cc27391cc61d46d))
* removes all default resources and limits ([0a5d96d](https://github.com/Telicent-io/telicent-core-charts/commit/0a5d96dd5060c6c35ead510a3dc7daadf8bd095a))
* removes all default resources and limits ([033bdc7](https://github.com/Telicent-io/telicent-core-charts/commit/033bdc7998cbe455d91fbf9849fa07e23ce16fbb))
* update app versions ([42620d6](https://github.com/Telicent-io/telicent-core-charts/commit/42620d61d9f5c20ef48c165c37f1ca31531496cd))
* update app versions ([9ff9491](https://github.com/Telicent-io/telicent-core-charts/commit/9ff9491c733d6e961f3f75453abf01a0112ab17e))
* use single demo-prereqs chart ([98a5531](https://github.com/Telicent-io/telicent-core-charts/commit/98a55316a5a7102fd9b0f13a3a9fbefa1e4e8e0b))


### Miscellaneous Chores

* relase 0.3.6 ([#538](https://github.com/Telicent-io/telicent-core-charts/issues/538)) ([434d75c](https://github.com/Telicent-io/telicent-core-charts/commit/434d75c915cae340e0296e8ccac60b69a5adcf77))
* Release telicent-data 0.3.7 ([#643](https://github.com/Telicent-io/telicent-core-charts/issues/643)) ([88142e0](https://github.com/Telicent-io/telicent-core-charts/commit/88142e0e6294b3f442cd7a0ca280ebbfbcb3cf6a))
* Release telicent-data 0.3.7 ([#645](https://github.com/Telicent-io/telicent-core-charts/issues/645)) ([184290d](https://github.com/Telicent-io/telicent-core-charts/commit/184290d41d67eac270be61315de60556d5f85cba))
* Release telicent-data 0.3.7 ([#650](https://github.com/Telicent-io/telicent-core-charts/issues/650)) ([1e197b4](https://github.com/Telicent-io/telicent-core-charts/commit/1e197b490a1c3bdcc808d33089ca5a9133887e2f))
* Release telicent-data 1.3.1 ([#648](https://github.com/Telicent-io/telicent-core-charts/issues/648)) ([ef2a24c](https://github.com/Telicent-io/telicent-core-charts/commit/ef2a24c2cfb9dcab1f00f845b02af14c23ea2fbf))

## [0.3.7](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v1.3.1...telicent-data-v0.3.7) (2026-07-07)


### Bug Fixes

* Add a new `canonicals-event` umbrella chart. ([#637](https://github.com/Telicent-io/telicent-core-charts/issues/637)) ([45f0475](https://github.com/Telicent-io/telicent-core-charts/commit/45f0475f0281b7221b28f0cb46f7f156899b1855))
* add enableSourceRefMode to mapper ([e439d94](https://github.com/Telicent-io/telicent-core-charts/commit/e439d940eb7cb9cd2a21a4fc7c581c09f034ddc4))
* add enableSourceRefMode to mapper ([3b77660](https://github.com/Telicent-io/telicent-core-charts/commit/3b77660721cd02ba9c71c49116d6528c5b48d0a4))
* add new environment variables ([da9510e](https://github.com/Telicent-io/telicent-core-charts/commit/da9510e981b227caecb8782c043731a9fdff48c4))
* bump data chart ([04dd4b9](https://github.com/Telicent-io/telicent-core-charts/commit/04dd4b9b00b7a1fccee8f06311debe86f2ae9573))
* make host domain values required ([69ac812](https://github.com/Telicent-io/telicent-core-charts/commit/69ac812caf209346986d38997cc27391cc61d46d))
* removes all default resources and limits ([0a5d96d](https://github.com/Telicent-io/telicent-core-charts/commit/0a5d96dd5060c6c35ead510a3dc7daadf8bd095a))
* removes all default resources and limits ([033bdc7](https://github.com/Telicent-io/telicent-core-charts/commit/033bdc7998cbe455d91fbf9849fa07e23ce16fbb))
* update app versions ([42620d6](https://github.com/Telicent-io/telicent-core-charts/commit/42620d61d9f5c20ef48c165c37f1ca31531496cd))
* update app versions ([9ff9491](https://github.com/Telicent-io/telicent-core-charts/commit/9ff9491c733d6e961f3f75453abf01a0112ab17e))
* use single demo-prereqs chart ([98a5531](https://github.com/Telicent-io/telicent-core-charts/commit/98a55316a5a7102fd9b0f13a3a9fbefa1e4e8e0b))


### Miscellaneous Chores

* relase 0.3.6 ([#538](https://github.com/Telicent-io/telicent-core-charts/issues/538)) ([434d75c](https://github.com/Telicent-io/telicent-core-charts/commit/434d75c915cae340e0296e8ccac60b69a5adcf77))
* Release telicent-data 0.3.7 ([#643](https://github.com/Telicent-io/telicent-core-charts/issues/643)) ([88142e0](https://github.com/Telicent-io/telicent-core-charts/commit/88142e0e6294b3f442cd7a0ca280ebbfbcb3cf6a))
* Release telicent-data 0.3.7 ([#645](https://github.com/Telicent-io/telicent-core-charts/issues/645)) ([184290d](https://github.com/Telicent-io/telicent-core-charts/commit/184290d41d67eac270be61315de60556d5f85cba))
* Release telicent-data 0.3.7 ([#650](https://github.com/Telicent-io/telicent-core-charts/issues/650)) ([1e197b4](https://github.com/Telicent-io/telicent-core-charts/commit/1e197b490a1c3bdcc808d33089ca5a9133887e2f))
* Release telicent-data 1.3.1 ([#648](https://github.com/Telicent-io/telicent-core-charts/issues/648)) ([ef2a24c](https://github.com/Telicent-io/telicent-core-charts/commit/ef2a24c2cfb9dcab1f00f845b02af14c23ea2fbf))

## [1.3.1](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.7...telicent-data-v1.3.1) (2026-07-07)


### Miscellaneous Chores

* Release telicent-data 1.3.1 ([#648](https://github.com/Telicent-io/telicent-core-charts/issues/648)) ([ef2a24c](https://github.com/Telicent-io/telicent-core-charts/commit/ef2a24c2cfb9dcab1f00f845b02af14c23ea2fbf))

## [0.3.7](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.7...telicent-data-v0.3.7) (2026-07-07)


### Miscellaneous Chores

* Release telicent-data 0.3.7 ([#645](https://github.com/Telicent-io/telicent-core-charts/issues/645)) ([184290d](https://github.com/Telicent-io/telicent-core-charts/commit/184290d41d67eac270be61315de60556d5f85cba))

## [0.3.7](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.7...telicent-data-v0.3.7) (2026-07-07)


### Bug Fixes

* Add a new `canonicals-event` umbrella chart. ([#637](https://github.com/Telicent-io/telicent-core-charts/issues/637)) ([45f0475](https://github.com/Telicent-io/telicent-core-charts/commit/45f0475f0281b7221b28f0cb46f7f156899b1855))
* add enableSourceRefMode to mapper ([e439d94](https://github.com/Telicent-io/telicent-core-charts/commit/e439d940eb7cb9cd2a21a4fc7c581c09f034ddc4))
* add enableSourceRefMode to mapper ([3b77660](https://github.com/Telicent-io/telicent-core-charts/commit/3b77660721cd02ba9c71c49116d6528c5b48d0a4))
* add new environment variables ([da9510e](https://github.com/Telicent-io/telicent-core-charts/commit/da9510e981b227caecb8782c043731a9fdff48c4))
* bump data chart ([04dd4b9](https://github.com/Telicent-io/telicent-core-charts/commit/04dd4b9b00b7a1fccee8f06311debe86f2ae9573))
* make host domain values required ([69ac812](https://github.com/Telicent-io/telicent-core-charts/commit/69ac812caf209346986d38997cc27391cc61d46d))
* removes all default resources and limits ([0a5d96d](https://github.com/Telicent-io/telicent-core-charts/commit/0a5d96dd5060c6c35ead510a3dc7daadf8bd095a))
* removes all default resources and limits ([033bdc7](https://github.com/Telicent-io/telicent-core-charts/commit/033bdc7998cbe455d91fbf9849fa07e23ce16fbb))
* update app versions ([42620d6](https://github.com/Telicent-io/telicent-core-charts/commit/42620d61d9f5c20ef48c165c37f1ca31531496cd))
* update app versions ([9ff9491](https://github.com/Telicent-io/telicent-core-charts/commit/9ff9491c733d6e961f3f75453abf01a0112ab17e))
* use single demo-prereqs chart ([98a5531](https://github.com/Telicent-io/telicent-core-charts/commit/98a55316a5a7102fd9b0f13a3a9fbefa1e4e8e0b))


### Miscellaneous Chores

* relase 0.3.6 ([#538](https://github.com/Telicent-io/telicent-core-charts/issues/538)) ([434d75c](https://github.com/Telicent-io/telicent-core-charts/commit/434d75c915cae340e0296e8ccac60b69a5adcf77))
* Release telicent-data 0.3.7 ([#643](https://github.com/Telicent-io/telicent-core-charts/issues/643)) ([88142e0](https://github.com/Telicent-io/telicent-core-charts/commit/88142e0e6294b3f442cd7a0ca280ebbfbcb3cf6a))

## [0.3.7](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.6...telicent-data-v0.3.7) (2026-07-06)


### Bug Fixes

* Add a new `canonicals-event` umbrella chart. ([#637](https://github.com/Telicent-io/telicent-core-charts/issues/637)) ([45f0475](https://github.com/Telicent-io/telicent-core-charts/commit/45f0475f0281b7221b28f0cb46f7f156899b1855))
* use single demo-prereqs chart ([98a5531](https://github.com/Telicent-io/telicent-core-charts/commit/98a55316a5a7102fd9b0f13a3a9fbefa1e4e8e0b))

## [0.3.6](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.5...telicent-data-v0.3.6) (2026-03-24)


### Miscellaneous Chores

* relase 0.3.6 ([#538](https://github.com/Telicent-io/telicent-core-charts/issues/538)) ([434d75c](https://github.com/Telicent-io/telicent-core-charts/commit/434d75c915cae340e0296e8ccac60b69a5adcf77))

## [0.3.5](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.4...telicent-data-v0.3.5) (2026-03-04)


### Bug Fixes

* add enableSourceRefMode to mapper ([e439d94](https://github.com/Telicent-io/telicent-core-charts/commit/e439d940eb7cb9cd2a21a4fc7c581c09f034ddc4))
* add enableSourceRefMode to mapper ([3b77660](https://github.com/Telicent-io/telicent-core-charts/commit/3b77660721cd02ba9c71c49116d6528c5b48d0a4))

## [0.3.4](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.3...telicent-data-v0.3.4) (2026-02-04)


### Bug Fixes

* update app versions ([42620d6](https://github.com/Telicent-io/telicent-core-charts/commit/42620d61d9f5c20ef48c165c37f1ca31531496cd))
* update app versions ([9ff9491](https://github.com/Telicent-io/telicent-core-charts/commit/9ff9491c733d6e961f3f75453abf01a0112ab17e))

## [0.3.3](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.2...telicent-data-v0.3.3) (2026-02-02)


### Bug Fixes

* add new environment variables ([da9510e](https://github.com/Telicent-io/telicent-core-charts/commit/da9510e981b227caecb8782c043731a9fdff48c4))
* make host domain values required ([69ac812](https://github.com/Telicent-io/telicent-core-charts/commit/69ac812caf209346986d38997cc27391cc61d46d))
* removes all default resources and limits ([0a5d96d](https://github.com/Telicent-io/telicent-core-charts/commit/0a5d96dd5060c6c35ead510a3dc7daadf8bd095a))
* removes all default resources and limits ([033bdc7](https://github.com/Telicent-io/telicent-core-charts/commit/033bdc7998cbe455d91fbf9849fa07e23ce16fbb))

## [0.3.2](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.1...telicent-data-v0.3.2) (2026-01-20)


### Bug Fixes

* bump data chart ([04dd4b9](https://github.com/Telicent-io/telicent-core-charts/commit/04dd4b9b00b7a1fccee8f06311debe86f2ae9573))

## [0.3.1](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.3.0...telicent-data-v0.3.1) (2025-12-16)


### Bug Fixes

* incorrect default source name ([983cea4](https://github.com/Telicent-io/telicent-core-charts/commit/983cea47d86bcde5f7a9631306484c3c2caf830c))
* Remove dpuplcate 'ies-' from source name configuration value. ([419ef0d](https://github.com/Telicent-io/telicent-core-charts/commit/419ef0de9592a993bed6645ae564ffca0aac86a1))
* Remove duplicate 'ies-' from source name configuration value. ([a117a6e](https://github.com/Telicent-io/telicent-core-charts/commit/a117a6edf271536454fb6185117b950eabea06fa))

## [0.3.0](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.2.0...telicent-data-v0.3.0) (2025-11-03)


### Features

* adds canonical-ontology ([6cc4059](https://github.com/Telicent-io/telicent-core-charts/commit/6cc40591da087bc29c0ab2cb602cd1ef3b7a97de))
* adds canonical-ontology ([0a3d299](https://github.com/Telicent-io/telicent-core-charts/commit/0a3d29917ebe5b97b266176959a3c1067c5f75ed))

## [0.2.0](https://github.com/Telicent-io/telicent-core-charts/compare/telicent-data-v0.1.0...telicent-data-v0.2.0) (2025-10-29)


### Features

* adds acled and canonicals ([3244782](https://github.com/Telicent-io/telicent-core-charts/commit/3244782c3de0a6590cad87a5d6bf3a282e188d2a))
* ies, rdf producers added ([f5ef457](https://github.com/Telicent-io/telicent-core-charts/commit/f5ef4571634d447ff89fa00e2d95941c48b271c0))
