# Changelog

## [0.1.3](https://github.com/Telicent-io/telicent-traefik/compare/v0.1.2...v0.1.3) (2026-08-27)


### Miscellaneous Chores

* release 0.1.3 ([7315f25](https://github.com/Telicent-io/telicent-traefik/commit/7315f25fcbeed5a16f665f60dcbf5af6cb940cea))

## [0.1.2](https://github.com/Telicent-io/telicent-traefik/compare/v0.1.1...v0.1.2) (2026-08-27)


### Features

* initial traefik deployment ([a01e708](https://github.com/Telicent-io/telicent-traefik/commit/a01e70880bda44da0ec5ed3ff6c7f925b129796d))
