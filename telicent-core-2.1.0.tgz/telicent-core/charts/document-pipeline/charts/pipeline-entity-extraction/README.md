# Telicent Package for Document Pipeline

Document Pipeline is a document processing pipeline made up of four loosely coupled microservices, each performing a different function but sharing data via Kafka topics.

Native documents, such as Microsoft Word or PDF files, are ingested into the pipeline either via the HTTP Ingester microservice, or via direct submission to Kafka, and then flow through the pipeline, ultimately having their content indexed and searchable within Elasticsearch.

## Introduction

This chart bootstraps Telicent Document Pipeline deployment on a [Kubernetes](https://kubernetes.io) cluster using
the [Helm](https://helm.sh) package manager.

## Umbrella chart 

To enable this chart as part of the umbrella chart, please set the key: `.Values.pipeline-entity-extraction.enabled: true`

## Prerequisites

- Kubernetes 1.23+
- Helm 3.9+

## Installing the Chart

To install the chart with the release name `my-release`:

```console
helm install my-release ./charts/telicent-core/charts/pipeline-entity-extraction
```

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```console
helm delete my-release
```
The command removes all the Kubernetes components associated with the chart and deletes the release.

## Automating README and schema generation

```bash
.dev/readme-generator-for-helm --config=charts/telicent-core/readme.config \
 --values=charts/telicent-core/charts/pipeline-entity-extraction/values.yaml \
 --readme=charts/telicent-core/charts/pipeline-entity-extraction/README.md \
 --schema=charts/telicent-core/charts/pipeline-entity-extraction/values.schema.json
```

## Configuration and installation details

### Resource requests and limits

These are inside the `resources` value (check parameter table). Setting requests is essential for production workloads
and these should be adapted to your specific use case.

### Sidecars and Init Containers

If you have a need for additional containers to run within the same pod (e.g. an additional metrics or logging
exporter), you can do so via the `sidecars` config parameter.
Define your container according to the Kubernetes container spec.

```yaml
sidecars:
- name: your-image-name
  image: your-image
  imagePullPolicy: Always
  ports:
  - name: portname
    containerPort: 1234
```

Similarly, you can add extra init containers using the `initContainers` parameter.

```yaml
initContainers:
- name: your-image-name
  image: your-image
  imagePullPolicy: Always
  ports:
  - name: portname
    containerPort: 1234
```

### Setting Pod's affinity

This chart allows you to set your custom affinity using the `affinity` parameter.
Find more information about Pod's affinity in
the [kubernetes documentation](https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity).

## Parameters

### Global Parameters

Contains global parameters; these parameters are mirrored within the Telicent core umbrella chart
Note: Only global parameters used within this chart will be listed below

| Name                                    | Description                                                                                                                                                                                                                          | Value                                          |
| --------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------- |
| `global.imageRegistry`                  | Global image registry                                                                                                                                                                                                                | `""`                                           |
| `global.imagePullSecrets`               | Global registry secret names as an array                                                                                                                                                                                             | `[]`                                           |
| `global.appHostDomain`                  | Domain associated with Telicent application/ui services. This value cannot be changed after it is set                                                                                                                                | `""`                                           |
| `global.apiHostDomain`                  | Domain associated with Telicent Api services. This value cannot be changed after it is set                                                                                                                                           | `""`                                           |
| `global.authHostDomain`                 | Domain associated with Telicent authentication services, including OIDC providers. This value cannot be changed after it is set                                                                                                      | `""`                                           |
| `global.kafka.bootstrapServers`         | Comma separated list containing Kafka bootstrap servers                                                                                                                                                                              | `kafka-bootstrap.kafka.svc.cluster.local:9092` |
| `global.kafka.existingConfigSecretName` | Name of an existing secret containing Kafka configuration (preferred over individual settings below for security)                                                                                                                    | `""`                                           |
| `global.kafka.username`                 | Username for Kafka authentication                                                                                                                                                                                                    | `your.kafka.username.here`                     |
| `global.kafka.password`                 | Password for Kafka authentication                                                                                                                                                                                                    | `your.kafka.password.here`                     |
| `global.kafka.protocol`                 | Protocol used for Kafka communication                                                                                                                                                                                                | `SASL_SSL`                                     |
| `global.kafka.mechanism`                | SASL mechanism used for Kafka authentication                                                                                                                                                                                         | `SCRAM-SHA-512`                                |
| `global.truststore.existingSecret`      | Name of an existing secret containing the truststore                                                                                                                                                                                 | `""`                                           |
| `global.truststore.mountPath`           | The mount path for the truststore in the container                                                                                                                                                                                   | `/app/config/truststore`                       |
| `hosts.enableAutoCorrect`               | Allow for the release name to be automatically pre-fixed to each host value when required (default behavior when installing through the parent chart). Alternatively, the host value will be used as it is, without any modification | `true`                                         |
| `hosts.auth`                            | Auth application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                                     | `auth:8080`                                    |
| `hosts.traefikProxy`                    | Traefik Proxy application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                            | `traefik-proxy:8080`                           |

### *Entity Extractor* - Application Parameters - Topics

| Name                     | Description                                                                                                                                                                                                                                                          | Value                      |
| ------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------- |
| `topics.inputTopic`      | The Kafka topic from which the content tagger will consume messages                                                                                                                                                                                                  | `document.textandmetadata` |
| `topics.outputTopic`     | The Kafka topic to which the content tagger will produce                                                                                                                                                                                                             | `document.entities`        |
| `topics.kafkaConfigMode` | The configuration mode for Kafka, either 'basic' or 'toml'                                                                                                                                                                                                           | `toml`                     |
| `maxContentChars`        | Maximum document content length in characters; longer documents are sent to the dead letter queue and skipped. The default is sized for a 1792Mi memory limit -- if you raise it, raise resources.limits.memory in proportion (roughly 4.5MiB per 1,000 characters). | `100000`                   |

### *Entity Extractor* - Common Parameters

| Name               | Description                                        | Value |
| ------------------ | -------------------------------------------------- | ----- |
| `nameOverride`     | Override the chart name for the *Entity Extractor* | `""`  |
| `fullnameOverride` | Override the full name for the *Entity Extractor*  | `""`  |

### *Entity Extractor* - Deployment Parameters

| Name                       | Description                                                                                                         | Value                                          |
| -------------------------- | ------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| `replicas`                 | Number of replicas to deploy                                                                                        | `1`                                            |
| `annotations`              | Add extra annotations to the deployment object                                                                      | `{}`                                           |
| `podLabels`                | Labels to add to the *Entity Extractor* pods                                                                        | `{}`                                           |
| `podAnnotations`           | Annotations to add to the *Entity Extractor* pods                                                                   | `{}`                                           |
| `extraEnvVars`             | Array with extra environment variables to add                                                                       | `[]`                                           |
| `extraVolumes`             | Additional volumes for the *Entity Extractor*                                                                       | `[]`                                           |
| `extraVolumeMounts`        | Additional volume mounts for the *Entity Extractor*                                                                 | `[]`                                           |
| `initContainers`           | Add init containers to the pod                                                                                      | `[]`                                           |
| `sidecars`                 | Add sidecars to the pod.                                                                                            | `[]`                                           |
| `image.registry`           | *Entity Extractor* image registry                                                                                   | `quay.io`                                      |
| `image.repository`         | The container image repository for the *Entity Extractor*                                                           | `telicent/telicent-pipeline-entity-extraction` |
| `image.tag`                | The image tag for the *Entity Extractor*                                                                            | `""`                                           |
| `image.pullPolicy`         | The image pull policy for the *Entity Extractor*                                                                    | `IfNotPresent`                                 |
| `image.pullSecrets`        | Secrets for pulling an image from a private repository                                                              | `[]`                                           |
| `affinity`                 | Affinity rules for the *Entity Extractor* pods                                                                      | `{}`                                           |
| `nodeSelector`             | Node selector for the *Entity Extractor* pods                                                                       | `{}`                                           |
| `tolerations`              | Tolerations for the *Entity Extractor* pods                                                                         | `[]`                                           |
| `resources`                | Resources for *Entity Extractor* containers                                                                         | `{}`                                           |
| `podSecurityContext`       | Security context for the pod(s). Optional override, otherwise inherited from the root security context definition   | `{}`                                           |
| `containerSecurityContext` | Security context for the container(s). Optional override, otherwise inherited from root security context definition | `{}`                                           |

### Service Account

This section builds out the service account more information can be found here: https://kubernetes.io/docs/concepts/security/service-accounts/

| Name                         | Description                                                                                                            | Value  |
| ---------------------------- | ---------------------------------------------------------------------------------------------------------------------- | ------ |
| `serviceAccount.create`      | Specifies whether a service account should be created                                                                  | `true` |
| `serviceAccount.automount`   | Automatically mount a ServiceAccount's API credentials                                                                 | `true` |
| `serviceAccount.annotations` | Annotations to add to the service account                                                                              | `{}`   |
| `serviceAccount.name`        | The name of the service account to use. If not set and create is true, a name is generated using the fullname template | `""`   |


## License

Copyright &copy; 2026 Telicent Limited
