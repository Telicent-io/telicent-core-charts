{{/*
Copyright (C) 2025 Telicent Limited
*/}}

{{- define "graph.fuseki" -}}
    PREFIX :        <#>
    PREFIX fuseki:  <http://jena.apache.org/fuseki#>
    PREFIX rdf:     <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX rdfs:    <http://www.w3.org/2000/01/rdf-schema#>
    PREFIX ja:      <http://jena.hpl.hp.com/2005/11/Assembler#>
    PREFIX authz:   <http://telicent.io/security#>
    PREFIX cqrs:    <http://telicent.io/cqrs#>
    PREFIX graphql: <https://telicent.io/fuseki/modules/graphql#>
    ## ---- Fuseki-Kafka connector
    PREFIX fk:      <http://jena.apache.org/fuseki/kafka#>
    PREFIX tdb2:    <http://jena.apache.org/2016/tdb#>
    [] rdf:type fuseki:Server ;
        ## Disable SERVICE (call out) in SPARQL.
        ja:context [  ja:cxtName "arq:httpServiceAllowed" ; ja:cxtValue "false" ] ;
        ## Data services enabled.
        fuseki:services (
            :knowledgeService
            :ontologyService
            :catalogService
        ) .
    ## --------
    :knowledgeService rdf:type fuseki:Service ;
        # http://host:port/knowledge
        fuseki:name "/knowledge" ;
        fuseki:endpoint [
            # SPARQL query service on "/knowledge/sparql"
            fuseki:operation fuseki:query ;
            fuseki:name "sparql" ;
            ja:context [
                ja:cxtName "arq:queryTimeout" ;
                ja:cxtValue "120000,120000"
            ] ;
        ];
        fuseki:endpoint [
            # SPARQL query service on "/knowledge/query"
            fuseki:operation fuseki:query ;
            fuseki:name "query" ;
            ja:context [
                ja:cxtName "arq:queryTimeout" ;
                ja:cxtValue "120000,120000"
            ] ;
        ] ;
    ## Direct access to out-of-the-box update endpoint not permitted in live environment, use cqrs endpoint
    #    fuseki:endpoint [
    #         # SPARQL update service on "/knowledge/update"
    #        fuseki:operation fuseki:update ;
    #        fuseki:name "update"
    #    ] ;
        ## Updates will be generate an RDF patch which is sent to the Kafka topic.
        ## This exposes update to all users and should only be applied in development environments. Pending access admin/user pools solution.
        fuseki:endpoint [
            # CQRS update service on "/knowledge/update"
            fuseki:operation cqrs:update ;
            # This name (ja:cxtValue) must agree with the connector below.
            ja:context [
                ja:cxtName "kafka:topic" ;
                ja:cxtValue "knowledge"
            ];
            fuseki:name "update"
        ];
        fuseki:endpoint [
            # GraphQL operations
            fuseki:operation graphql:graphql ;
            ja:context [
                ja:cxtName "graphql:executor" ;
                ja:cxtValue "io.telicent.jena.graphql.execution.telicent.graph.TelicentGraphExecutor"
            ] ;
            fuseki:name "graphql"
        ];
        fuseki:endpoint [
            # SPARQL Graph Store Protocol (read) on "/knowledge/get"
            fuseki:operation fuseki:gsp-r ;
            fuseki:name "get"
        ] ;
    ## Direct access to out-of-the-box read/write endpoint not permitted in live environment
    #    fuseki:endpoint [
    #        # SPARQL Graph Store Protcol (read and write) on "/knowledge/data"
    #        fuseki:operation fuseki:gsp-rw ;
    #        fuseki:name "data"
    #    ] ;
        fuseki:endpoint [
            # Authz upload operation on "/knowledge/upload"
            fuseki:operation authz:upload ;
            fuseki:name "upload"
        ] ;
        # Knowledge dataset to use
        fuseki:dataset :datasetAuth ;
        .
    ## Dataset without security labels.
    ## Transactional in-memory dataset.
    # :dataset rdf:type ja:MemoryDataset .
    ## Dataset with security labels / ABAC.
    ## Transactional in-memory dataset.
    :datasetAuth rdf:type authz:DatasetAuthz ;
        ## Config item where labels are stored (only define if not in memory)
        authz:labelsStore [ authz:labelsStorePath "/fuseki/databases/knowledgeLabels.db" ] ;
        authz:dataset :datasetAuthBase;
        authz:tripleDefaultLabels "!";
        ## This substitutes the value of the environment variable
        ## or Java system property "USER_ATTRIBUTES_URL".
        ##
        ##   USER_ATTRIBUTES_URL="http://host:port/users/lookup/{user}"
        ##
        ## {user} is replaced with the URL-safe encoding of the user id.
        ## Local attribute store for dev use only
        # authz:attributes <file:attribute-store.ttl>;
        # ABAC endpoint for user attributes
        ## OLD AUTH APPROACH
        # authz:attributesURL <env:USER_ATTRIBUTES_URL>;
        # authz:hierarchiesURL <env:ATTRIBUTE_HIERARCHY_URL>;
        authz:authServer true;
        .
    ## Storage of data in memory.
    #:datasetAuthBase rdf:type ja:MemoryDataset .
    ## Storage of data on filesystem.
    :datasetAuthBase rdf:type      tdb2:DatasetTDB2 ;
        tdb2:location "/fuseki/databases/knowledge";
        .
    ## --------
    :ontologyService rdf:type fuseki:Service ;
        # http://host:port/ontology
        fuseki:name "/ontology" ;
        fuseki:endpoint [
            # SPARQL query service on ???
            fuseki:operation
            fuseki:query
        ] ;
        fuseki:endpoint [
            # SPARQL query service on "/ontology/sparql"
            fuseki:operation fuseki:query ;
            fuseki:name "sparql"
        ];
        fuseki:endpoint [
            # SPARQL query service on "/ontology/query"
            fuseki:operation fuseki:query ;
            fuseki:name "query"
        ] ;
    ## Direct access to out-of-the-box update endpoint not permitted in live environment, use cqrs endpoint
    #    fuseki:endpoint [
    #         # SPARQL update service on "/ontology/update"
    #        fuseki:operation fuseki:update ;
    #        fuseki:name "update"
    #    ] ;
        ## Updates will be generate an RDF patch which is sent to the Kafka topic.
        ## This exposes update to all users and should only be applied in development environments. Pending access admin/user pools solution.
        fuseki:endpoint [
            # CQRS update service on "/ontology/update"
            fuseki:operation cqrs:update ;
            # This name (ja:cxtValue) must agree with the connector below.
            ja:context [
                ja:cxtName "kafka:topic" ;
                ja:cxtValue "ontology"
            ];
            fuseki:name "update" ] ;
        fuseki:endpoint [
            # GraphQL operations
            fuseki:operation graphql:graphql ;
            ja:context [
                ja:cxtName "graphql:executor" ;
                ja:cxtValue "io.telicent.jena.graphql.execution.telicent.graph.TelicentGraphExecutor"
            ] ;
            fuseki:name "graphql"
        ];
        fuseki:endpoint [
            # SPARQL Graph Store Protocol (read) on "/ontology/get"
            fuseki:operation fuseki:gsp-r ;
            fuseki:name "get"
        ] ;
    ## Direct access to out-of-the-box read/write endpoint not permitted in live environment
    #    fuseki:endpoint [
    #        # SPARQL Graph Store Protcol (read and write) on "/ontology/data"
    #        fuseki:operation fuseki:gsp-rw ;
    #        fuseki:name "data"
    #    ] ;
        fuseki:endpoint [
            # Authz upload operation on "/ontology/upload"
            fuseki:operation authz:upload ;
            fuseki:name "upload"
        ] ;
        # Ontology dataset to use
        fuseki:dataset :ontologyDataset ;
        .
    ## No security labels.
    ## Transactional in-memory dataset.
    #:ontologyDataset rdf:type ja:MemoryDataset ;
        # Optional load with data on start-up
        # ja:data "data1.trig";
        # ja:data "data2.trig";
        #.
    ## With security labels.
    ## --- ABAC dataset
    :ontologyDataset rdf:type authz:DatasetAuthz ;
        ## Config item where labels are stored (only define if not in memory)
        authz:labelsStore [ authz:labelsStorePath "/fuseki/databases/ontologyLabels.db" ] ;
        authz:dataset :datasetOntoBase;
        authz:tripleDefaultLabels "!";
        ## This substitutes the value of the environment variable
        ## or Java system property "USER_ATTRIBUTES_URL".
        ##
        ##   USER_ATTRIBUTES_URL="http://host:port/users/lookup/{user}"
        ##
        ## {user} is replaced with the URL-safe encoding of the user id.
        # Local attribute store for dev
        # authz:attributes <file:attribute-store.ttl>;
        # ABAC endpoint for user attributes
        ## OLD AUTH APPROACH
        # authz:attributesURL <env:USER_ATTRIBUTES_URL>;
        # authz:hierarchiesURL <env:ATTRIBUTE_HIERARCHY_URL>;
        authz:authServer true;
        .
    ## Storage of data in memory.
    #:datasetOntoBase rdf:type ja:MemoryDataset .
    ## Storage of data on filesystem.
    :datasetOntoBase rdf:type tdb2:DatasetTDB2 ;
        tdb2:location "/fuseki/databases/ontology";
        .
    ## --------
    ## 2024-08-21 AshC: Assume we'll need all of this later e.g. CQRS, GraphQL
    :catalogService rdf:type fuseki:Service ;
        # http://host:port/catalog
        fuseki:name "/catalog" ;
        fuseki:endpoint [
            # SPARQL query service on ???
            fuseki:operation
            fuseki:query
        ] ;
        fuseki:endpoint [
            # SPARQL query service on "/catalog/sparql"
            fuseki:operation fuseki:query ;
            fuseki:name "sparql"
        ];
        fuseki:endpoint [
            # SPARQL query service on "/catalog/query"
            fuseki:operation fuseki:query ;
            fuseki:name "query"
        ] ;
    ## Direct access to out-of-the-box update endpoint not permitted in live environment, use cqrs endpoint
    #    fuseki:endpoint [
    #         # SPARQL update service on "/catalog/update"
    #        fuseki:operation fuseki:update ;
    #        fuseki:name "update"
    #    ] ;
        ## Updates will be generate an RDF patch which is sent to the Kafka topic.
        ## This exposes update to all users and should only be applied in development environments. Pending access admin/user pools solution.
        fuseki:endpoint [
            # CQRS update service on "/catalog/update"
            fuseki:operation cqrs:update ;
            # This name (ja:cxtValue) must agree with the connector below.
            ja:context [
                ja:cxtName "kafka:topic" ;
                ja:cxtValue "catalog"
            ];
            fuseki:name "update" ] ;
        fuseki:endpoint [
            # GraphQL operations
            fuseki:operation graphql:graphql ;
            ja:context [
                ja:cxtName "graphql:executor" ;
                ja:cxtValue "io.telicent.jena.graphql.execution.telicent.graph.TelicentGraphExecutor"
            ] ;
            fuseki:name "graphql"
        ];
        fuseki:endpoint [
            # SPARQL Graph Store Protocol (read) on "/catalog/get"
            fuseki:operation fuseki:gsp-r ;
            fuseki:name "get"
        ] ;
    ## Direct access to out-of-the-box read/write endpoint not permitted in live environment
    #    fuseki:endpoint [
    #        # SPARQL Graph Store Protcol (read and write) on "/catalog/data"
    #        fuseki:operation fuseki:gsp-rw ;
    #        fuseki:name "data"
    #    ] ;
        fuseki:endpoint [
            # Authz upload operation on "/catalog/upload"
            fuseki:operation authz:upload ;
            fuseki:name "upload"
        ] ;
        # Catalog dataset to use
        fuseki:dataset :catalogDataset ;
        .
    ## No security labels.
    ## Transactional in-memory dataset.
    #:catalogDataset rdf:type ja:MemoryDataset ;
        # Optional load with data on start-up
        # ja:data "data1.trig";
        # ja:data "data2.trig";
        #.
    ## With security labels.
    ## --- ABAC dataset
    :catalogDataset rdf:type authz:DatasetAuthz ;
        ## Config item where labels are stored (only define if not in memory)
        authz:labelsStore [ authz:labelsStorePath "/fuseki/databases/catalogLabels.db" ] ;
        authz:dataset :datasetCatBase;
        authz:tripleDefaultLabels "!";
        ## This substitutes the value of the environment variable
        ## or Java system property "USER_ATTRIBUTES_URL".
        ##
        ##   USER_ATTRIBUTES_URL="http://host:port/users/lookup/{user}"
        ##
        ## {user} is replaced with the URL-safe encoding of the user id.
        # Local attribute store for dev
        # authz:attributes <file:attribute-store.ttl>;
        # ABAC endpoint for user attributes
        ## OLD AUTH APPROACH
        # authz:attributesURL <env:USER_ATTRIBUTES_URL>;
        # authz:hierarchiesURL <env:ATTRIBUTE_HIERARCHY_URL>;
        authz:authServer true;
        .
    ## Storage of data in memory.
    #:datasetCatBase rdf:type ja:MemoryDataset .
    ## Storage of data on filesystem.
    :datasetCatBase rdf:type tdb2:DatasetTDB2 ;
        tdb2:location "/fuseki/databases/catalog";
        .
    ## --------
    <#connector> rdf:type fk:Connector ;
        fk:bootstrapServers    {{ .Values.global.kafka.bootstrapServers | quote }};
        fk:topic               "knowledge";
        fk:dlqTopic            "knowledge.dlq";
        ## This should refer to an authz:upload endpoint
        fk:fusekiServiceName   "/knowledge/upload";
        ## From 0.90.0 onwards this is mandatory if defining more than one connector
        ## and each connector MUST have a unique Group ID
        fk:groupId "graph-knowledge";
        ## fk:replayTopic -- true for in-memory storage / false for TDB2 storage
        fk:replayTopic      false;
        fk:stateFile        "/fuseki/databases/Replay-RDF.state";
        # Additional Kafka Configuration properties are loaded from a file specified via
        # an environment variable
        # Empty default (the :} at the end) means if this variable is not set then no extra
        # properties are loaded
        fk:configFile       "env:{KAFKA_CONFIG_FILE_PATH:}"
        .
    <#ontologyConnector> rdf:type fk:Connector ;
        fk:bootstrapServers    {{ .Values.global.kafka.bootstrapServers | quote }};
        fk:topic               "ontology";
        fk:dlqTopic            "ontology.dlq";
        ## This should refer to the target dataset
        fk:fusekiServiceName   "/ontology/upload";
        ## From 0.90.0 onwards this is mandatory if defining more than one connector
        ## and each connector MUST have a unique Group ID
        fk:groupId "graph-ontology";
        ## fk:replayTopic -- true for in-memory storage / false for TDB2 storage
        fk:replayTopic      false;
        fk:stateFile        "/fuseki/databases/Replay-Ontology-RDF.state";
        # Additional Kafka Configuration properties are loaded from a file specified via
        # an environment variable
        # Empty default (the :} at the end) means if this variable is not set then no extra
        # properties are loaded
        fk:configFile       "env:{KAFKA_CONFIG_FILE_PATH:}"
        .
    <#catalogConnector> rdf:type fk:Connector ;
        fk:bootstrapServers    {{ .Values.global.kafka.bootstrapServers | quote }};
        fk:topic               "catalog";
        fk:dlqTopic            "catalog.dlq";
        ## This should refer to the target dataset
        fk:fusekiServiceName   "/catalog/upload";
        ## From 0.90.0 onwards this is mandatory if defining more than one connector
        ## and each connector MUST have a unique Group ID
        fk:groupId "graph-catalog";
        ## fk:replayTopic -- true for in-memory storage / false for TDB2 storage
        fk:replayTopic      false;
        fk:stateFile        "/fuseki/databases/Replay-Catalog-RDF.state";
        # Additional Kafka Configuration properties are loaded from a file specified via
        # an environment variable
        # Empty default (the :} at the end) means if this variable is not set then no extra
        # properties are loaded
        fk:configFile       "env:{KAFKA_CONFIG_FILE_PATH:}"
        .

{{- end  -}}
