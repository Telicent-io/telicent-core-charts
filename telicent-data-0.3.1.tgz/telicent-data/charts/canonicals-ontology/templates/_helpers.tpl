{{/*
Expand the name of the chart.
*/}}
{{- define "canonicals-ontology.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "canonicals-ontology.fullname" -}} 
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "canonicals-ontology.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "canonicals-ontology.labels" -}}
helm.sh/chart: {{ include "canonicals-ontology.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Validator Selector labels
*/}}
{{- define "canonicals-ontology-validator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "canonicals-ontology.name" . }}-validator
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Mapper Selector labels
*/}}
{{- define "canonicals-ontology-mapper.selectorLabels" -}}
app.kubernetes.io/name: {{ include "canonicals-ontology.name" . }}-mapper
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "canonicals-ontology.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "canonicals-ontology.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
