# Helm Chart for Telicent Core

Telicent Core is the umbrella chart under which all the subcharts are configured and released.

## Introduction

This chart bootstraps Telicent Core deployment on a [Kubernetes](https://kubernetes.io) cluster using
the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.23+
- Helm 3.8.0+

## Installing the Chart

To install the chart with the release name `my-release`:

```console
helm install my-release ./charts/telicent-core
```

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```console
helm delete my-release
```
The command removes all the Kubernetes components associated with the chart and deletes the release.

## Automating README and schema generation

```bash
.dev/readme-generator-for-helm --config=charts/telicent-core/readme.config \
 --values=charts/telicent-core/values.yaml \
 --readme=charts/telicent-core/README.md \
 --schema=charts/telicent-core/values.schema.json
```

## Configuration and installation details

## Parameters

### Global Parameters - Common

Contains global parameters, these parameters are mirrored across all Telicent Core sub charts, these values will be authoritative.

| Name                                | Description                                                                       | Value                                            |
| ----------------------------------- | --------------------------------------------------------------------------------- | ------------------------------------------------ |
| `global.imageRegistry`              | Global image registry                                                             | `""`                                             |
| `global.imagePullSecrets`           | Global registry secret names as an array                                          | `[]`                                             |
| `global.enterprise`                 | Enable enterprise mode, adding additional features and configurations             | `false`                                          |
| `global.appHostDomain`              | Domain associated with Telicent application services                              | `apps.telicent.io`                               |
| `global.authHostDomain`             | Domain associated with Telicent authentication services, including OIDC providers | `auth.telicent.io`                               |
| `global.groupsClaim`                | Key used to retrieve groups from the OIDC provider                                | `groups`                                         |
| `global.jwksUrl`                    | Endpoint exposing multiple public keys represented as JWKs (JSON Web Key Set)     | `https://{yourAuthdomain}/.well-known/jwks.json` |
| `global.istioNamespace`             | Namespace in which Istio is deployed                                              | `istio-system`                                   |
| `global.istioServiceAccountName`    | Name of the Istio service account                                                 | `istio-ingress`                                  |
| `global.istioGatewayName`           | Name of the Istio Gateway Resource (LB operating at the edge of the mesh)         | `ingress-gateway`                                |
| `global.istioVirtualServiceEnabled` | Enable Istio traffic routing to a named destination service                       | `true`                                           |

### Global Parameters - Kafka

Kafka configuration parameters. These settings will be used by all Telicent Core components that interact
with Kafka, ensuring consistent connectivity and authentication across the platform.

| Name                                    | Description                                               | Value                                          |
| --------------------------------------- | --------------------------------------------------------- | ---------------------------------------------- |
| `global.kafka.bootstrapServers`         | Comma separated list containing Kafka bootstrap servers   | `kafka-bootstrap.kafka.svc.cluster.local:9092` |
| `global.kafka.existingConfigSecretName` | Name of an existing secret containing Kafka configuration | `""`                                           |
| `global.kafka.username`                 | Username for Kafka authentication                         | `your.kafka.username.here`                     |
| `global.kafka.password`                 | Password for Kafka authentication                         | `your.kafka.password.here`                     |
| `global.kafka.protocol`                 | Protocol used for Kafka communication                     | `SASL_SSL`                                     |
| `global.kafka.mechanism`                | SASL mechanism used for Kafka authentication              | `SCRAM-SHA-512`                                |

### Global Parameters - Truststore

Contains global truststore parameters, these parameters are mirrored across Telicent Core sub charts.

| Name                                   | Description                                          | Value                    |
| -------------------------------------- | ---------------------------------------------------- | ------------------------ |
| `global.truststore.existingSecretName` | Name of an existing secret containing the truststore | `""`                     |
| `global.truststore.mountPath`          | The mount path for the truststore in the container   | `/app/config/truststore` |

### Service Account Parameters

| Name                         | Description                                                                           | Value       |
| ---------------------------- | ------------------------------------------------------------------------------------- | ----------- |
| `serviceAccount.name`        | Name of the ServiceAccount to use. If not set, a name is generated using the fullname | `""`        |
| `serviceAccount.annotations` | Additional custom annotations for the ServiceAccount                                  | `{}`        |
| `jobServiceAccountName`      | Service account used for running jobs in Kubernetes.                                  | `producers` |

### Kafka Topics Parameters

| Name                  | Description                                                        | Value   |
| --------------------- | ------------------------------------------------------------------ | ------- |
| `kafkaTopics.enabled` | Enable or disable the creation of Kafka topics during installation | `false` |
| `kafkaTopics.topics`  | List of Kafka topics to be created                                 | `[]`    |

## Subchart configurations

This section contains configurations for the various subcharts included in the Telicent Core chart.
Each subchart can be configured independently, allowing for flexibility in deployment.
They are addressed by their names, and each subchart has its own set of configuration parameters.

| Name | Description | Link |
|------|-------------|------|
| Access | XX | [access](./charts/access/README.md) |
| Access UI | XX | [access-ui](./charts/access-ui/README.md) |
| Data Catalogue | XX | [data-catalog](./charts/data-catalog/README.md) |
| Document Pipeline | XX | [document-pipeline](./charts/document-pipeline/README.md) |
| Graph | XX | [graph](./charts/graph/README.md) |
| Graph UI | XX | [graph-ui](./charts/graph-ui/README.md) |
| Oauth2 Proxy | XX | [oauth2-proxy](./charts/oauth2-proxy/README.md) |
| Paperback Writer | XX | [paperback-writer](./charts/paperback-writer/README.md) |
| Query UI | XX | [query-ui](./charts/query-ui/README.md) |
| Search | XX | [search](./charts/search/README.md) |
| Search Projector | XX | [search-projector](./charts/search-projector/README.md) |
| Search UI | XX | [search-ui](./charts/search-ui/README.md) |
| User Preferences | XX | [user-preferences](./charts/user-preferences/README.md) |

## License

Copyright &copy; 2025 Telicent Limited
