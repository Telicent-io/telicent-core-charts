{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Names of the service(s) and service account(s) this application relies on.
Resolution is delegated to the common.discover* helpers so values resolve
correctly both standalone and under an umbrella chart, where the umbrella's
release name prefixes every sub-chart's service and service account.
*/}}

{{/* entity-resolution-api - returns host ('service:port') and serviceAccount.
     The PDP's caller: it answers the label decisions the API filters on. */}}
{{- define "telicent-pdp.hostEntityResolutionApi" -}}
{{- printf "%s" (include "common.discoverHost" (list . .Values.hosts.entityResolutionApi )) -}}
{{- end -}}
{{- define "telicent-pdp.serviceAccountEntityResolutionApi" -}}
{{- printf "%s" (include "common.discoverServiceAccount" (list . .Values.hosts.entityResolutionApi )) -}}
{{- end -}}
