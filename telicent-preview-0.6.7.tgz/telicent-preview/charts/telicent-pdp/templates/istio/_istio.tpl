{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Returns the principal admitted by the ingress AuthorizationPolicy
*/}}
{{- define "telicent-pdp.ingressPrincipal" -}}
{{- printf "cluster.local/ns/%s/sa/%s" .Release.Namespace ( include "telicent-pdp.serviceAccountEntityResolutionApi" .) -}}
{{- end -}}
