# entity-resolution-api

Selective 1:n entity resolution API with ABAC-first scoring, over the
label-partitioned Delta tables written by the entity-resolution projector.
Person is always on; vehicle and address resolution enable per deployment
(`api.vehicle.*` / `api.address.*` - table and artefact together, or
neither), each bringing its route family, `/v1/capabilities` entry (keyed by
IES class: `ies:Person`, `ies:Vehicle`, `ies:Address`) and MCP tools as one
unit. Versioned REST plus MCP access. Ships two entrypoints in one image:
the API, and the trainer that produces the model artefacts the API serves -
one pass covers every enabled type.

## Operational characteristics

Read this before tuning anything — several defaults here are load-bearing.

- **Filter, then merge, then match.** Every request prunes the Delta table to
  the caller's label partitions before anything is merged or scored; a row
  outside the caller's labels never enters the scoring population at any
  threshold. Nothing merged or scored outlives a request, and nothing is
  cached across callers.

- **`pdp.enabled` is not an ABAC switch.** The PDP answers which label ids a
  caller may see. Turning it off does not serve unfiltered data; it makes
  labels unavailable and the API fails closed with
  `503 label enforcement unavailable` on every request.

- **The API never trains — it serves the trainer's artefact.** No artefact,
  no start. On first boot the `seed-baseline` init container copies the
  image's shipped baseline into place (never overwriting); the trainer
  CronJob replaces it once the table has enough merged rows to train on
  (`trainer.minRows` — below that floor EM produces a degenerate model, not
  a weak one). A retrain lands without a restart: the API re-checks the
  artefact file every `api.artefactTtl` seconds.

- **The artefact is classified at the highest level in the estate.** Its
  term-frequency tables carry literal values (every name, with frequency)
  from every label. It lives on the internal volume or bucket only, is
  written solely by the trainer, and is read solely by the API.

- **There is no quiet-window requirement on `trainer.schedule`.** A training
  pass runs in its own pod and never touches the serving path; the swap is
  one atomic file. Bound `trainer.resources` so a pass can never starve the
  API on a shared node.

- **The Delta table is mounted read-only in the serving container.** The
  projector is the single writer of the table; the trainer writes only the
  artefact. In a normal deployment `persistence.existingClaim` points at the
  projector's claim. For object-store-backed tables set
  `persistence.enabled: false` and point `api.personTablePath` and
  `api.modelArtefactPath` at object-store URIs. Two stores are supported
  and tested: `s3://` (credentials from the pod's IAM role or the AWS env;
  `AWS_ENDPOINT_URL` for an emulator) and `az://container/path` (Azure
  Blob: `AZURE_STORAGE_ACCOUNT_NAME`, optionally `AZURE_STORAGE_ACCOUNT_KEY`
  - unset means workload/managed identity - and for Azurite
  `AZURE_STORAGE_USE_EMULATOR=true` or an `AZURE_STORAGE_ENDPOINT`). Set
  them through `extraEnvVars`. One set of variables configures deltalake,
  DuckDB and the artefact store alike; the DuckDB extensions are baked into
  the image.

- **The table must be the label-partitioned one.** The ABAC filter opens only
  the label directories the caller may see — that partition pruning is what
  makes the filter cheap, and it is verified against both local disk and S3.

- **DuckDB spills to `/tmp`.** The root filesystem is read-only; a merge or
  score that outgrows memory writes to `api.duckdbTempDir` (default
  `/tmp/duckdb`, on the chart's emptyDir). Set `api.duckdbMemoryLimit` a
  little under `resources.limits.memory` so DuckDB spills rather than the
  pod being OOM-killed - its own default is 80% of the node's RAM.

- **An absent table is a normal state, not a fault.** On this event-driven
  platform the API may start before the projector has ever written; requests
  answer empty results and `/health` reports `table_version: null`.

- **`replicas` is 1, and autoscaling is off.** The supported growth path is
  type-sharding — one deployment per entity type — not horizontal
  replication.

- **Memory is the binding resource for the trainer, not the API.** The API
  reads lazily per request; the trainer merges the full table when it
  trains. Size `trainer.resources` against the table, and set API
  `resources` for steady-state serving.

- **`api.logUris` and `api.openDocs` are dev-only.** Both default to the
  secure value; the application logs loudly when either is enabled.

## Installing

```bash
helm install er-api charts/entity-resolution-api \
  --set persistence.existingClaim=<the projector's claim> \
  --set hosts.pdp=telicent-pdp:8081 \
  --set resources.requests.memory=1Gi \
  --set trainer.resources.requests.memory=4Gi
```

## Parameters

### Global parameters

| Name                      | Description                                                                                                                                                                                                                          | Value                |
| ------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------- |
| `global.imageRegistry`    | Global image registry override for umbrella charts                                                                                                                                                                                   | `""`                 |
| `global.imagePullSecrets` | Global image pull secrets override for umbrella charts                                                                                                                                                                               | `[]`                 |
| `global.appHostDomain`    | Domain associated with Telicent application/ui services. This value cannot be changed after it is set                                                                                                                                | `""`                 |
| `global.apiHostDomain`    | Domain associated with Telicent Api services. This value cannot be changed after it is set                                                                                                                                           | `""`                 |
| `global.authHostDomain`   | Domain associated with Telicent authentication services, including OIDC providers. This value cannot be changed after it is set                                                                                                      | `""`                 |
| `global.enabled`          | Enable the entity resolution API deployment                                                                                                                                                                                          | `false`              |
| `hosts.enableAutoCorrect` | Allow for the release name to be automatically pre-fixed to each host value when required (default behavior when installing through the parent chart). Alternatively, the host value will be used as it is, without any modification | `true`               |
| `hosts.auth`              | Auth application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                                     | `auth:8080`          |
| `hosts.pdp`               | Policy Decision Point host value, as defined by 'service/serviceAccount:port'. Owns the label decisions this API filters on                                                                                                          | `telicent-pdp:8081`  |
| `hosts.traefikProxy`      | Traefik Proxy application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                            | `traefik-proxy:8080` |

### Image

| Name                | Description                                                    | Value                            |
| ------------------- | -------------------------------------------------------------- | -------------------------------- |
| `image.registry`    | Container image registry                                       | `quay.io`                        |
| `image.repository`  | Container image repository                                     | `telicent/entity-resolution-api` |
| `image.tag`         | Container image tag (defaults to Chart.appVersion)             | `""`                             |
| `image.digest`      | Image digest (sha256:...) - takes precedence over tag when set | `""`                             |
| `image.pullPolicy`  | Image pull policy                                              | `IfNotPresent`                   |
| `image.pullSecrets` | Image pull secrets (merged with global.imagePullSecrets)       | `[]`                             |

### Replicas

Replicas are stateless: each request prunes, merges and scores in its own
DuckDB connection and keeps nothing afterwards, so replicas share nothing
and need no coordination. Memory is bounded per request by the caller's
visible population, so size `resources` per pod. Type-sharding (one
deployment per entity type) remains the supported growth path - see
"Operational characteristics" in the chart README.

| Name       | Description                                                       | Value |
| ---------- | ----------------------------------------------------------------- | ----- |
| `replicas` | Number of API replicas (ignored when autoscaling.enabled is true) | `1`   |

### API

Settings owned by this service (Settings.from_env in
src/entity_resolution_api/config.py). Auth and PDP settings are owned by
telicent-core-extensions and appear in their own sections below.

| Name                    | Description                                                                                                                                                                                                                                                                     | Value                                 |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------- |
| `api.logLevel`          | Python logging level for the API                                                                                                                                                                                                                                                | `INFO`                                |
| `api.personTablePath`   | Path or object-store URI (s3://, az://) of the person Delta table (sets PERSON_TABLE_PATH; REQUIRED - the API refuses to start without it). Must be the label-partitioned table written by the projector, and must live under persistence.mountPath when persistence is enabled | `/data/er/person`                     |
| `api.uriPrefix`         | Graph namespace prefix used to map URIs to bare ids (sets ER_URI_PREFIX)                                                                                                                                                                                                        | `http://telicent.io/data#`            |
| `api.port`              | Port the API binds (sets ER_API_PORT; must match service.targetPort)                                                                                                                                                                                                            | `8100`                                |
| `api.blocking`          | Enable blocking rules during the wash - trades recall for cost (sets ER_API_BLOCKING)                                                                                                                                                                                           | `false`                               |
| `api.maxMatches`        | Default cap on matches returned per query (sets ER_API_MAX_MATCHES)                                                                                                                                                                                                             | `10`                                  |
| `api.maxBatch`          | Maximum URIs accepted per batch request - a self-DoS guard (sets ER_API_MAX_BATCH)                                                                                                                                                                                              | `50`                                  |
| `api.logUris`           | Log entity URIs instead of redacting them (sets ER_API_LOG_URIS). A URI discloses record existence - dev only                                                                                                                                                                   | `false`                               |
| `api.openDocs`          | Serve /docs, /redoc and /openapi.json unauthenticated (sets ER_API_OPEN_DOCS). Dev only; logs loudly when enabled                                                                                                                                                               | `false`                               |
| `api.allowedOrigins`    | Comma-separated EXACT browser origins allowed to call this API cross-origin (sets ER_API_ALLOWED_ORIGINS). Empty emits no CORS headers at all; wildcards are rejected at startup - credentialed CORS never opens to every site                                                  | `""`                                  |
| `api.modelArtefactPath` | Path or object-store URI (s3://, az://) of the model artefact (sets ER_API_MODEL_ARTEFACT_PATH). REQUIRED - the API never trains; it refuses to start without an artefact. The seedBaseline initContainer puts the shipped baseline here on first boot                          | `/data/er/person-model.artefact.json` |
| `api.artefactTtl`       | Seconds between checks for a replaced artefact - how fast a retrain lands (sets ER_API_ARTEFACT_TTL)                                                                                                                                                                            | `60`                                  |
| `api.duckdbTempDir`     | Directory DuckDB spills to when a merge or score outgrows memory (sets ER_API_DUCKDB_TEMP_DIR). Must be writable: the root filesystem is read-only, /tmp is the chart's emptyDir                                                                                                | `/tmp/duckdb`                         |
| `api.duckdbMemoryLimit` | DuckDB memory cap, e.g. "3GB" (sets ER_API_DUCKDB_MEMORY_LIMIT). Set it below resources.limits.memory so DuckDB spills to disk instead of the pod being OOM-killed; DuckDB's default is 80% of the NODE's RAM                                                                   | `""`                                  |

### Additional entity types

A type is enabled by setting BOTH its tablePath and artefactPath (the API
refuses half a configuration). Its route family, /v1/capabilities entry
and MCP tools all appear together; the trainer covers it in the same
pass; seedBaseline seeds its shipped baseline on first boot.

| Name                          | Description                                                                                                     | Value |
| ----------------------------- | --------------------------------------------------------------------------------------------------------------- | ----- |
| `api.vehicle.tablePath`       | Path/URI of the vehicle Delta table (sets VEHICLE_TABLE_PATH). Empty = vehicle resolution disabled              | `""`  |
| `api.vehicle.artefactPath`    | Path/URI of the vehicle model artefact (sets ER_API_VEHICLE_MODEL_ARTEFACT_PATH)                                | `""`  |
| `api.address.tablePath`       | Path/URI of the address Delta table (sets ADDRESS_TABLE_PATH). Empty = address resolution disabled              | `""`  |
| `api.address.artefactPath`    | Path/URI of the address model artefact (sets ER_API_ADDRESS_MODEL_ARTEFACT_PATH)                                | `""`  |
| `api.rateLimit.requests`      | Requests permitted per window per user (sets ER_API_RATE_LIMIT). Empty disables in-API throttling               | `""`  |
| `api.rateLimit.windowSeconds` | Length of the throttle window in seconds (sets ER_API_RATE_WINDOW)                                              | `""`  |
| `api.rateLimit.mcpRequests`   | Separate per-window allowance for MCP tool calls (sets ER_API_MCP_RATE_LIMIT). MCP calls draw from BOTH buckets | `""`  |

### Auth Server (telicent-core-extensions)

| Name                | Description                                                          | Value           |
| ------------------- | -------------------------------------------------------------------- | --------------- |
| `auth.allowHttp`    | Allow HTTP (non-TLS) connections to auth-server                      | `true`          |
| `auth.jwtIssuer`    | Expected JWT issuer claim                                            | `""`            |
| `auth.jwtAudience`  | Expected JWT audience claim                                          | `telicent_core` |
| `auth.jwtAlgorithm` | JWT signing algorithm (leave empty for default RS256)                | `RS256`         |
| `auth.jwtHeader`    | Request header carrying the user's JWT                               | `Authorization` |
| `auth.jwksUrl`      | JWKS endpoint URL (leave empty to derive from auth-server URL)       | `""`            |
| `auth.requiredRole` | Role required in the JWT (leave empty for the library default, USER) | `""`            |

### PDP (label decisions)

The PDP answers "which label ids may this caller see". Every row this API
reads is filtered to that answer BEFORE any records are merged or scored.
Unset PDP_URL means labels are unavailable, and the API fails closed with a
503 rather than serving unfiltered data - so pdp.enabled: false is a
deliberate choice to serve nothing, not a way to turn ABAC off.

| Name                 | Description                                                                                                                           | Value  |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------- | ------ |
| `pdp.enabled`        | Wire the PDP URL into the API. Disabled means every request fails closed with 503                                                     | `true` |
| `pdp.url`            | PDP base URL (sets PDP_URL). Empty derives it from hosts.pdp                                                                          | `""`   |
| `pdp.allowHttp`      | Allow HTTP (non-TLS) connections to the PDP (sets PDP_ALLOW_HTTP)                                                                     | `true` |
| `pdp.caCertPath`     | Path to a CA certificate for verifying the PDP's TLS certificate (sets PDP_CA_CERT_PATH). Mount it via extraVolumes/extraVolumeMounts | `""`   |
| `pdp.timeout`        | PDP request timeout in seconds (sets PDP_TIMEOUT)                                                                                     | `""`   |
| `pdp.connectTimeout` | PDP TCP connect timeout in seconds (sets PDP_CONNECT_TIMEOUT)                                                                         | `""`   |
| `pdp.cacheCapacity`  | Maximum cached label decisions, keyed by JWT hash (sets PDP_CACHE_CAPACITY). 0 disables the cache                                     | `""`   |
| `pdp.maxRetries`     | Retry attempts on transient PDP failures (sets PDP_MAX_RETRIES)                                                                       | `""`   |

### Trainer

The API never trains; this CronJob does (same image, the
entity-resolution-trainer entrypoint). Each run skips unless the table
version moved AND the merged row count clears minRows - below that floor
EM produces a degenerate model, not a weak one, and the current artefact
(initially the shipped baseline) stays in force. It trains over the FULL
unfiltered table, deliberately: weights are aggregates and must be right
for every caller; the label filter is applied per request in the API.
The artefact carries literal values with frequencies - classified at the
highest level in the estate; it lives on the internal volume/bucket only.

| Name                              | Description                                                                                                                                                                                                                                                                                                                                                                                                                         | Value         |
| --------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------- |
| `trainer.enabled`                 | Create the trainer CronJob                                                                                                                                                                                                                                                                                                                                                                                                          | `true`        |
| `trainer.schedule`                | Cron schedule for training passes. There is no quiet-window requirement - a pass never touches the serving path                                                                                                                                                                                                                                                                                                                     | `0 */6 * * *` |
| `trainer.minRows`                 | Merged-row floor below which a pass refuses to train                                                                                                                                                                                                                                                                                                                                                                                | `3000`        |
| `trainer.stoplistMaxFreq`         | Values appearing in more than this many merged records are dropped as junk evidence before training (sets STOPLIST_MAX_FREQ)                                                                                                                                                                                                                                                                                                        | `1000`        |
| `trainer.resources`               | Resource requests/limits for the trainer container - bound it so a pass can never starve the API on a shared node                                                                                                                                                                                                                                                                                                                   | `{}`          |
| `trainer.activeDeadlineSeconds`   | Kill a training run that has not finished in this many seconds. MUST be shorter than the gap between runs: concurrencyPolicy is Forbid, so a run that never finishes stops every later run from starting, for ever. A pod that cannot pull its image or cannot reach the broker has not FAILED - it is still trying - so backoffLimit never applies to it and only a deadline ends it. Set to 0 to disable, and own the consequence | `3600`        |
| `trainer.ttlSecondsAfterFinished` | Delete a finished Job this many seconds later. Without it, failed Jobs accumulate until failedJobsHistoryLimit evicts them, and each one keeps its pod                                                                                                                                                                                                                                                                              | `86400`       |

### Baseline seeding

| Name                   | Description                                                                                                                                                              | Value  |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------ |
| `seedBaseline.enabled` | Init container that copies the image's shipped baseline artefact to api.modelArtefactPath if nothing is there yet - so the API can start before the trainer has ever run | `true` |

### Persistence (Delta table)

The Delta table is WRITTEN by the entity-resolution projector and READ here.
The normal deployment points persistence.existingClaim at the projector's
claim and mounts it read-only. For an object-store-backed table set
persistence.enabled: false and point api.personTablePath at the object-store
URI instead.

| Name                           | Description                                                                                                                                               | Value           |
| ------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------- |
| `persistence.enabled`          | Mount a PersistentVolumeClaim holding the Delta table                                                                                                     | `true`          |
| `persistence.existingClaim`    | Name of an existing PVC to use - normally the projector's claim. Leave empty to let this chart create one                                                 | `""`            |
| `persistence.storageClassName` | StorageClass to request - MUST support ReadWriteMany when sharing the projector's table                                                                   | `""`            |
| `persistence.accessMode`       | Access mode for the created PVC                                                                                                                           | `ReadWriteMany` |
| `persistence.size`             | Size to request for the created PVC                                                                                                                       | `10Gi`          |
| `persistence.mountPath`        | Mount path inside the container - api.personTablePath must live under this path                                                                           | `/data/er`      |
| `persistence.readOnly`         | Mount the volume read-only in the serving container. The trainer and the seed initContainer mount it read-write regardless - they write only the artefact | `true`          |

### Autoscaling

Disabled by default. Replicas are stateless, so scaling out is safe; CPU is
a coarse signal for a per-request merge workload, and per-pod memory is the
limit to size for. Type-sharding is the supported growth path.

| Name                                         | Description                        | Value   |
| -------------------------------------------- | ---------------------------------- | ------- |
| `autoscaling.enabled`                        | Enable Horizontal Pod Autoscaler   | `false` |
| `autoscaling.minReplicas`                    | Minimum number of replicas         | `2`     |
| `autoscaling.maxReplicas`                    | Maximum number of replicas         | `10`    |
| `autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization for scaling | `70`    |

### Pod Disruption Budget

| Name                               | Description                                           | Value   |
| ---------------------------------- | ----------------------------------------------------- | ------- |
| `podDisruptionBudget.enabled`      | Enable a PodDisruptionBudget (requires replicas >= 2) | `false` |
| `podDisruptionBudget.minAvailable` | Minimum number of available pods during disruption    | `1`     |

### ConfigMap

| Name                             | Description                                                                       | Value |
| -------------------------------- | --------------------------------------------------------------------------------- | ----- |
| `configMap.existingEnvConfigMap` | Name of an existing ConfigMap to use for non-secret env instead of generating one | `""`  |

### Service

| Name                 | Description                                                                      | Value       |
| -------------------- | -------------------------------------------------------------------------------- | ----------- |
| `service.type`       | Kubernetes service type                                                          | `ClusterIP` |
| `service.port`       | Port the Service exposes (the cluster-facing port)                               | `8080`      |
| `service.targetPort` | Port the container listens on; must match api.port and the image's EXPOSE (8100) | `8100`      |

### Service Account

| Name                         | Description                                                            | Value   |
| ---------------------------- | ---------------------------------------------------------------------- | ------- |
| `serviceAccount.create`      | Create a ServiceAccount for the workload                               | `true`  |
| `serviceAccount.annotations` | Annotations to add to the ServiceAccount                               | `{}`    |
| `serviceAccount.name`        | ServiceAccount name (generated from the chart name if empty)           | `""`    |
| `serviceAccount.automount`   | Automount the ServiceAccount token (the API does not call the K8s API) | `false` |

### Pod Labels and Annotations

| Name             | Description                       | Value |
| ---------------- | --------------------------------- | ----- |
| `podLabels`      | Extra labels applied to Pods      | `{}`  |
| `podAnnotations` | Extra annotations applied to Pods | `{}`  |

### Probes

The API serves a single unauthenticated /health route; there is no separate
readiness path. Startup is fast - the API loads the model artefact rather
than training (training lives in the trainer CronJob) - so the startup
budget only covers image pull + artefact load.

| Name                              | Description                                                          | Value     |
| --------------------------------- | -------------------------------------------------------------------- | --------- |
| `startupProbe.httpGet.path`       | HTTP path probed to detect application startup                       | `/health` |
| `startupProbe.httpGet.port`       | Port (name or number) probed to detect application startup           | `http`    |
| `startupProbe.failureThreshold`   | Number of failed startup probes before the container is restarted    | `30`      |
| `startupProbe.periodSeconds`      | How often (in seconds) to perform the startup probe                  | `10`      |
| `readinessProbe.httpGet.path`     | HTTP path probed to determine readiness to serve traffic             | `/health` |
| `readinessProbe.httpGet.port`     | Port (name or number) probed to determine readiness                  | `http`    |
| `readinessProbe.periodSeconds`    | How often (in seconds) to perform the readiness probe                | `10`      |
| `readinessProbe.timeoutSeconds`   | Seconds after which the readiness probe times out                    | `5`       |
| `readinessProbe.failureThreshold` | Number of failed readiness probes before the Pod is marked not ready | `6`       |
| `livenessProbe.httpGet.path`      | HTTP path probed to determine container liveness                     | `/health` |
| `livenessProbe.httpGet.port`      | Port (name or number) probed to determine container liveness         | `http`    |
| `livenessProbe.periodSeconds`     | How often (in seconds) to perform the liveness probe                 | `30`      |
| `livenessProbe.timeoutSeconds`    | Seconds after which the liveness probe times out                     | `10`      |
| `livenessProbe.failureThreshold`  | Number of failed liveness probes before the container is restarted   | `3`       |

### Deployment Security Context Parameters - Default Security Context

| Name                                                | Description                                                | Value            |
| --------------------------------------------------- | ---------------------------------------------------------- | ---------------- |
| `podSecurityContext.runAsUser`                      | Set the pod's Security Context runAsUser User ID           | `185`            |
| `podSecurityContext.runAsGroup`                     | Set the pod's Security Context runAsGroup Group ID         | `185`            |
| `podSecurityContext.runAsNonRoot`                   | Set the pod's Security Context runAsNonRoot                | `true`           |
| `podSecurityContext.fsGroup`                        | Set the pod's Group ID for the mounted volumes' filesystem | `185`            |
| `podSecurityContext.seccompProfile.type`            | Set the pod's Security Context seccomp profile             | `RuntimeDefault` |
| `containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser User ID         | `185`            |
| `containerSecurityContext.runAsGroup`               | Set containers' Security Context runAsGroup Group ID       | `185`            |
| `containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot              | `true`           |
| `containerSecurityContext.readOnlyRootFilesystem`   | Mount the container root filesystem read-only              | `true`           |
| `containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation  | `false`          |
| `containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                         | `["ALL"]`        |
| `containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile           | `RuntimeDefault` |

### Resource requests/limits

Memory is the binding constraint, not CPU: the whole visible population and
the trained model sit in-process. Size requests against the person table, and
set limits deliberately - an OOMKill mid-request takes the replica down.
Example:
  requests:
    cpu: 500m
    memory: 2Gi
  limits:
    cpu: "2"
    memory: 8Gi

| Name        | Description                                    | Value |
| ----------- | ---------------------------------------------- | ----- |
| `resources` | Resource requests/limits for the API container | `{}`  |

### Ingress policy

| Name                                | Description                                                                  | Value  |
| ----------------------------------- | ---------------------------------------------------------------------------- | ------ |
| `istio.authorizationPolicy.enabled` | Create an Istio AuthorizationPolicy restricting ingress to the Traefik proxy | `true` |
| `istio.exposeDocs`                  | Allow /docs, /redoc and /openapi.json through the ingress policy             | `true` |
| `istio.exposeMcp`                   | Allow the /mcp endpoint through the ingress policy                           | `true` |

### Scheduling

| Name           | Description                       | Value |
| -------------- | --------------------------------- | ----- |
| `nodeSelector` | Node selector for pod scheduling  | `{}`  |
| `tolerations`  | Tolerations for pod scheduling    | `[]`  |
| `affinity`     | Affinity rules for pod scheduling | `{}`  |

### Extra configuration

| Name                | Description                                            | Value |
| ------------------- | ------------------------------------------------------ | ----- |
| `extraEnvVars`      | Additional environment variables for the API container | `[]`  |
| `extraVolumes`      | Additional volumes                                     | `[]`  |
| `extraVolumeMounts` | Additional volume mounts for the API container         | `[]`  |
| `initContainers`    | Additional init containers                             | `[]`  |
| `sidecars`          | Additional sidecar containers                          | `[]`  |

### Override defaults

| Name                   | Description                            | Value |
| ---------------------- | -------------------------------------- | ----- |
| `nameOverride`         | Override the chart name                | `""`  |
| `fullnameOverride`     | Override the full resource name prefix | `""`  |
| `namespaceOverride`    | Override the target namespace          | `""`  |
| `commonLabels`         | Extra labels applied to every resource | `{}`  |
| `revisionHistoryLimit` | Number of old ReplicaSets to retain    | `5`   |
