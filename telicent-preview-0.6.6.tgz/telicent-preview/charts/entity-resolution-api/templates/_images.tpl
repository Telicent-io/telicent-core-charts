{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Return the API image name.
Supports global.imageRegistry override and image digest pinning.
*/}}
{{- define "entity-resolution-api.image" -}}
{{- $registry := .Values.image.registry -}}
{{- if .Values.global }}
{{- if .Values.global.imageRegistry }}
{{- $registry = .Values.global.imageRegistry -}}
{{- end }}
{{- end }}
{{- if .Values.image.digest }}
{{- printf "%s/%s@%s" $registry .Values.image.repository .Values.image.digest }}
{{- else }}
{{- $tag := .Values.image.tag | default .Chart.AppVersion }}
{{- /*
Refuse to render a tag that cannot exist, rather than shipping a workload
that will never start (2026-09-20).

0.0.0 is the version a chart carries before release-please has ever bumped
it, so such a chart installed straight from the repo with no image.tag asked
for `entity-resolution-api:0.0.0` - an image nobody has ever pushed. The
Deployment shows that as ImagePullBackOff, which is at least visible. The
trainer CronJob does not: the failure was a Job stuck pulling for two days,
which (concurrencyPolicy being Forbid) stopped training altogether and looked
from the outside like a CronJob with nothing to do.

Failing here costs an install that says what is wrong. The alternative costs
whoever is on call.
*/ -}}
{{- if eq $tag "0.0.0" }}
{{- fail "image.tag is unset and the chart's appVersion is the unreleased placeholder 0.0.0, so this would ask for an image tag that has never been published. Set image.tag (for example a sha build: image.tag=shadebd09a), or image.digest." }}
{{- end }}
{{- printf "%s/%s:%s" $registry .Values.image.repository $tag }}
{{- end }}
{{- end }}

{{/*
Return merged image pull secrets (global + image, deduplicated).
*/}}
{{- define "entity-resolution-api.imagePullSecrets" -}}
{{- $global := list }}
{{- if .Values.global }}
{{- $global = .Values.global.imagePullSecrets | default list }}
{{- end }}
{{- $image := .Values.image.pullSecrets | default list }}
{{- $all := concat $global $image | uniq }}
{{- if $all }}
imagePullSecrets:
  {{- range $all }}
  - name: {{ . }}
  {{- end }}
{{- end }}
{{- end }}
