{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Names of other host/service name(s) and service account name(s) this
application relies on. Resolution is delegated to the common.discover* helpers
so values resolve correctly both standalone and under the telicent-core
umbrella chart.
*/}}

{{/* auth - returns host ('service:port') and serviceAccount */}}
{{- define "entity-resolution-api.hostAuth" -}}
{{- printf "%s" (include "common.discoverHost" (list . .Values.hosts.auth )) -}}
{{- end -}}
{{- define "entity-resolution-api.serviceAccountAuth" -}}
{{- printf "%s" (include "common.discoverServiceAccount" (list . .Values.hosts.auth )) -}}
{{- end -}}

{{/* pdp - returns host ('service:port') and serviceAccount. The PDP owns label
     decisions; without it this service fails closed and serves nothing. */}}
{{- define "entity-resolution-api.hostPdp" -}}
{{- printf "%s" (include "common.discoverHost" (list . .Values.hosts.pdp )) -}}
{{- end -}}
{{- define "entity-resolution-api.serviceAccountPdp" -}}
{{- printf "%s" (include "common.discoverServiceAccount" (list . .Values.hosts.pdp )) -}}
{{- end -}}

{{/* traefik-proxy - returns host ('service:port') and serviceAccount */}}
{{- define "entity-resolution-api.hostTraefikProxy" -}}
{{- printf "%s" (include "common.discoverHost" (list . .Values.hosts.traefikProxy )) -}}
{{- end -}}
{{- define "entity-resolution-api.serviceAccountTraefikProxy" -}}
{{- printf "%s" (include "common.discoverServiceAccount" (list . .Values.hosts.traefikProxy )) -}}
{{- end -}}
