{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Return the env configmap name.
Uses existingEnvConfigMap if provided, otherwise generates a tc-prefixed name.
*/}}
{{- define "entity-resolution-api.envConfigMapName" -}}
{{- if .Values.configMap.existingEnvConfigMap }}
{{- .Values.configMap.existingEnvConfigMap }}
{{- else }}
{{- printf "tc-%s-env" (include "entity-resolution-api.fullname" .) }}
{{- end }}
{{- end }}
