# Canonicals Event Knowledge Mapper

A Kafka-based component that operates as part of the Telicent Data parent chart, designed to map and process canonical event data into knowledge graph structures for enhanced data understanding and analysis.

## Overview

This chart deploys the Canonicals Event Knowledge Mapper, which processes canonical event data from Kafka topics and transforms it into structured knowledge representations within the Telicent data ecosystem. The mapper enriches raw event data with semantic context and relationships.

## Prerequisites

- Kubernetes cluster
- Helm 3.x
- Access to Kafka cluster
- Telicent Data parent chart deployed

## Installation

This chart is typically installed as a dependency of the `telicent-data` parent chart:

```bash
helm dependency update ../telicent-data
```

```bash
helm install telicent-data ../telicent-data
```

To install this chart independently:

```bash
helm install map-monkey .
```

## Dependencies

- Kafka cluster (configured via parent chart)
- Telicent Core components

## Parameters

### Global Parameters

Contains global parameters. Not explicitly used in this chart, added to maintain consistency across Telicent charts.
These parameters can be referenced in sub-charts as `.Values.global.<parameter-name>`.

| Name                             | Description                                                                   | Value                                            |
| -------------------------------- | ----------------------------------------------------------------------------- | ------------------------------------------------ |
| `global.imageRegistry`           | Global image registry                                                         | `""`                                             |
| `global.imagePullSecrets`        | Global registry secret names as an array                                      | `[]`                                             |
| `global.enterprise`              | Enable enterprise mode, adding additional features and configurations         | `false`                                          |
| `global.groupsClaim`             | Key used to retrieve groups from the OIDC provider                            | `groups`                                         |
| `global.jwksUrl`                 | Endpoint exposing multiple public keys represented as JWKs (JSON Web Key Set) | `https://{yourAuthdomain}/.well-known/jwks.json` |
| `global.istioNamespace`          | Namespace in which Istio is deployed                                          | `istio-system`                                   |
| `global.istioServiceAccountName` | Name of the Istio service account                                             | `istio-ingress`                                  |
| `global.istioGatewayName`        | Name of the Istio Gateway Resource (LB operating at the edge of the mesh)     | `ingress-gateway`                                |

### Kafka Parameters

| Name                                    | Description                                                                                                       | Value                                          |
| --------------------------------------- | ----------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| `global.kafka.bootstrapServers`         | Comma separated list containing Kafka bootstrap servers                                                           | `kafka-bootstrap.kafka.svc.cluster.local:9092` |
| `global.kafka.existingConfigSecretName` | Name of an existing secret containing Kafka configuration (preferred over individual settings below for security) | `""`                                           |
| `global.kafka.username`                 | Username for Kafka authentication                                                                                 | `""`                                           |
| `global.kafka.password`                 | Password for Kafka authentication                                                                                 | `""`                                           |
| `global.kafka.protocol`                 | Protocol used for Kafka communication                                                                             | `SASL_SSL`                                     |
| `global.kafka.mechanism`                | SASL mechanism used for Kafka authentication                                                                      | `SCRAM-SHA-512`                                |
| `global.truststore.existingSecret`      | Name of an existing secret containing the truststore                                                              | `""`                                           |
| `global.truststore.mountPath`           | The mount path for the truststore in the container                                                                | `/app/config/truststore`                       |

### Deployment Parameters

| Name           | Description                  | Value |
| -------------- | ---------------------------- | ----- |
| `replicaCount` | Number of replicas to deploy | `1`   |

### Image Parameters

| Name                | Description                                                                                                                                                                          | Value                          |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------ |
| `image.registry`    | Container image registry                                                                                                                                                             | `quay.io`                      |
| `image.repository`  | Container image name. Releases are published to quay.io/telicent/telicent-map-monkey; development builds to ECR, so point global.imageRegistry or image.registry there for a sha tag | `telicent/telicent-map-monkey` |
| `image.tag`         | Container image tag. If not set, a tag is generated using the appVersion                                                                                                             | `""`                           |
| `image.pullPolicy`  | Container image pull policy                                                                                                                                                          | `IfNotPresent`                 |
| `image.pullSecrets` | Specify registry secret names as an array                                                                                                                                            | `[]`                           |

### Common Parameters

| Name               | Description                                                            | Value |
| ------------------ | ---------------------------------------------------------------------- | ----- |
| `imagePullSecrets` | Global Docker registry secret names as an array                        | `[]`  |
| `nameOverride`     | String to partially override fullname (will maintain the release name) | `""`  |
| `fullnameOverride` | String to fully override the generated release name                    | `""`  |

### Service Account Parameters

| Name                         | Description                                                                                                       | Value  |
| ---------------------------- | ----------------------------------------------------------------------------------------------------------------- | ------ |
| `serviceAccount.create`      | Specifies whether a service account should be created                                                             | `true` |
| `serviceAccount.automount`   | Automatically mount a ServiceAccount's API credentials?                                                           | `true` |
| `serviceAccount.annotations` | Additional custom annotations for the ServiceAccount                                                              | `{}`   |
| `serviceAccount.name`        | Name of the ServiceAccount to use. If not set and create is true, a name is generated using the fullname template | `""`   |

### Pod Parameters

| Name                            | Description                                                                                                                                                                                                                                                                        | Value |
| ------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----- |
| `podAnnotations`                | Additional custom annotations for pods                                                                                                                                                                                                                                             | `{}`  |
| `podLabels`                     | Additional custom labels for pods                                                                                                                                                                                                                                                  | `{}`  |
| `terminationGracePeriodSeconds` | How long Kubernetes waits after SIGTERM before SIGKILL. A clean stop drains every mapper's in-flight work (up to 45s), then flushes the producers (up to 30s) and commits offsets; the default 30s would kill the pod mid-flush and replay those messages as duplicates on restart | `90`  |
| `podSecurityContext`            | Set pods' Security Context                                                                                                                                                                                                                                                         | `{}`  |
| `securityContext`               | Set containers' Security Context                                                                                                                                                                                                                                                   | `{}`  |

### Resource Parameters

| Name        | Description                           | Value |
| ----------- | ------------------------------------- | ----- |
| `resources` | Resources for *map-monkey* containers | `{}`  |

### Autoscaling Parameters

| Name                                         | Description                       | Value   |
| -------------------------------------------- | --------------------------------- | ------- |
| `autoscaling.enabled`                        | Enable Horizontal Pod Autoscaler  | `false` |
| `autoscaling.minReplicas`                    | Minimum number of replicas        | `1`     |
| `autoscaling.maxReplicas`                    | Maximum number of replicas        | `100`   |
| `autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization percentage | `80`    |

### Volume Parameters

| Name           | Description                                                 | Value |
| -------------- | ----------------------------------------------------------- | ----- |
| `volumes`      | Additional volumes on the output Deployment definition      | `[]`  |
| `volumeMounts` | Additional volumeMounts on the output Deployment definition | `[]`  |

### Node Selection Parameters

| Name           | Description                     | Value |
| -------------- | ------------------------------- | ----- |
| `nodeSelector` | Node labels for pods assignment | `{}`  |
| `tolerations`  | Tolerations for pods assignment | `[]`  |
| `affinity`     | Affinity for pods assignment    | `{}`  |

### Health Probe Parameters

The engine serves /healthz, /readyz and /status on the health port.

/healthz fails when the supervisor loop's heartbeat goes stale, i.e. the
engine is wedged rather than merely idle. /readyz additionally fails when
EVERY mapper is parked, so a rollout will not proceed past a version that
cannot map anything.

The startup probe matters more than it looks. The health server only starts
after the engine has tried to reach the config database, and that retries for
up to 60 seconds before giving up and coming up with no mappers. Without a
startup probe, a liveness check would kill the pod during exactly the
database outage the retry exists to survive.

| Name                              | Description                                                                                    | Value      |
| --------------------------------- | ---------------------------------------------------------------------------------------------- | ---------- |
| `startupProbe.httpGet.path`       | Endpoint to probe                                                                              | `/healthz` |
| `startupProbe.httpGet.port`       | Named port on the container serving the health endpoints                                       | `health`   |
| `startupProbe.periodSeconds`      | How often to poll while starting up                                                            | `5`        |
| `startupProbe.failureThreshold`   | Attempts allowed before startup is called failed. 30 x 5s covers the 60s config-database retry | `30`       |
| `livenessProbe.httpGet.path`      | Endpoint to probe                                                                              | `/healthz` |
| `livenessProbe.httpGet.port`      | Named port on the container serving the health endpoints                                       | `health`   |
| `livenessProbe.periodSeconds`     | How often to check the engine is still making progress                                         | `10`       |
| `livenessProbe.failureThreshold`  | Consecutive failures before the pod is restarted                                               | `3`        |
| `readinessProbe.httpGet.path`     | Endpoint to probe                                                                              | `/readyz`  |
| `readinessProbe.httpGet.port`     | Named port on the container serving the health endpoints                                       | `health`   |
| `readinessProbe.periodSeconds`    | How often to check the engine can map anything                                                 | `10`       |
| `readinessProbe.failureThreshold` | Consecutive failures before the pod is taken out of service                                    | `3`        |

### Configuration Parameters

Contains configuration parameters specific to the application

| Name                                     | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | Value    |
| ---------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------- |
| `configuration.logLevel`                 | Log filter for the engine (RUST_LOG syntax)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | `info`   |
| `configuration.kafkaConfigMode`          | Kafka configuration mode: `toml` layers the mounted kafka-config file over env (flow semantics); `basic` uses env only                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | `toml`   |
| `configuration.producerBufferMaxKbytes`  | Producer buffer ceiling in KiB (librdkafka queue.buffering.max.kbytes). PER MAPPER - the engine runs one producer per mapper, so this times two times the mapper count IS the engine's memory ceiling, and a stalled sink fills every buffer to it. Was 32768, which at 59 mappers is ~3.8 GiB and OOM-killed a 3 GiB pod in two minutes of real backlog. Sized against the largest message a topic accepts, not against throughput: every registered topic is at Kafka's default max.message.bytes (1,048,588), so 8 MiB holds eight whole messages. A buffer smaller than ONE message makes a produce fail outright, so raise this if the broker's message limit rises | `8192`   |
| `configuration.consumerQueueMaxKbytes`   | Consumer prefetch ceiling in KiB (librdkafka queued.max.messages.kbytes). Also per mapper, same arithmetic as producerBufferMaxKbytes and sized the same way                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             | `8192`   |
| `configuration.sinkMaxMessageBytes`      | Fallback cap on a packed sink message, used only for topics whose registration does not record the broker's real max.message.bytes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | `900000` |
| `configuration.mapperStartRatePerSecond` | Ceiling on mapper runtime starts per second. Each start opens a consumer and a producer, and brokers cap connection creation (MSK small nodes: 4 new connections/s/broker; Kafka stalls ALL accepts once a second goes over, so an unpaced start of many mappers never connects). Fractional allowed                                                                                                                                                                                                                                                                                                                                                                     | `1`      |
| `configuration.mapperStarvationSeconds`  | How long a mapper may receive nothing while the broker still reports lag for its consumer group, before the engine restarts it. Catches a consumer that has silently stopped while still reporting "running". Must comfortably exceed a rebalance; `0` disables it                                                                                                                                                                                                                                                                                                                                                                                                       | `300`    |
| `configuration.crashRecovery.enabled`    | Mount an emptyDir for crash-loop recovery state. When the process dies in a way nothing can catch (OOM kill, allocation abort, hard signal), this is what lets the restart notice it is dying on the same message every time. emptyDir survives a container restart inside the pod, which is exactly that case, and is empty in a fresh pod                                                                                                                                                                                                                                                                                                                              | `true`   |
| `configuration.crashRecovery.skipAfter`  | How many process starts from the same unmoved offset before the message sitting there is dead-lettered as `crash-poison` and skipped. Only restarts of the PROCESS count. Minimum 2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | `3`      |

### Config Database Parameters

The engine reads its mapper and topic config STRAIGHT FROM POSTGRES, as a
read-only user. There is deliberately no API in the read path: the engine
has to stay up, and a web request in front of a config read is one more
thing that can fail. Every write goes through the-management.

Host, port, database and user are plain values; only the password comes
from a secret. All four are required by the engine and have no defaults -
miss one and it exits at startup.

| Name                                        | Description                                                                                                                                                                                                                                                                                                                                                                   | Value         |
| ------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------- |
| `configuration.configDb.host`               | Config database host                                                                                                                                                                                                                                                                                                                                                          | `""`          |
| `configuration.configDb.port`               | Config database port                                                                                                                                                                                                                                                                                                                                                          | `5432`        |
| `configuration.configDb.database`           | Config database name                                                                                                                                                                                                                                                                                                                                                          | `map_monkey`  |
| `configuration.configDb.user`               | Config database user. Needs SELECT only                                                                                                                                                                                                                                                                                                                                       | `""`          |
| `configuration.configDb.existingSecretName` | Name of an existing secret holding the config database password                                                                                                                                                                                                                                                                                                               | `""`          |
| `configuration.configDb.passwordKey`        | Key within that secret holding the password                                                                                                                                                                                                                                                                                                                                   | `password`    |
| `configuration.configDb.sslmode`            | libpq sslmode. `disable` is plaintext; a cluster should use `verify-full`                                                                                                                                                                                                                                                                                                     | `verify-full` |
| `configuration.configDb.caSecretName`       | Name of an EXISTING Kubernetes Secret holding the CA chain that signs the database server's certificate. Needed whenever that certificate is not publicly chained (AWS RDS, most customer databases) - the engine ALWAYS verifies. The secret is platform-managed (devops' cross-platform secrets shim), never pasted into values. Empty = the container's system trust store | `""`          |
| `configuration.configDb.caSecretKey`        | Key within that secret holding the PEM chain                                                                                                                                                                                                                                                                                                                                  | `ca.pem`      |
| `configuration.configDb.pollSeconds`        | How often to re-read config. The control topic below makes a change arrive sooner; this is the backstop                                                                                                                                                                                                                                                                       | `60`          |
| `configuration.configDb.controlTopic`       | Kafka topic carrying "config changed" nudges. Every replica watches it, so a change reaches all of them at once. Empty disables it, leaving polling only                                                                                                                                                                                                                      | `""`          |

### Observability Parameters

The engine exports its own per-partition consumer lag over OTLP, which is
the autoscaling signal - deliberately not read from the broker, since the
broker may be Kafka, Redpanda or an S3-native clone.

| Name                                                | Description                                                                                                                                     | Value   |
| --------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- | ------- |
| `configuration.observability.otlpEndpoint`          | OTLP gRPC endpoint for metrics. Empty disables metric export; the engine still runs                                                             | `""`    |
| `configuration.observability.healthPort`            | Port for the health endpoints (/healthz, /readyz, /status)                                                                                      | `9090`  |
| `configuration.observability.statusTokenSecretName` | Name of an existing secret holding the bearer token that unlocks per-mapper detail on /status. Without it /status returns aggregate counts only | `""`    |
| `configuration.observability.statusTokenKey`        | Key within that secret holding the token                                                                                                        | `token` |

helm install telicent-data ../telicent-data
```

To install this chart independently:

```bash
helm install producer-acled-ontology .
```

## Dependencies

- Kafka cluster (configured via parent chart)
- Telicent Core components

