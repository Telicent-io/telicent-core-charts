{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Returns the version
*/}}
{{- define "map-monkey.version" -}}
{{- .Values.image.tag | default .Chart.AppVersion }}
{{- end -}}

{{/*
Returns the image registry
*/}}
{{- define "map-monkey.imageRegistry" -}}
{{- .Values.global.imageRegistry | default .Values.image.registry }}
{{- end -}}

{{/*
Returns the image
*/}}
{{- define "map-monkey.image" -}}
{{- printf "%s/%s:%s" (include "map-monkey.imageRegistry" .) .Values.image.repository (include "map-monkey.version" .) }}
{{- end -}}
