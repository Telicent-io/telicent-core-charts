{{/*
Return the labels database secret name.
Uses existingSecret if provided, otherwise generates a name.
*/}}
{{- define "telicent-pdp.labelsDbSecretName" -}}
{{- if .Values.labelsDb.existingSecret }}
{{- .Values.labelsDb.existingSecret }}
{{- else }}
{{- printf "%s-labels-db" (include "telicent-pdp.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Return the env configmap name.
Uses existingEnvConfigMap if provided, otherwise generates a name.
*/}}
{{- define "telicent-pdp.envConfigMapName" -}}
{{- if .Values.configMap.existingEnvConfigMap }}
{{- .Values.configMap.existingEnvConfigMap }}
{{- else }}
{{- printf "%s-env" (include "telicent-pdp.fullname" .) }}
{{- end }}
{{- end }}
