# telicent-pdp

Attribute-Based Access Control Policy Decision Point (Python) for IDH labels.
The PDP answers label decisions for the entity-resolution API over a
PostgreSQL labels database, authenticating callers against the platform
auth-server via `telicent-core-extensions`.

## Installing

Release charts are published to `oci://quay.io/telicent/charts/telicent-pdp`
and release images to `quay.io/telicent/telicent-pdp`, both tagged with the
release version. Development builds from `main` go to ECR as
`charts/telicent-pdp` and `telicent-pdp`, with the chart version re-stamped to
`<version>-<sha>` and `appVersion` to `<sha>`.

A chart installed straight from this repository carries the unreleased
placeholder `0.0.0` as `appVersion`, so `image.tag` (or `image.digest`) must
be set explicitly - the chart refuses to render otherwise.

`labelsDb.password` (or `labelsDb.existingSecret`) is required.

## Parameters

### Global parameters

| Name                      | Description                                            | Value |
| ------------------------- | ------------------------------------------------------ | ----- |
| `global.imageRegistry`    | Global image registry override for umbrella charts     | `""`  |
| `global.imagePullSecrets` | Global image pull secrets override for umbrella charts | `[]`  |

### Image

| Name                | Description                                                    | Value                   |
| ------------------- | -------------------------------------------------------------- | ----------------------- |
| `image.registry`    | Container image registry                                       | `quay.io`               |
| `image.repository`  | Container image repository                                     | `telicent/telicent-pdp` |
| `image.tag`         | Container image tag (defaults to Chart.appVersion)             | `""`                    |
| `image.digest`      | Image digest (sha256:...) - takes precedence over tag when set | `""`                    |
| `image.pullPolicy`  | Image pull policy                                              | `IfNotPresent`          |
| `image.pullSecrets` | Image pull secrets                                             | `[]`                    |

### Replicas

| Name       | Description                                                       | Value |
| ---------- | ----------------------------------------------------------------- | ----- |
| `replicas` | Number of pod replicas (ignored when autoscaling.enabled is true) | `1`   |

### Autoscaling

| Name                                         | Description                        | Value   |
| -------------------------------------------- | ---------------------------------- | ------- |
| `autoscaling.enabled`                        | Enable Horizontal Pod Autoscaler   | `false` |
| `autoscaling.minReplicas`                    | Minimum number of replicas         | `2`     |
| `autoscaling.maxReplicas`                    | Maximum number of replicas         | `10`    |
| `autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization for scaling | `70`    |

### Pod Disruption Budget

| Name                               | Description                                        | Value   |
| ---------------------------------- | -------------------------------------------------- | ------- |
| `podDisruptionBudget.enabled`      | Enable Pod Disruption Budget                       | `false` |
| `podDisruptionBudget.minAvailable` | Minimum number of available pods during disruption | `1`     |

### PostgreSQL

| Name                       | Description                                | Value       |
| -------------------------- | ------------------------------------------ | ----------- |
| `postgres.host`            | PostgreSQL host                            | `localhost` |
| `postgres.port`            | PostgreSQL port                            | `5432`      |
| `postgres.maxPoolSize`     | Maximum connections in the pool            | `32`        |
| `postgres.waitTimeoutMs`   | Max ms to wait for an available connection | `5000`      |
| `postgres.createTimeoutMs` | Max ms to establish a new connection       | `3000`      |
| `postgres.queryTimeoutMs`  | Max ms for a single database query         | `10000`     |
| `postgres.tlsEnabled`      | Enable TLS for PostgreSQL connections      | `true`      |
| `postgres.caBundle`        | PEM certificate chain used to verify the   | `""`        |

### Labels Database

| Name                      | Description                                                                      | Value      |
| ------------------------- | -------------------------------------------------------------------------------- | ---------- |
| `labelsDb.database`       | Database name for labels                                                         | `access`   |
| `labelsDb.username`       | Database username for labels                                                     | `postgres` |
| `labelsDb.password`       | Database password for labels (ignored if existingSecret is set)                  | `""`       |
| `labelsDb.existingSecret` | Name of existing kubernetes.io/basic-auth secret with username and password keys | `""`       |

### Auth Server (telicent-core-extensions)

| Name                      | Description                                                    | Value                   |
| ------------------------- | -------------------------------------------------------------- | ----------------------- |
| `authServer.url`          | Base URL of the auth-server                                    | `http://localhost:9000` |
| `authServer.allowHttp`    | Allow HTTP (non-TLS) connections to auth-server                | `false`                 |
| `authServer.jwtIssuer`    | Expected JWT issuer claim                                      | `""`                    |
| `authServer.jwtAudience`  | Expected JWT audience claim                                    | `telicent_core`         |
| `authServer.jwtAlgorithm` | JWT signing algorithm (leave empty for default RS256)          | `""`                    |
| `authServer.jwksUrl`      | JWKS endpoint URL (leave empty to derive from auth-server URL) | `""`                    |
| `authServer.requiredRole` | Role required in JWT (leave empty for default USER)            | `""`                    |

### Server

| Name          | Description                    | Value  |
| ------------- | ------------------------------ | ------ |
| `server.port` | TCP port the server listens on | `3001` |

### TLS

| Name             | Description                                                             | Value  |
| ---------------- | ----------------------------------------------------------------------- | ------ |
| `tls.mode`       | Transport security mode: NONE, TLS, or MTLS                             | `NONE` |
| `tls.certPath`   | Path to server certificate (PEM). Required for TLS/MTLS                 | `""`   |
| `tls.keyPath`    | Path to server private key (PEM). Required for TLS/MTLS                 | `""`   |
| `tls.caCertPath` | Path to CA certificate for client verification (PEM). Required for MTLS | `""`   |

### Cache

| Name                        | Description                                      | Value   |
| --------------------------- | ------------------------------------------------ | ------- |
| `cache.jwtCacheEnabled`     | Enable JWT-based label results caching           | `true`  |
| `cache.jwtCacheMaxSize`     | Max entries in JWT cache                         | `10000` |
| `cache.expiryBufferSeconds` | Seconds subtracted from JWT expiry for cache TTL | `30`    |

### Evaluation

| Name                       | Description                                                                                                       | Value  |
| -------------------------- | ----------------------------------------------------------------------------------------------------------------- | ------ |
| `evaluation.strictNatEval` | Strict (true): empty/absent nationality array denies the label (fail-safe); false treats empty as no restriction  | `true` |
| `evaluation.strictOrgEval` | Strict (true): empty/absent organisation array denies the label (fail-safe); false treats empty as no restriction | `true` |

### Logging

| Name             | Description                             | Value  |
| ---------------- | --------------------------------------- | ------ |
| `logging.level`  | Log level (debug, info, warning, error) | `info` |
| `logging.format` | Log format: text or json                | `json` |

### Telemetry

| Name                     | Description                                              | Value          |
| ------------------------ | -------------------------------------------------------- | -------------- |
| `telemetry.serviceName`  | OpenTelemetry service name                               | `telicent-pdp` |
| `telemetry.otlpEndpoint` | OTLP collector endpoint (leave empty to disable tracing) | `""`           |

### ConfigMap

| Name                             | Description                                                 | Value |
| -------------------------------- | ----------------------------------------------------------- | ----- |
| `configMap.existingEnvConfigMap` | Name of existing ConfigMap to use instead of generating one | `""`  |

### Service

| Name           | Description             | Value       |
| -------------- | ----------------------- | ----------- |
| `service.type` | Kubernetes service type | `ClusterIP` |
| `service.port` | Kubernetes service port | `3001`      |

### Service Account

| Name                         | Description                                 | Value  |
| ---------------------------- | ------------------------------------------- | ------ |
| `serviceAccount.create`      | Create a service account                    | `true` |
| `serviceAccount.annotations` | Service account annotations                 | `{}`   |
| `serviceAccount.name`        | Service account name (generated if not set) | `""`   |

### Pod Security Context

| Name                                     | Description                      | Value            |
| ---------------------------------------- | -------------------------------- | ---------------- |
| `podSecurityContext.runAsUser`           | User ID to run the container as  | `1001`           |
| `podSecurityContext.runAsGroup`          | Group ID to run the container as | `0`              |
| `podSecurityContext.runAsNonRoot`        | Require non-root user            | `true`           |
| `podSecurityContext.fsGroup`             | Filesystem group ID              | `0`              |
| `podSecurityContext.seccompProfile.type` | Seccomp profile type             | `RuntimeDefault` |

### Container Security Context

| Name                                                | Description                        | Value     |
| --------------------------------------------------- | ---------------------------------- | --------- |
| `containerSecurityContext.allowPrivilegeEscalation` | Allow privilege escalation         | `false`   |
| `containerSecurityContext.readOnlyRootFilesystem`   | Mount root filesystem as read-only | `true`    |
| `containerSecurityContext.capabilities.drop`        | Linux capabilities to drop         | `["ALL"]` |

### Resources

| Name        | Description                                    | Value |
| ----------- | ---------------------------------------------- | ----- |
| `resources` | Resource requests and limits for the container | `{}`  |

### Scheduling

| Name           | Description                       | Value |
| -------------- | --------------------------------- | ----- |
| `nodeSelector` | Node selector for pod scheduling  | `{}`  |
| `tolerations`  | Tolerations for pod scheduling    | `[]`  |
| `affinity`     | Affinity rules for pod scheduling | `{}`  |

### Extra configuration

| Name                | Description                      | Value |
| ------------------- | -------------------------------- | ----- |
| `extraEnvVars`      | Additional environment variables | `[]`  |
| `extraVolumes`      | Additional volumes               | `[]`  |
| `extraVolumeMounts` | Additional volume mounts         | `[]`  |
| `initContainers`    | Additional init containers       | `[]`  |
| `sidecars`          | Additional sidecar containers    | `[]`  |
