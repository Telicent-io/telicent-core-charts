{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Return the projector image name.
Supports global.imageRegistry override and image digest pinning.
*/}}
{{- define "entity-resolution-projector.image" -}}
{{- $registry := .Values.image.registry -}}
{{- if .Values.global }}
{{- if .Values.global.imageRegistry }}
{{- $registry = .Values.global.imageRegistry -}}
{{- end }}
{{- end }}
{{- if .Values.image.digest }}
{{- printf "%s/%s@%s" $registry .Values.image.repository .Values.image.digest }}
{{- else }}
{{- $tag := .Values.image.tag | default .Chart.AppVersion }}
{{- /*
Refuse to render a tag that cannot exist, rather than shipping a workload
that will never start.

0.0.0 is the version a chart carries before release-please has ever bumped
it, so such a chart installed straight from the repo with no image.tag asks
for `entity-resolution-projector:0.0.0` - an image nobody has ever pushed.
Failing here costs an install that says what is wrong; ImagePullBackOff
costs whoever is on call. Same guard as smart-cache-er-api (2026-09-20).
*/ -}}
{{- if eq $tag "0.0.0" }}
{{- fail "image.tag is unset and the chart's appVersion is the unreleased placeholder 0.0.0, so this would ask for an image tag that has never been published. Set image.tag (for example a sha build: image.tag=shadebd09a), or image.digest." }}
{{- end }}
{{- printf "%s/%s:%s" $registry .Values.image.repository $tag }}
{{- end }}
{{- end }}
