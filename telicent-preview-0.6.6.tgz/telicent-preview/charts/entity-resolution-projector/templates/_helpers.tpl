{{/*
Expand the name of the chart.
*/}}
{{- define "entity-resolution-projector.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "entity-resolution-projector.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "entity-resolution-projector.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "entity-resolution-projector.labels" -}}
helm.sh/chart: {{ include "entity-resolution-projector.chart" . }}
{{ include "entity-resolution-projector.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
telicent.io/type: projector
telicent.io/component-of: entity-resolution
{{- end }}

{{/*
Selector labels
*/}}
{{- define "entity-resolution-projector.selectorLabels" -}}
app.kubernetes.io/name: {{ include "entity-resolution-projector.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "entity-resolution-projector.kafkaAuthConfigSecretName" }}
{{- if .Values.global.kafka.existingConfigSecretName }}
{{- .Values.global.kafka.existingConfigSecretName }}
{{- else }}
{{- include "entity-resolution-projector.fullname" . }}-kafka-config
{{- end }}
{{- end }}

{{- define "entity-resolution-projector.jsonRegisterSecretName" }}
{{- if .Values.jsonRegister.existingSecret }}
{{- .Values.jsonRegister.existingSecret }}
{{- else }}
{{- include "entity-resolution-projector.fullname" . }}-json-register
{{- end }}
{{- end }}

{{- define "entity-resolution-projector.jsonRegisterSecretPasswordKey" }}
{{- if .Values.jsonRegister.existingSecret }}
{{- .Values.jsonRegister.existingSecretPasswordKey }}
{{- else }}
{{- "password" }}
{{- end }}
{{- end }}

{{- define "entity-resolution-projector.pvcName" }}
{{- if .Values.persistence.existingClaim }}
{{- .Values.persistence.existingClaim }}
{{- else }}
{{- include "entity-resolution-projector.fullname" . }}-data
{{- end }}
{{- end }}

{{/*
The service account the pod runs as. On EKS, S3 credentials for the Delta
tables arrive by IRSA, which binds an IAM role to this service account -
the deployment's role trust policy names it, so the default (the release
fullname, e.g. "er-projector") must match what the infra side was told.
*/}}
{{- define "entity-resolution-projector.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "entity-resolution-projector.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
