# entity-resolution-projector

Canonical topic -> Delta/Parquet projector for the entity-resolution
stack. One deployment serves all entity types (routes in-process by
`schema_type`) - today, only `person`.

## Operational characteristics

- **`replicaCount` is fixed at 1.** This is a single-writer-per-table
  projector; scaling it means partition-consumer coordination work that
  does not exist today. Do not raise this above 1 and do not put an HPA
  in front of this chart.
- **Delta table volume defaults to `ReadWriteMany`.** This projector
  WRITEs the table; `entity-resolution-api` and the batch matcher READ
  the same table directly - single-writer(projector)/many-reader is the
  contract, not an accident of the default `persistence.accessMode`. For
  object-store-backed tables, set `persistence.enabled: false` and point
  `configuration.personTablePath` at the object-store URI instead.
- **Health probes hit the built-in aiohttp health server** on
  `configuration.healthPort` (`/live`, `/ready`) - there is no sidecar or
  exec probe.
- **Kafka auth comes from the platform secret.** Set
  `global.kafka.existingConfigSecretName` (the shared `kafka-auth-config`)
  and the chart mounts it at `/app/config/kafka-auth/` and sets
  `KAFKA_CONFIG_FILE_PATH`; the app merges the file's librdkafka
  `key=value` properties (`security.protocol`, `sasl.*`) over its own
  client settings, file wins. Unset, the projector talks plaintext to
  `global.kafka.bootstrapServers`, which is right for compose and wrong
  for MSK: against a SASL_SSL port every connection is closed at
  APIVERSION_QUERY.

## Parameters

### Global Parameters

Contains global parameters. Not explicitly used in this chart, added to maintain consistency across Telicent charts.
These parameters can be referenced in sub-charts as `.Values.global.<parameter-name>`.

| Name                             | Description                                                                       | Value                                            |
| -------------------------------- | --------------------------------------------------------------------------------- | ------------------------------------------------ |
| `global.imageRegistry`           | Global image registry                                                             | `""`                                             |
| `global.imagePullSecrets`        | Global registry secret names as an array                                          | `[]`                                             |
| `global.enterprise`              | Enable enterprise mode, adding additional features and configurations             | `false`                                          |
| `global.appHostDomain`           | Domain associated with Telicent application services                              | `apps.telicent.io`                               |
| `global.authHostDomain`          | Domain associated with Telicent authentication services, including OIDC providers | `auth.telicent.io`                               |
| `global.groupsClaim`             | Key used to retrieve groups from the OIDC provider                                | `groups`                                         |
| `global.jwksUrl`                 | Endpoint exposing multiple public keys represented as JWKs (JSON Web Key Set)     | `https://{yourAuthdomain}/.well-known/jwks.json` |
| `global.istioNamespace`          | Namespace in which Istio is deployed                                              | `istio-system`                                   |
| `global.istioServiceAccountName` | Name of the Istio service account                                                 | `istio-ingress`                                  |
| `global.istioGatewayName`        | Name of the Istio Gateway Resource (LB operating at the edge of the mesh)         | `ingress-gateway`                                |

### Kafka Parameters

| Name                                    | Description                                                                                                       | Value                                          |
| --------------------------------------- | ----------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| `global.kafka.bootstrapServers`         | Comma separated list containing Kafka bootstrap servers                                                           | `kafka-bootstrap.kafka.svc.cluster.local:9092` |
| `global.kafka.existingConfigSecretName` | Name of an existing secret containing Kafka configuration (preferred over individual settings below for security) | `""`                                           |
| `global.kafka.username`                 | Username for Kafka authentication                                                                                 | `""`                                           |
| `global.kafka.password`                 | Password for Kafka authentication                                                                                 | `""`                                           |
| `global.kafka.protocol`                 | Protocol used for Kafka communication                                                                             | `SASL_SSL`                                     |
| `global.kafka.mechanism`                | SASL mechanism used for Kafka authentication                                                                      | `SCRAM-SHA-512`                                |
| `global.truststore.existingSecret`      | Name of an existing secret containing the truststore                                                              | `""`                                           |
| `global.truststore.mountPath`           | The mount path for the truststore in the container                                                                | `/app/config/truststore`                       |

### Deployment Parameters

replicaCount is FIXED at 1 by design - this is a single-writer-per-table
projector (one consumer group, one Delta table). Scaling it means
partition-consumer coordination work that does not exist today; do not
set this above 1 and do not add an HPA for this workload.

| Name           | Description                                      | Value |
| -------------- | ------------------------------------------------ | ----- |
| `replicaCount` | Number of replicas to deploy (fixed - see above) | `1`   |

### Service Account Parameters

The pod's service account. On EKS the S3 credentials for the Delta tables
arrive by IRSA: an IAM role's trust policy names this service account, so
the per-deployment values put the role arn in annotations
(eks.amazonaws.com/role-arn). The default name is the release fullname
(e.g. "er-projector") - the same name the infra trust policy was given.

| Name                         | Description                                                                         | Value  |
| ---------------------------- | ----------------------------------------------------------------------------------- | ------ |
| `serviceAccount.create`      | Create a ServiceAccount for the workload                                            | `true` |
| `serviceAccount.automount`   | Automount the ServiceAccount token                                                  | `true` |
| `serviceAccount.annotations` | Annotations to add to the ServiceAccount (e.g. eks.amazonaws.com/role-arn for IRSA) | `{}`   |
| `serviceAccount.name`        | ServiceAccount name (the release fullname if empty)                                 | `""`   |

### Image Parameters

| Name                | Description                                                              | Value                                  |
| ------------------- | ------------------------------------------------------------------------ | -------------------------------------- |
| `image.registry`    | Container image registry                                                 | `quay.io`                              |
| `image.repository`  | Container image name                                                     | `telicent/entity-resolution-projector` |
| `image.tag`         | Container image tag. If not set, a tag is generated using the appVersion | `""`                                   |
| `image.digest`      | Image digest (sha256:...) - takes precedence over tag when set           | `""`                                   |
| `image.pullPolicy`  | Container image pull policy                                              | `IfNotPresent`                         |
| `image.pullSecrets` | Specify registry secret names as an array                                | `[]`                                   |

### Name Parameters

| Name               | Description                                                            | Value |
| ------------------ | ---------------------------------------------------------------------- | ----- |
| `nameOverride`     | String to partially override fullname (will maintain the release name) | `""`  |
| `fullnameOverride` | String to fully override the generated release name                    | `""`  |

### Pod Parameters

| Name                 | Description                            | Value |
| -------------------- | -------------------------------------- | ----- |
| `podAnnotations`     | Additional custom annotations for pods | `{}`  |
| `podLabels`          | Additional custom labels for pods      | `{}`  |
| `podSecurityContext` | Set pods' Security Context             | `{}`  |

### Container Parameters

| Name                                       | Description                                                                                               | Value            |
| ------------------------------------------ | --------------------------------------------------------------------------------------------------------- | ---------------- |
| `securityContext.runAsUser`                | The UID to run the entrypoint of the container process                                                    | `185`            |
| `securityContext.runAsGroup`               | The GID to run the entrypoint of the container process                                                    | `185`            |
| `securityContext.runAsNonRoot`             | Indicates that the container must run as a non-root user                                                  | `true`           |
| `securityContext.allowPrivilegeEscalation` | Whether to allow privilege escalation, where the process can gain more privileges than its parent process | `false`          |
| `securityContext.capabilities.drop`        | The capabilities to drop when running containers                                                          | `["ALL"]`        |
| `securityContext.seccompProfile.type`      | Indicates which kind of seccomp profile will be applied                                                   | `RuntimeDefault` |
| `resources`                                | Resources for workload containers                                                                         | `{}`             |

### Health Probe Parameters

Probes hit the built-in aiohttp health server (configuration.healthPort),
not a sidecar or exec probe - /live and /ready are served by the
projector process itself.

| Name                                 | Description                                                          | Value    |
| ------------------------------------ | -------------------------------------------------------------------- | -------- |
| `livenessProbe.httpGet.path`         | HTTP path probed to determine container liveness                     | `/live`  |
| `livenessProbe.httpGet.port`         | Port (name or number) probed to determine container liveness         | `health` |
| `livenessProbe.initialDelaySeconds`  | Seconds after the container starts before the liveness probe begins  | `10`     |
| `livenessProbe.periodSeconds`        | How often (in seconds) to perform the liveness probe                 | `10`     |
| `livenessProbe.timeoutSeconds`       | Seconds after which the liveness probe times out                     | `5`      |
| `livenessProbe.failureThreshold`     | Number of failed liveness probes before the container is restarted   | `3`      |
| `readinessProbe.httpGet.path`        | HTTP path probed to determine readiness to consume                   | `/ready` |
| `readinessProbe.httpGet.port`        | Port (name or number) probed to determine readiness                  | `health` |
| `readinessProbe.initialDelaySeconds` | Seconds after the container starts before the readiness probe begins | `10`     |
| `readinessProbe.periodSeconds`       | How often (in seconds) to perform the readiness probe                | `10`     |
| `readinessProbe.timeoutSeconds`      | Seconds after which the readiness probe times out                    | `5`      |
| `readinessProbe.failureThreshold`    | Number of failed readiness probes before the Pod is marked not ready | `3`      |

### Volume Parameters

| Name           | Description                                                 | Value |
| -------------- | ----------------------------------------------------------- | ----- |
| `volumes`      | Additional volumes on the output Deployment definition      | `[]`  |
| `volumeMounts` | Additional volumeMounts on the output Deployment definition | `[]`  |

### Node Selection Parameters

| Name           | Description                     | Value |
| -------------- | ------------------------------- | ----- |
| `nodeSelector` | Node labels for pods assignment | `{}`  |
| `tolerations`  | Tolerations for pods assignment | `[]`  |
| `affinity`     | Affinity for pods assignment    | `{}`  |
| `annotations`  | Annotations for the deployment  | `{}`  |

### Configuration Parameters

Contains configuration parameters specific to the projector: source/DLQ
topics, table path, label register connection, and health port. See
README.md "Configuration" for the full env-var table these map onto.

| Name                             | Description                                                                                                                                                                                                                                                        | Value              |
| -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------ |
| `configuration.sourceTopic`      | The er.evidence topic the sink consumes. Env-overridable per deployment - topic names collide in customer environments                                                                                                                                             | `er.evidence`      |
| `configuration.dlqTopic`         | Dead-letter topic - malformed envelopes, unknown tables, contract-schema failures                                                                                                                                                                                  | `er.evidence.dlq`  |
| `configuration.personTablePath`  | Person Delta table path                                                                                                                                                                                                                                            | `/data/er/person`  |
| `configuration.vehicleTablePath` | Vehicle Delta table path                                                                                                                                                                                                                                           | `/data/er/vehicle` |
| `configuration.addressTablePath` | Address Delta table path                                                                                                                                                                                                                                           | `/data/er/address` |
| `configuration.deviceTablePath`  | Device Delta table path                                                                                                                                                                                                                                            | `/data/er/device`  |
| `configuration.healthPort`       | Port the built-in aiohttp health server listens on                                                                                                                                                                                                                 | `8080`             |
| `configuration.kafkaConfigMode`  | Kept for house-style consistency; the app has one format (librdkafka key=value lines, the platform's kafka-config.toml) and switches on global.kafka.existingConfigSecretName being set, which mounts that secret and merges its properties over the client config | `toml`             |

### Label Register Parameters

Postgres connection for the label register (json-register) - ABAC label
ids this projector partitions the person table by. Fails closed: if the
register is unavailable the message goes to DLQ, never written unlabelled.

| Name                                     | Description                                                                                                                                                                              | Value            |
| ---------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------- |
| `jsonRegister.host`                      | Label register postgres host                                                                                                                                                             | `""`             |
| `jsonRegister.port`                      | Label register postgres port                                                                                                                                                             | `5432`           |
| `jsonRegister.database`                  | Label register postgres database                                                                                                                                                         | `access`         |
| `jsonRegister.user`                      | Label register postgres user                                                                                                                                                             | `""`             |
| `jsonRegister.table`                     | Label register table name                                                                                                                                                                | `label_register` |
| `jsonRegister.existingSecret`            | Name of an existing secret containing the label register password (preferred over jsonRegister.password for security)                                                                    | `""`             |
| `jsonRegister.existingSecretPasswordKey` | Key within jsonRegister.existingSecret holding the password                                                                                                                              | `password`       |
| `jsonRegister.password`                  | Label register password (ignored if jsonRegister.existingSecret is set) - prefer existingSecret in any real environment                                                                  | `""`             |
| `jsonRegister.tlsEnabled`                | Connect to the label register over TLS. Required by the platform's RDS; json-register's own default is plain TCP, which RDS rejects                                                      | `false`          |
| `jsonRegister.caSecretName`              | Name of an EXISTING Secret holding the CA chain that signs the register database's certificate (AWS RDS: the platform-managed rds-ca-bundle). Empty = the container's system trust store | `""`             |
| `jsonRegister.caSecretKey`               | Key within that secret holding the PEM chain                                                                                                                                             | `ca.crt`         |

### Delta Table Storage Parameters

The person Delta table volume. WRITE access for this projector; the
entity-resolution-api and batch matcher READ the same table - single-
writer(projector)/many-reader is the contract, so the volume defaults to
a multi-reader-capable (RWX / object-store-backed) class. For object
storage, set persistence.enabled: false, point
configuration.personTablePath at the s3://.. or az://container/path URI,
and supply the store's settings via extraEnv: AWS_* for S3 (IRSA needs
none), AZURE_STORAGE_ACCOUNT_NAME plus optionally AZURE_STORAGE_ACCOUNT_KEY
for Azure Blob (unset key = workload identity). deltalake reads them
directly; the entity-resolution-api reads the same names.

| Name                           | Description                                                                                              | Value           |
| ------------------------------ | -------------------------------------------------------------------------------------------------------- | --------------- |
| `persistence.enabled`          | Mount a PersistentVolumeClaim for the Delta table storage                                                | `true`          |
| `persistence.existingClaim`    | Name of an existing PVC to use (leave empty to let the chart create one)                                 | `""`            |
| `persistence.storageClassName` | StorageClass to request - MUST support ReadWriteMany (ABAC readers share this table)                     | `""`            |
| `persistence.accessMode`       | Access mode for the created PVC                                                                          | `ReadWriteMany` |
| `persistence.size`             | Size to request for the created PVC                                                                      | `10Gi`          |
| `persistence.mountPath`        | Mount path inside the container - configuration.personTablePath must live under this path                | `/data/er`      |
| `extraEnv`                     | Extra environment variables (e.g. AWS/object-store creds, OTEL_EXPORTER_OTLP_ENDPOINT, BATCH_TIMEOUT_MS) | `[]`            |
