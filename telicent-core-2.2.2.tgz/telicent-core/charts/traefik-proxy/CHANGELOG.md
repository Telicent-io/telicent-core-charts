# Changelog

## [0.1.5](https://github.com/Telicent-io/telicent-traefik/compare/v0.1.4...v0.1.5) (2026-10-02)


### Features

* adds status UI ([b4374c3](https://github.com/Telicent-io/telicent-traefik/commit/b4374c325f146b1c60846434419b6423c6da4e11))
* adds status UI ([372a0a7](https://github.com/Telicent-io/telicent-traefik/commit/372a0a7c25b80df1767119da36ee97100ed9cd5a))
* allow extra Traefik routes to be supplied via values ([0afca0f](https://github.com/Telicent-io/telicent-traefik/commit/0afca0f91ac93825c20e190c01c534d132a4f877))
* allow extra Traefik routes to be supplied via values ([a632b3f](https://github.com/Telicent-io/telicent-traefik/commit/a632b3f23e9797f20632a52debeaf782b3253c2b))
* **routes:** entity-resolution API at api.&lt;domain&gt;/er ([9d6dadc](https://github.com/Telicent-io/telicent-traefik/commit/9d6dadc7c6a1af9b4dfcb01659b5b89598391ab0))
* **routes:** entity-resolution API at api.&lt;domain&gt;/er ([d2c8250](https://github.com/Telicent-io/telicent-traefik/commit/d2c82506f5a96e29f9f48bc15c3b4b665b834f91))


### Bug Fixes

* **routes:** hostsPreview.erApi is the bare service name, er-api:8080 ([aca732c](https://github.com/Telicent-io/telicent-traefik/commit/aca732c36df78f8088ca97ed250c9aad23e53ff2))
* **routes:** hostsPreview.erApi is the chart name, smart-cache-er-api:8080 (review) ([0caecf1](https://github.com/Telicent-io/telicent-traefik/commit/0caecf1cf870e79ce18261c97d77d0fa705a83b3))
* split data config routes ([82bd57c](https://github.com/Telicent-io/telicent-traefik/commit/82bd57c04b577fa12888bc8bb6622cc1e798146b))
* split data config routes ([c5ec9e2](https://github.com/Telicent-io/telicent-traefik/commit/c5ec9e24f198df61e768cb74425149cbb0631451))
* update status entrypoint ([#14](https://github.com/Telicent-io/telicent-traefik/issues/14)) ([45f347b](https://github.com/Telicent-io/telicent-traefik/commit/45f347b62419749252db92b9fe107df8622d9d7d))

## [0.1.4](https://github.com/Telicent-io/telicent-traefik/compare/v0.1.3...v0.1.4) (2026-09-02)


### Features

* route data-config-app at /config on the app host ([bd16e2d](https://github.com/Telicent-io/telicent-traefik/commit/bd16e2dbdde4656173edd1ba0f08da29485f9fb3))
* route data-config-app at /config on the app host ([98e6612](https://github.com/Telicent-io/telicent-traefik/commit/98e66127ffa4df178e2f618a84d476b3312b7061))


### Bug Fixes

* oauth2 on the data-config-app route, and move it off /config ([8ccab74](https://github.com/Telicent-io/telicent-traefik/commit/8ccab74ace75742ae72d24294e864b5b50b83a93))

## [0.1.3](https://github.com/Telicent-io/telicent-traefik/compare/v0.1.2...v0.1.3) (2026-08-27)


### Miscellaneous Chores

* release 0.1.3 ([7315f25](https://github.com/Telicent-io/telicent-traefik/commit/7315f25fcbeed5a16f665f60dcbf5af6cb940cea))

## [0.1.2](https://github.com/Telicent-io/telicent-traefik/compare/v0.1.1...v0.1.2) (2026-08-27)


### Features

* initial traefik deployment ([a01e708](https://github.com/Telicent-io/telicent-traefik/commit/a01e70880bda44da0ec5ed3ff6c7f925b129796d))
