{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Returns the version
*/}}
{{- define "ies-regions-ontology-producer.version" -}}
{{- .Values.image.tag | default .Chart.AppVersion }}
{{- end -}}

{{/*
Returns the image registry
*/}}
{{- define "ies-regions-ontology-producer.imageRegistry" -}}
{{- .Values.image.registry }}
{{- end -}}

{{/*
Returns the image 
*/}}
{{- define "ies-regions-ontology-producer.image" -}}
{{- printf "%s/%s:%s" (include "ies-regions-ontology-producer.imageRegistry" .) .Values.image.repository  (include "ies-regions-ontology-producer.version" .) }}
{{- end -}}