{{/*
Expand the name of the chart.
*/}}
{{- define "canonicals-ontology-mapper.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "canonicals-ontology-mapper.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "canonicals-ontology-mapper.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "canonicals-ontology-mapper.labels" -}}
helm.sh/chart: {{ include "canonicals-ontology-mapper.chart" . }}
{{ include "canonicals-ontology-mapper.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
telicent.io/type: mapper
telicent.io/component-of: canonicals-ontology
{{- end }}

{{/*
Selector labels
*/}}
{{- define "canonicals-ontology-mapper.selectorLabels" -}}
app.kubernetes.io/name: {{ include "canonicals-ontology-mapper.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}


{{- define "canonicals-ontology-mapper.kafkaAuthConfigSecretName" }}
{{- if .Values.global.kafka.existingConfigSecretName }}
{{- .Values.global.kafka.existingConfigSecretName }}
{{- else }}
{{- include "canonicals-ontology-mapper.fullname" . }}-kafka-config
{{- end }}
{{- end }}
