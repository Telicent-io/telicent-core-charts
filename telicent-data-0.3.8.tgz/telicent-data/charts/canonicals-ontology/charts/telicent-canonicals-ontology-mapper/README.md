# Canonicals Ontology Mapper

## Parameters

### Global Parameters

Contains global parameters. Not explicitly used in this chart, added to maintain consistency across Telicent charts.
These parameters can be referenced in sub-charts as `.Values.global.<parameter-name>`.

| Name                             | Description                                                                       | Value                                            |
| -------------------------------- | --------------------------------------------------------------------------------- | ------------------------------------------------ |
| `global.imageRegistry`           | Global image registry                                                             | `""`                                             |
| `global.imagePullSecrets`        | Global registry secret names as an array                                          | `[]`                                             |
| `global.enterprise`              | Enable enterprise mode, adding additional features and configurations             | `false`                                          |
| `global.appHostDomain`           | Domain associated with Telicent application services                              | `apps.telicent.io`                               |
| `global.authHostDomain`          | Domain associated with Telicent authentication services, including OIDC providers | `auth.telicent.io`                               |
| `global.groupsClaim`             | Key used to retrieve groups from the OIDC provider                                | `groups`                                         |
| `global.jwksUrl`                 | Endpoint exposing multiple public keys represented as JWKs (JSON Web Key Set)     | `https://{yourAuthdomain}/.well-known/jwks.json` |
| `global.istioNamespace`          | Namespace in which Istio is deployed                                              | `istio-system`                                   |
| `global.istioServiceAccountName` | Name of the Istio service account                                                 | `istio-ingress`                                  |
| `global.istioGatewayName`        | Name of the Istio Gateway Resource (LB operating at the edge of the mesh)         | `ingress-gateway`                                |

### Kafka Parameters

| Name                                    | Description                                                                                                       | Value                                          |
| --------------------------------------- | ----------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| `global.kafka.bootstrapServers`         | Comma separated list containing Kafka bootstrap servers                                                           | `kafka-bootstrap.kafka.svc.cluster.local:9092` |
| `global.kafka.existingConfigSecretName` | Name of an existing secret containing Kafka configuration (preferred over individual settings below for security) | `""`                                           |
| `global.kafka.username`                 | Username for Kafka authentication                                                                                 | `""`                                           |
| `global.kafka.password`                 | Password for Kafka authentication                                                                                 | `""`                                           |
| `global.kafka.protocol`                 | Protocol used for Kafka communication                                                                             | `SASL_SSL`                                     |
| `global.kafka.mechanism`                | SASL mechanism used for Kafka authentication                                                                      | `SCRAM-SHA-512`                                |

### truststore Parameters

| Name                               | Description                                          | Value                    |
| ---------------------------------- | ---------------------------------------------------- | ------------------------ |
| `global.truststore.existingSecret` | Name of an existing secret containing the truststore | `""`                     |
| `global.truststore.mountPath`      | The mount path for the truststore in the container   | `/app/config/truststore` |

### Image Parameters

| Name                | Description                                                              | Value                                          |
| ------------------- | ------------------------------------------------------------------------ | ---------------------------------------------- |
| `image.registry`    | Container image registry                                                 | `quay.io`                                      |
| `image.repository`  | Container image name                                                     | `telicent/telicent-canonicals-ontology-mapper` |
| `image.tag`         | Container image tag. If not set, a tag is generated using the appVersion | `""`                                           |
| `image.pullPolicy`  | Container image pull policy                                              | `IfNotPresent`                                 |
| `image.pullSecrets` | Specify registry secret names as an array                                | `[]`                                           |

### Common Parameters

| Name               | Description                                                            | Value |
| ------------------ | ---------------------------------------------------------------------- | ----- |
| `nameOverride`     | String to partially override fullname (will maintain the release name) | `""`  |
| `fullnameOverride` | String to fully override the generated release name                    | `""`  |

### Pod Parameters

| Name                 | Description                            | Value |
| -------------------- | -------------------------------------- | ----- |
| `podAnnotations`     | Additional custom annotations for pods | `{}`  |
| `podLabels`          | Additional custom labels for pods      | `{}`  |
| `podSecurityContext` | Set pods' Security Context             | `{}`  |

### Container Parameters

| Name                                       | Description                                                                                               | Value            |
| ------------------------------------------ | --------------------------------------------------------------------------------------------------------- | ---------------- |
| `securityContext.runAsUser`                | The UID to run the entrypoint of the container process                                                    | `185`            |
| `securityContext.runAsGroup`               | The GID to run the entrypoint of the container process                                                    | `185`            |
| `securityContext.runAsNonRoot`             | Indicates that the container must run as a non-root user                                                  | `true`           |
| `securityContext.allowPrivilegeEscalation` | Whether to allow privilege escalation, where the process can gain more privileges than its parent process | `false`          |
| `securityContext.capabilities.drop`        | The capabilities to drop when running containers                                                          | `["ALL"]`        |
| `securityContext.seccompProfile.type`      | Indicates which kind of seccomp profile will be applied                                                   | `RuntimeDefault` |

### Resource Parameters

| Name             | Description                                  | Value |
| ---------------- | -------------------------------------------- | ----- |
| `resources`      | Set containers' resource requests and limits | `{}`  |
| `livenessProbe`  | Set liveness probes for the container        | `{}`  |
| `readinessProbe` | Set readiness probes for the container       | `{}`  |

### Volume Parameters

| Name           | Description                                                 | Value |
| -------------- | ----------------------------------------------------------- | ----- |
| `volumes`      | Additional volumes on the output Deployment definition      | `[]`  |
| `volumeMounts` | Additional volumeMounts on the output Deployment definition | `[]`  |

### Node Selection Parameters

| Name           | Description                     | Value |
| -------------- | ------------------------------- | ----- |
| `nodeSelector` | Node labels for pods assignment | `{}`  |
| `tolerations`  | Tolerations for pods assignment | `[]`  |
| `affinity`     | Affinity for pods assignment    | `{}`  |
| `annotations`  | Annotations for the job         | `{}`  |

### Service Account Parameters

| Name                         | Description                                                                           | Value  |
| ---------------------------- | ------------------------------------------------------------------------------------- | ------ |
| `serviceAccount.create`      | Specifies whether a service account should be created                                 | `true` |
| `serviceAccount.name`        | Name of the ServiceAccount to use. If not set, a name is generated using the fullname | `""`   |
| `serviceAccount.annotations` | Additional custom annotations for the ServiceAccount                                  | `{}`   |
| `serviceAccount.automount`   | Automatically mount a ServiceAccount's API credentials                                | `true` |
