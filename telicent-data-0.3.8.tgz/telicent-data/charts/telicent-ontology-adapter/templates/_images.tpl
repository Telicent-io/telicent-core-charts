{{/*
Copyright (C) 2025 Telicent Limited
*/}}

{{/*
Returns the version
*/}}
{{- define "ontology-adapter.version" -}}
{{- .Values.image.tag | default .Chart.AppVersion }}
{{- end -}}

{{/*
Returns the image registry
*/}}
{{- define "ontology-adapter.imageRegistry" -}}
{{- .Values.image.registry }}
{{- end -}}

{{/*
Returns the image 
*/}}
{{- define "ontology-adapter.image" -}}
{{- printf "%s/%s:%s" (include "ontology-adapter.imageRegistry" .) .Values.image.repository  (include "ontology-adapter.version" .) }}
{{- end -}}
