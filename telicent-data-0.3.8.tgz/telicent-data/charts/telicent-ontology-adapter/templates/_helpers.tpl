{{/*
Expand the name of the chart.
*/}}
{{- define "ontology-adapter.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ontology-adapter.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ontology-adapter.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ontology-adapter.labels" -}}
helm.sh/chart: {{ include "ontology-adapter.chart" . }}
{{ include "ontology-adapter.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
telicent.io/type: adapter
telicent.io/component-of: base-ontologies
{{- end }}

{{/*
Build a colon-separated list of enabled ontology paths inside the container image.
Iterates configuration.ontologies.builtin so new families only require a values.yaml entry.
Always appends /ontologies/custom so user-provided ConfigMap mounts are also scanned.
*/}}
{{- define "ontology-adapter.ontologyPaths" -}}
{{- $paths := list }}
{{- $builtin := .Values.configuration.ontologies.builtin }}
{{- if not $builtin }}
{{- $builtin = list
  (dict "folder" "ies"      "enabled" true "version" "4.3")
  (dict "folder" "telicent" "enabled" true "version" "1.0")
  (dict "folder" "rdf-owl"  "enabled" true "version" "default")
  (dict "folder" "cco-bfo"  "enabled" true "version" "2.0")
  (dict "folder" "catalog"  "enabled" true "version" "default")
}}
{{- end }}
{{- range $entry := $builtin }}
{{- if $entry.enabled }}
{{- $paths = append $paths (printf "/app/ontologies/%s/%s" $entry.folder (toString $entry.version)) }}
{{- end }}
{{- end }}
{{- range $entry := .Values.configuration.ontologies.custom }}
{{- if and $entry.enabled $entry.path }}
{{- $paths = append $paths $entry.path }}
{{- end }}
{{- end }}
{{- $paths = append $paths "/ontologies/custom" }}
{{- join ";" $paths }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ontology-adapter.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ontology-adapter.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
