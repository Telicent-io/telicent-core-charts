# Ontology Adapter

## Parameters

### Global Parameters

Contains global parameters shared across charts, including either Kafka connection parameters or a reference to an existing Kubernetes secret containing the necessary Kafka configuration. See [Telicent - Kafka Auth](https://docs.telicent.io/core/getting-started/installation/helm/secrets-management/kafka-auth.html) for more details.

| Name                                    | Description                                                                                                                              | Value                                          |
| --------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| `global.kafka.bootstrapServers`         | Comma separated list containing Kafka bootstrap servers. Not required for Kafka authentication if `existingConfigSecretName` is provided | `kafka-bootstrap.kafka.svc.cluster.local:9092` |
| `global.kafka.existingConfigSecretName` | Name of an existing secret containing Kafka configuration (preferred over individual settings below for security)                        | `""`                                           |
| `global.kafka.username`                 | Username for Kafka authentication                                                                                                        | `""`                                           |
| `global.kafka.password`                 | Password for Kafka authentication                                                                                                        | `""`                                           |
| `global.kafka.protocol`                 | Protocol used for Kafka communication                                                                                                    | `SASL_SSL`                                     |
| `global.kafka.mechanism`                | SASL mechanism used for Kafka authentication                                                                                             | `SCRAM-SHA-512`                                |

### Image Parameters

| Name                | Description                                                              | Value                                |
| ------------------- | ------------------------------------------------------------------------ | ------------------------------------ |
| `image.registry`    | Container image registry                                                 | `quay.io`                            |
| `image.repository`  | Container image name                                                     | `telicent/telicent-ontology-adapter` |
| `image.tag`         | Container image tag. If not set, a tag is generated using the appVersion | `""`                                 |
| `image.pullPolicy`  | Container image pull policy                                              | `IfNotPresent`                       |
| `image.pullSecrets` | Specify registry secret names as an array                                | `[]`                                 |

### Job Parameters

| Name                          | Description                                                          | Value |
| ----------------------------- | -------------------------------------------------------------------- | ----- |
| `job.activeDeadlineSeconds`   | Maximum time in seconds a job can run                                | `360` |
| `job.backoffLimit`            | Number of retries before marking this job as failed                  | `3`   |
| `job.completions`             | Number of successful completions before marking this job as complete | `1`   |
| `job.parallelism`             | Maximum number of pods that can run in parallel                      | `1`   |
| `job.ttlSecondsAfterFinished` | Time to live (in seconds) for finished jobs before automatic cleanup | `0`   |

### Name Parameters

| Name               | Description                                                            | Value |
| ------------------ | ---------------------------------------------------------------------- | ----- |
| `nameOverride`     | String to partially override fullname (will maintain the release name) | `""`  |
| `fullnameOverride` | String to fully override the generated release name                    | `""`  |

### Pod Parameters

| Name                 | Description                            | Value |
| -------------------- | -------------------------------------- | ----- |
| `podAnnotations`     | Additional custom annotations for pods | `{}`  |
| `podLabels`          | Additional custom labels for pods      | `{}`  |
| `podSecurityContext` | Set pods' Security Context             | `{}`  |

### Container Parameters

| Name                                       | Description                                                                                               | Value            |
| ------------------------------------------ | --------------------------------------------------------------------------------------------------------- | ---------------- |
| `securityContext.runAsUser`                | The UID to run the entrypoint of the container process                                                    | `185`            |
| `securityContext.runAsGroup`               | The GID to run the entrypoint of the container process                                                    | `185`            |
| `securityContext.runAsNonRoot`             | Indicates that the container must run as a non-root user                                                  | `true`           |
| `securityContext.allowPrivilegeEscalation` | Whether to allow privilege escalation, where the process can gain more privileges than its parent process | `false`          |
| `securityContext.capabilities.drop`        | The capabilities to drop when running containers                                                          | `["ALL"]`        |
| `securityContext.seccompProfile.type`      | Indicates which kind of seccomp profile will be applied                                                   | `RuntimeDefault` |
| `resources`                                | Resources for workload containers                                                                         | `{}`             |
| `livenessProbe`                            | Set liveness probes for the container                                                                     | `{}`             |
| `readinessProbe`                           | Set readiness probes for the container                                                                    | `{}`             |

### Volume Parameters

| Name           | Description                                                 | Value |
| -------------- | ----------------------------------------------------------- | ----- |
| `volumes`      | Additional volumes on the output Deployment definition      | `[]`  |
| `volumeMounts` | Additional volumeMounts on the output Deployment definition | `[]`  |

### Node Selection Parameters

| Name           | Description                     | Value |
| -------------- | ------------------------------- | ----- |
| `nodeSelector` | Node labels for pods assignment | `{}`  |
| `tolerations`  | Tolerations for pods assignment | `[]`  |
| `affinity`     | Affinity for pods assignment    | `{}`  |
| `annotations`  | Annotations for the job         | `{}`  |

### Configuration Parameters

Contains configuration parameters specific to the application

| Name                               | Description                                                                | Value      |
| ---------------------------------- | -------------------------------------------------------------------------- | ---------- |
| `configuration.targetTopic`        | The target topic for the styles and ontologies (usually 'ontology')        | `ontology` |
| `configuration.ontologies.builtin` | array List of built-in ontology families to load from the container image. | `[]`       |
| `configuration.ontologies.custom`  | array List of user-provided ontologies to add alongside the built-ins.     | `[]`       |
