{{/*
Copyright (C) 2025 Telicent Limited
*/}}

{{/*
Returns the version
*/}}
{{- define "region-resolver-mapper.version" -}}
{{- .Values.image.tag | default .Chart.AppVersion }}
{{- end -}}

{{/*
Returns the image registry
*/}}
{{- define "region-resolver-mapper.imageRegistry" -}}
{{- .Values.image.registry }}
{{- end -}}

{{/*
Returns the image 
*/}}
{{- define "region-resolver-mapper.image" -}}
{{- printf "%s/%s:%s" (include "region-resolver-mapper.imageRegistry" .) .Values.image.repository  (include "region-resolver-mapper.version" .) }}
{{- end -}}
