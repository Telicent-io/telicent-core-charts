{{/*
Expand the name of the chart.
*/}}
{{- define "region-resolver-mapper.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "region-resolver-mapper.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "region-resolver-mapper.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "region-resolver-mapper.labels" -}}
helm.sh/chart: {{ include "region-resolver-mapper.chart" . }}
{{ include "region-resolver-mapper.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
telicent.io/type: mapper
telicent.io/component-of: canonical-events
{{- end }}

{{/*
Selector labels
*/}}
{{- define "region-resolver-mapper.selectorLabels" -}}
app.kubernetes.io/name: {{ include "region-resolver-mapper.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}


{{- define "region-resolver-mapper.kafkaAuthConfigSecretName" }}
{{- if .Values.global.kafka.existingConfigSecretName }}
{{- .Values.global.kafka.existingConfigSecretName }}
{{- else }}
{{- include "region-resolver-mapper.fullname" . }}-kafka-config
{{- end }}
{{- end }}
