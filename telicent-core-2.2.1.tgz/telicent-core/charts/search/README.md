# Telicent Package for Search

**Search** provides search capabilities and exposes endpoints for querying indexed data.

## Introduction

This chart bootstraps Search deployment on a [Kubernetes](https://kubernetes.io) cluster using
the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.23+
- Helm 3.9+

## Installing the Chart

To install the chart with the release name `my-release`:

```console
helm install my-release ./charts/telicent-core/charts/search
```

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```console
helm delete my-release
```
The command removes all the Kubernetes components associated with the chart and deletes the release.

## Automating README and schema generation

To obtain the latest version of the generator script run:
```shell
.dev/metadata-updater.sh
```
Then run the following from the project root directory:
```bash
.dev/readme-generator-for-helm --config=charts/search/readme.config \
 --values=charts/search/values.yaml \
 --readme=charts/search/README.md \
 --schema=charts/search/values.schema.json
```

## Configuration and installation details

### Resource requests and limits

These are inside the `resources` value (check parameter table). Setting requests is essential for production workloads
and these should be adapted to your specific use case.

### Sidecars and Init Containers

If you have a need for additional containers to run within the same pod (e.g. an additional metrics or logging
exporter), you can do so via the `sidecars` config parameter.
Define your container according to the Kubernetes container spec.

```yaml
sidecars:
- name: your-image-name
  image: your-image
  imagePullPolicy: Always
  ports:
  - name: portname
    containerPort: 1234
```

Similarly, you can add extra init containers using the `initContainers` parameter.

```yaml
initContainers:
- name: your-image-name
  image: your-image
  imagePullPolicy: Always
  ports:
  - name: portname
    containerPort: 1234
```

### Setting Pod's affinity

This chart allows you to set your custom affinity using the `affinity` parameter.
Find more information about Pod's affinity in
the [kubernetes documentation](https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity).

### Distribution Lifecycle Management

Distribution Lifecycle Management is turned on with a single flag:

```yaml
distributionLifecycle:
  routeToNamedGraphs: true
```

This sets `ROUTE_TO_NAMED_GRAPHS=true`, `DISTRIBUTION_LIFECYCLE_ENABLED=true` and points
`DISTRIBUTION_LIFECYCLE_STATE_FILE` at a file on a persistent volume, provisioned by this chart as a
`PersistentVolumeClaim` named `<fullname>-lifecycle-state`. Provide your own volume instead with
`distributionLifecycle.persistence.existingClaim`.

The lifecycle state file only supports a single writer, which has two consequences:

- The **Search** and **Search Projector** charts must each be given their own volume. The claims created by the two
  charts are named after their respective releases so they are distinct by default; if you set `existingClaim`, make
  sure you do not point both services at the same claim.
- Because the state store code is not designed to handle multiple processes sharing the same state file, only one
  replica is supported while the feature is enabled. The chart fails to render if `replicas` is greater
  than 1, and switches the deployment strategy to `Recreate` so that the outgoing pod releases the state file before
  the incoming pod starts.

## Parameters

### Global Parameters

Contains global parameters; these parameters are mirrored within the Telicent core umbrella chart
Note: Only global parameters used within this chart will be listed below

| Name                                    | Description                                                                                                                     | Value                                          |
| --------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| `global.imageRegistry`                  | Global image registry                                                                                                           | `""`                                           |
| `global.imagePullSecrets`               | Global registry secret names as an array                                                                                        | `[]`                                           |
| `global.enterprise`                     | Enable enterprise mode, adding additional features and configurations                                                           | `false`                                        |
| `global.appHostDomain`                  | Domain associated with Telicent application/ui services. This value cannot be changed after it is set                           | `""`                                           |
| `global.apiHostDomain`                  | Domain associated with Telicent Api services. This value cannot be changed after it is set                                      | `""`                                           |
| `global.authHostDomain`                 | Domain associated with Telicent authentication services, including OIDC providers. This value cannot be changed after it is set | `""`                                           |
| `global.kafka.bootstrapServers`         | Comma separated list containing Kafka bootstrap servers                                                                         | `kafka-bootstrap.kafka.svc.cluster.local:9092` |
| `global.kafka.existingConfigSecretName` | Name of an existing secret containing Kafka configuration                                                                       | `""`                                           |
| `global.kafka.username`                 | Username for Kafka authentication                                                                                               | `your.kafka.username.here`                     |
| `global.kafka.password`                 | Password for Kafka authentication                                                                                               | `your.kafka.password.here`                     |
| `global.kafka.protocol`                 | Protocol used for Kafka communication                                                                                           | `SASL_SSL`                                     |
| `global.kafka.mechanism`                | SASL mechanism used for Kafka authentication                                                                                    | `SCRAM-SHA-512`                                |
| `global.truststore.existingSecret`      | Name of an existing secret containing the truststore                                                                            | `""`                                           |
| `global.truststore.mountPath`           | The mount path for the truststore in the container                                                                              | `/app/config/truststore`                       |

### Application Parameters - Java

Contains Java configuration parameters to be used by the *Search* application

| Name                  | Description                                                                | Value                       |
| --------------------- | -------------------------------------------------------------------------- | --------------------------- |
| `java.jvmOptions`     | JVM options for the application                                            | `-XX:MaxRAMPercentage=80.0` |
| `java.mallocArenaMax` | glibc malloc arena cap used to limit native memory fragmentation/retention | `2`                         |

### Application Parameters - Elastic/OpenSearch and Secret

The following contains connection details to an Elastic/OpenSearch service, on which the application relies.
It is recommended to store sensitive information including passwords in a Kubernetes secret and not in Helm values.
For Quick Start purposes, a secret named `tc-auth-usr-elastic-search` will be created if one is not set.

| Name                                   | Description                                                                                         | Value                          |
| -------------------------------------- | --------------------------------------------------------------------------------------------------- | ------------------------------ |
| `elastic.host`                         | Elastic/OpenSearch host                                                                             | `https://your.opensearch.host` |
| `elastic.port`                         | Elastic/OpenSearch port number                                                                      | `443`                          |
| `elastic.opensearchCompatibility`      | Enable OpenSearch compatibility                                                                     | `true`                         |
| `elastic.index`                        | Elastic/OpenSearch index to be used                                                                 | `search,doc-content`           |
| `elastic.partsIndices`                 | Elastic/OpenSearch indices to be used by the /parts endpoint                                        | `search`                       |
| `elastic.labelsIndex`                  | Elastic/OpenSearch index to store security labels.                                                  | `labels`                       |
| `elastic.searchFieldOptions`           | Field options for search                                                                            | `primaryName^2,*`              |
| `elastic.indexBatchSize`               | Number of documents to index in a single batch operation                                            | `100`                          |
| `elastic.actionsTopic`                 | Topic used to synchronise actions between the *Search Projector* and the *Search API* applications. | `actions`                      |
| `elastic.writeBackAttributeExpression` | Attribute expression which is evaluated to ascertain access to write-back endpoints                 | `!`                            |
| `elastic.existingSecret`               | Name of an existing secret. The secret must contain 2 keys: 'username', 'password'                  | `""`                           |
| `elastic.username`                     | OpenSearch/Elastic username                                                                         | `""`                           |
| `elastic.password`                     | OpenSearch/Elastic user password                                                                    | `""`                           |

### Application Parameters - Distribution Lifecycle Management

Distribution Lifecycle Management routes data into named graphs keyed by the distribution URI and reacts to
distribution lifecycle events, for example excluding documents belonging to a deleted distribution.
It is disabled by default; the surrounding ecosystem that emits distribution lifecycle events must be in place
before enabling it.
When enabled the application persists its lifecycle tracking state to a file, which requires a persistent volume.
The state file is not designed to be shared between processes, so the *Search API* and the *Search Projector* MUST
each be given their own volume. For the same reason only a single replica is supported while this feature is enabled.

| Name                                              | Description                                                                                                             | Value                         |
| ------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- | ----------------------------- |
| `distributionLifecycle.routeToNamedGraphs`        | Enable Distribution Lifecycle Management                                                                                | `false`                       |
| `distributionLifecycle.stateFileName`             | Name of the file used to persist lifecycle tracking state, created within 'distributionLifecycle.persistence.mountPath' | `distribution-lifecycle.json` |
| `distributionLifecycle.persistence.existingClaim` | Name of an existing PersistentVolumeClaim used to store the lifecycle state file                                        | `""`                          |
| `distributionLifecycle.persistence.storageClass`  | Storage class of the created PersistentVolumeClaim. Left unset, the cluster default is used                             | `""`                          |
| `distributionLifecycle.persistence.accessModes`   | Access modes of the created PersistentVolumeClaim                                                                       | `["ReadWriteOnce"]`           |
| `distributionLifecycle.persistence.size`          | Size of the created PersistentVolumeClaim                                                                               | `128Mi`                       |
| `distributionLifecycle.persistence.mountPath`     | Path at which the lifecycle state volume is mounted in the container                                                    | `/app/state`                  |
| `distributionLifecycle.persistence.annotations`   | Additional custom annotations for the created PersistentVolumeClaim                                                     | `{}`                          |

### ConfigMap Parameters

Contains configuration parameters specific to the *Search* application

| Name                             | Description                                                              | Value |
| -------------------------------- | ------------------------------------------------------------------------ | ----- |
| `configMap.existingEnvConfigMap` | Name of existing configmap containing *Search* Environment Configuration | `""`  |

### Common Parameters

| Name                | Description                                                            | Value |
| ------------------- | ---------------------------------------------------------------------- | ----- |
| `nameOverride`      | String to partially override fullname (will maintain the release name) | `""`  |
| `fullnameOverride`  | String to fully override the generated release name                    | `""`  |
| `namespaceOverride` | String to fully override all deployed resources namespace              | `""`  |
| `commonLabels`      | Add labels to all the deployed resources                               | `{}`  |

### Deployment Parameters

| Name                   | Description                                                   | Value |
| ---------------------- | ------------------------------------------------------------- | ----- |
| `replicas`             | Number of *Search* replicas to deploy                         | `1`   |
| `revisionHistoryLimit` | Number of controller revisions to keep                        | `5`   |
| `annotations`          | Add extra annotations to the deployment object                | `{}`  |
| `podLabels`            | Add extra labels to the *Search* pod                          | `{}`  |
| `podAnnotations`       | Add extra annotations to the *Search* pod                     | `{}`  |
| `extraEnvVars`         | Array with extra environment variables to add to *Search* pod | `[]`  |
| `extraVolumes`         | Additional containers to be added to the *Search* pod         | `[]`  |
| `extraVolumeMounts`    | Optionally specify extra list of additional volumeMounts      | `[]`  |
| `initContainers`       | Add init containers to the pod                                | `[]`  |
| `sidecars`             | Add sidecars to the pod                                       | `[]`  |

### Deployment Image Parameters

| Name                | Description                                                             | Value                        |
| ------------------- | ----------------------------------------------------------------------- | ---------------------------- |
| `image.registry`    | *Search* image registry                                                 | `quay.io`                    |
| `image.repository`  | *Search* image name                                                     | `telicent/search-api-server` |
| `image.tag`         | *Search* image tag. If not set, a tag is generated using the appVersion | `""`                         |
| `image.pullPolicy`  | *Search* image pull policy                                              | `IfNotPresent`               |
| `image.pullSecrets` | Specify registry secret names as an array                               | `[]`                         |

### Deployment Resources Parameters - Requests and Limits

| Name        | Description                       | Value |
| ----------- | --------------------------------- | ----- |
| `resources` | Resources for *Search* containers | `{}`  |

### Deployment Security Context Parameters - Default Security Context

| Name                                                | Description                                                             | Value            |
| --------------------------------------------------- | ----------------------------------------------------------------------- | ---------------- |
| `podSecurityContext.runAsUser`                      | Set the provisioning pod's Security Context runAsUser User ID           | `185`            |
| `podSecurityContext.runAsGroup`                     | Set the provisioning pod's Security Context runAsGroup Group ID         | `185`            |
| `podSecurityContext.runAsNonRoot`                   | Set the provisioning pod's Security Context runAsNonRoot                | `true`           |
| `podSecurityContext.fsGroup`                        | Set the provisioning pod's Group ID for the mounted volumes' filesystem | `185`            |
| `podSecurityContext.seccompProfile.type`            | Set the provisioning pod's Security Context seccomp profile             | `RuntimeDefault` |
| `containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser User ID                      | `185`            |
| `containerSecurityContext.runAsGroup`               | Set containers' Security Context runAsGroup Group ID                    | `185`            |
| `containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                           | `true`           |
| `containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation               | `false`          |
| `containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                      | `["ALL"]`        |
| `containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                        | `RuntimeDefault` |

### Deployment Affinity Parameters

| Name           | Description                    | Value |
| -------------- | ------------------------------ | ----- |
| `affinity`     | Affinity for pod assignment    | `{}`  |
| `nodeSelector` | Node labels for pod assignment | `{}`  |
| `tolerations`  | Tolerations for pod assignment | `[]`  |

### Service Account Parameters

| Name                         | Description                                                                           | Value  |
| ---------------------------- | ------------------------------------------------------------------------------------- | ------ |
| `serviceAccount.create`      | Specifies whether a service account should be created                                 | `true` |
| `serviceAccount.name`        | Name of the ServiceAccount to use. If not set, a name is generated using the fullname | `""`   |
| `serviceAccount.annotations` | Additional custom annotations for the ServiceAccount                                  | `{}`   |
| `serviceAccount.automount`   | Automatically mount a ServiceAccount's API credentials                                | `true` |

### Traffic Exposure Parameters

| Name           | Description                                                               | Value       |
| -------------- | ------------------------------------------------------------------------- | ----------- |
| `service.name` | *Search* service name. If not set, a name is generated using the fullname | `""`        |
| `service.port` | *Search* service port                                                     | `8080`      |
| `service.type` | *Search* service port                                                     | `ClusterIP` |

### Metrics (Prometheus) Exposure Parameters

| Name                   | Description                     | Value     |
| ---------------------- | ------------------------------- | --------- |
| `metrics.enabled`      | Enable Prometheus metrics       | `true`    |
| `metrics.service.name` | Name for the Prometheus service | `metrics` |
| `metrics.service.port` | Port for the Prometheus service | `9464`    |

### Host(s) Parameters - Contains host information for applications deployed via *telicent-core* chart.

*Search* interacts directly with other Telicent Applications using their default service/serviceAccount and port.
If either of those details changes, you can use this section to correctly refer to those apps.

| Name                      | Description                                                                                                                                                                                                                          | Value                |
| ------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------- |
| `hosts.enableAutoCorrect` | Allow for the release name to be automatically pre-fixed to each host value when required (default behavior when installing through the parent chart). Alternatively, the host value will be used as it is, without any modification | `true`               |
| `hosts.auth`              | Auth application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                                     | `auth:8080`          |
| `hosts.traefikProxy`      | Traefik Proxy application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                            | `traefik-proxy:8080` |
| `hosts.graph`             | Graph application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                                    | `graph:8080`         |

## License

Copyright &copy; 2026 Telicent Limited
