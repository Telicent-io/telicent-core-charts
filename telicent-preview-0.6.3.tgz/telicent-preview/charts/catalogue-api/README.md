# catalogue-api

A read-write API for DCAT catalog metadata (Argus Catalogue API).

This chart deploys the Catalogue API into an existing cluster. It expects an
external triplestore (SPARQL endpoint) and a Telicent auth server.

## Installing

```bash
helm install catalogue-api ./charts/catalogue-api \
  --set triplestore.url=https://triplestore.example.com
```

## Parameters

### Global parameters

| Name                      | Description                                                                                                                                                                                                                          | Value                |
| ------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------- |
| `global.imageRegistry`    | Global image registry override for umbrella charts                                                                                                                                                                                   | `""`                 |
| `global.imagePullSecrets` | Global image pull secrets override for umbrella charts                                                                                                                                                                               | `[]`                 |
| `global.appHostDomain`    | Domain associated with Telicent application/ui services. This value cannot be changed after it is set                                                                                                                                | `""`                 |
| `global.apiHostDomain`    | Domain associated with Telicent Api services. This value cannot be changed after it is set                                                                                                                                           | `""`                 |
| `global.authHostDomain`   | Domain associated with Telicent authentication services, including OIDC providers. This value cannot be changed after it is set                                                                                                      | `""`                 |
| `global.enabled`          | Enable the Catalogue API deployment                                                                                                                                                                                                  | `false`              |
| `hosts.enableAutoCorrect` | Allow for the release name to be automatically pre-fixed to each host value when required (default behavior when installing through the parent chart). Alternatively, the host value will be used as it is, without any modification | `true`               |
| `hosts.auth`              | Auth application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                                     | `auth:8080`          |
| `hosts.traefikProxy`      | Traefik Proxy application default host value, as defined by 'service/serviceAccount:port'                                                                                                                                            | `traefik-proxy:8080` |

### Image

| Name                | Description                                                  | Value                    |
| ------------------- | ------------------------------------------------------------ | ------------------------ |
| `image.registry`    | Container image registry                                     | `quay.io`                |
| `image.repository`  | Container image repository                                   | `telicent/catalogue-api` |
| `image.tag`         | Container image tag (defaults to Chart.appVersion)           | `""`                     |
| `image.digest`      | Image digest (sha256:…) — takes precedence over tag when set | `""`                     |
| `image.pullPolicy`  | Image pull policy                                            | `IfNotPresent`           |
| `image.pullSecrets` | Image pull secrets (merged with global.imagePullSecrets)     | `[]`                     |

### Replicas

| Name       | Description                                                       | Value |
| ---------- | ----------------------------------------------------------------- | ----- |
| `replicas` | Number of API replicas (ignored when autoscaling.enabled is true) | `1`   |

### API

| Name                       | Description                                                                                                                                                                | Value           |
| -------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------- |
| `api.logLevel`             | Python logging level for the API                                                                                                                                           | `INFO`          |
| `api.rootPath`             | Root path prefix when behind a proxy/ingress (sets API_ROOT_PATH, e.g. /catalogue)                                                                                         | `/catalogue`    |
| `api.openapiPath`          | Path served for the OpenAPI schema (sets API_OPENAPI_PATH)                                                                                                                 | `/openapi.json` |
| `api.disableDocs`          | Disable the Swagger UI (/docs) and OpenAPI schema routes in the ingress policy                                                                                             | `false`         |
| `api.corsAllowOrigins`     | Comma-separated list of allowed CORS origins; empty allows all ("*")                                                                                                       | `""`            |
| `api.sharedSecurityLabel`  | Security label for shared-entity writes: owner, publisher, contact, rights, contributor (sets CATALOG_SHARED_SECURITY_LABEL). "*" is permissive — override per deployment. | `*`             |
| `api.defaultSecurityLabel` | Security label for a dataset write when securityLabel is absent from the request (sets CATALOG_DEFAULT_SECURITY_LABEL). "*" is permissive — override per deployment.       | `*`             |

### Triplestore (SPARQL)

| Name                         | Description                                                     | Value                   |
| ---------------------------- | --------------------------------------------------------------- | ----------------------- |
| `triplestore.url`            | SPARQL endpoint base URL (sets SPARQL_URL)                      | `http://localhost:3030` |
| `triplestore.username`       | SPARQL DIGEST auth username (ignored if existingSecret is set)  | `""`                    |
| `triplestore.password`       | SPARQL DIGEST auth password (ignored if existingSecret is set)  | `""`                    |
| `triplestore.existingSecret` | Name of an existing secret with SPARQL_USER and SPARQL_PWD keys | `""`                    |

### Auth Server (telicent-core-extensions)

| Name                | Description                                                    | Value           |
| ------------------- | -------------------------------------------------------------- | --------------- |
| `auth.allowHttp`    | Allow HTTP (non-TLS) connections to auth-server                | `true`          |
| `auth.jwtIssuer`    | Expected JWT issuer claim                                      | `""`            |
| `auth.jwtAudience`  | Expected JWT audience claim                                    | `telicent_core` |
| `auth.jwtAlgorithm` | JWT signing algorithm (leave empty for default RS256)          | `RS256`         |
| `auth.jwtHeader`    | request header containing the users JWT                        | `Authorization` |
| `auth.jwksUrl`      | JWKS endpoint URL (leave empty to derive from auth-server URL) | `""`            |
| `auth.requiredRole` | Role required in JWT (ADMIN_SYSTEM recommended for this API)   | `""`            |

### Autoscaling

| Name                                         | Description                        | Value   |
| -------------------------------------------- | ---------------------------------- | ------- |
| `autoscaling.enabled`                        | Enable Horizontal Pod Autoscaler   | `false` |
| `autoscaling.minReplicas`                    | Minimum number of replicas         | `2`     |
| `autoscaling.maxReplicas`                    | Maximum number of replicas         | `10`    |
| `autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization for scaling | `70`    |

### Pod Disruption Budget

| Name                               | Description                                           | Value   |
| ---------------------------------- | ----------------------------------------------------- | ------- |
| `podDisruptionBudget.enabled`      | Enable a PodDisruptionBudget (requires replicas >= 2) | `false` |
| `podDisruptionBudget.minAvailable` | Minimum number of available pods during disruption    | `1`     |

### ConfigMap

| Name                             | Description                                                                       | Value |
| -------------------------------- | --------------------------------------------------------------------------------- | ----- |
| `configMap.existingEnvConfigMap` | Name of an existing ConfigMap to use for non-secret env instead of generating one | `""`  |

### Service

| Name                 | Description                                                                                 | Value       |
| -------------------- | ------------------------------------------------------------------------------------------- | ----------- |
| `service.type`       | Kubernetes service type                                                                     | `ClusterIP` |
| `service.port`       | Port the Service exposes (the cluster-facing port)                                          | `8080`      |
| `service.targetPort` | Port the container listens on; must match the port uvicorn binds in the image (EXPOSE 8000) | `8000`      |

### Service Account

| Name                         | Description                                                            | Value   |
| ---------------------------- | ---------------------------------------------------------------------- | ------- |
| `serviceAccount.create`      | Create a ServiceAccount for the workload                               | `true`  |
| `serviceAccount.annotations` | Annotations to add to the ServiceAccount                               | `{}`    |
| `serviceAccount.name`        | ServiceAccount name (generated from the chart name if empty)           | `""`    |
| `serviceAccount.automount`   | Automount the ServiceAccount token (the API does not call the K8s API) | `false` |

### Pod Labels and Annotations

| Name             | Description                       | Value |
| ---------------- | --------------------------------- | ----- |
| `podLabels`      | Extra labels applied to Pods      | `{}`  |
| `podAnnotations` | Extra annotations applied to Pods | `{}`  |

### Probes

| Name                              | Description                                                          | Value        |
| --------------------------------- | -------------------------------------------------------------------- | ------------ |
| `startupProbe.httpGet.path`       | HTTP path probed to detect application startup                       | `/readiness` |
| `startupProbe.httpGet.port`       | Port (name or number) probed to detect application startup           | `http`       |
| `startupProbe.failureThreshold`   | Number of failed startup probes before the container is restarted    | `30`         |
| `startupProbe.periodSeconds`      | How often (in seconds) to perform the startup probe                  | `10`         |
| `readinessProbe.httpGet.path`     | HTTP path probed to determine readiness to serve traffic             | `/readiness` |
| `readinessProbe.httpGet.port`     | Port (name or number) probed to determine readiness                  | `http`       |
| `readinessProbe.periodSeconds`    | How often (in seconds) to perform the readiness probe                | `5`          |
| `readinessProbe.timeoutSeconds`   | Seconds after which the readiness probe times out                    | `5`          |
| `readinessProbe.failureThreshold` | Number of failed readiness probes before the Pod is marked not ready | `6`          |
| `livenessProbe.httpGet.path`      | HTTP path probed to determine container liveness                     | `/liveness`  |
| `livenessProbe.httpGet.port`      | Port (name or number) probed to determine container liveness         | `http`       |
| `livenessProbe.periodSeconds`     | How often (in seconds) to perform the liveness probe                 | `15`         |
| `livenessProbe.timeoutSeconds`    | Seconds after which the liveness probe times out                     | `5`          |
| `livenessProbe.failureThreshold`  | Number of failed liveness probes before the container is restarted   | `3`          |

### Deployment Security Context Parameters - Default Security Context

| Name                                                | Description                                                             | Value            |
| --------------------------------------------------- | ----------------------------------------------------------------------- | ---------------- |
| `podSecurityContext.runAsUser`                      | Set the provisioning pod's Security Context runAsUser User ID           | `185`            |
| `podSecurityContext.runAsGroup`                     | Set the provisioning pod's Security Context runAsGroup Group ID         | `185`            |
| `podSecurityContext.runAsNonRoot`                   | Set the provisioning pod's Security Context runAsNonRoot                | `true`           |
| `podSecurityContext.fsGroup`                        | Set the provisioning pod's Group ID for the mounted volumes' filesystem | `185`            |
| `podSecurityContext.seccompProfile.type`            | Set the provisioning pod's Security Context seccomp profile             | `RuntimeDefault` |
| `containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser User ID                      | `185`            |
| `containerSecurityContext.runAsGroup`               | Set containers' Security Context runAsGroup Group ID                    | `185`            |
| `containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                           | `true`           |
| `containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation               | `false`          |
| `containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                      | `["ALL"]`        |
| `containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                        | `RuntimeDefault` |

### Resource requests/limits

| Name        | Description                                    | Value |
| ----------- | ---------------------------------------------- | ----- |
| `resources` | Resource requests/limits for the API container | `{}`  |

### Scheduling

| Name           | Description                       | Value |
| -------------- | --------------------------------- | ----- |
| `nodeSelector` | Node selector for pod scheduling  | `{}`  |
| `tolerations`  | Tolerations for pod scheduling    | `[]`  |
| `affinity`     | Affinity rules for pod scheduling | `{}`  |

### Extra configuration

| Name                | Description                                            | Value |
| ------------------- | ------------------------------------------------------ | ----- |
| `extraEnvVars`      | Additional environment variables for the API container | `[]`  |
| `extraVolumes`      | Additional volumes                                     | `[]`  |
| `extraVolumeMounts` | Additional volume mounts for the API container         | `[]`  |
| `initContainers`    | Additional init containers                             | `[]`  |
| `sidecars`          | Additional sidecar containers                          | `[]`  |

### Override defaults

| Name                   | Description                            | Value |
| ---------------------- | -------------------------------------- | ----- |
| `nameOverride`         | Override the chart name                | `""`  |
| `fullnameOverride`     | Override the full resource name prefix | `""`  |
| `namespaceOverride`    | Override the target namespace          | `""`  |
| `commonLabels`         | Extra labels applied to every resource | `{}`  |
| `revisionHistoryLimit` | Number of old ReplicaSets to retain    | `5`   |
