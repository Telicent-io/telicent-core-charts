{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Return the API image name.
Supports global.imageRegistry override and image digest pinning.
*/}}
{{- define "catalogue-api.image" -}}
{{- $registry := .Values.image.registry -}}
{{- if .Values.global }}
{{- if .Values.global.imageRegistry }}
{{- $registry = .Values.global.imageRegistry -}}
{{- end }}
{{- end }}
{{- if .Values.image.digest }}
{{- printf "%s/%s@%s" $registry .Values.image.repository .Values.image.digest }}
{{- else }}
{{- printf "%s/%s:%s" $registry .Values.image.repository (.Values.image.tag | default .Chart.AppVersion) }}
{{- end }}
{{- end }}

{{/*
Return merged image pull secrets (global + image, deduplicated).
*/}}
{{- define "catalogue-api.imagePullSecrets" -}}
{{- $global := list }}
{{- if .Values.global }}
{{- $global = .Values.global.imagePullSecrets | default list }}
{{- end }}
{{- $image := .Values.image.pullSecrets | default list }}
{{- $all := concat $global $image | uniq }}
{{- if $all }}
imagePullSecrets:
  {{- range $all }}
  - name: {{ . }}
  {{- end }}
{{- end }}
{{- end }}
