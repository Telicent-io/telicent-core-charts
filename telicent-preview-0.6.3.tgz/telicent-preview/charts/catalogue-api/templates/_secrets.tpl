{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Return the SPARQL credentials secret name.
Uses existingSecret if provided, otherwise generates a tc-prefixed name.
*/}}
{{- define "catalogue-api.sparqlSecretName" -}}
{{- if .Values.triplestore.existingSecret }}
{{- .Values.triplestore.existingSecret }}
{{- else }}
{{- printf "tc-%s-sparql" (include "catalogue-api.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Whether SPARQL credentials should be wired into the API container.
True when either an existing secret is named or a username/password has been
supplied (in which case this chart creates the secret).
*/}}
{{- define "catalogue-api.sparqlAuthEnabled" -}}
{{- if or .Values.triplestore.existingSecret .Values.triplestore.username .Values.triplestore.password -}}
true
{{- end -}}
{{- end }}

{{/*
Return the env configmap name.
Uses existingEnvConfigMap if provided, otherwise generates a tc-prefixed name.
*/}}
{{- define "catalogue-api.envConfigMapName" -}}
{{- if .Values.configMap.existingEnvConfigMap }}
{{- .Values.configMap.existingEnvConfigMap }}
{{- else }}
{{- printf "tc-%s-env" (include "catalogue-api.fullname" .) }}
{{- end }}
{{- end }}
