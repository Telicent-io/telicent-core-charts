{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/*
Returns the principal used for Ingress traffic by the Istio AuthorizationPolicy
*/}}
{{- define "catalogue-api.ingressPrincipal" -}}
{{- printf "cluster.local/ns/%s/sa/%s" .Release.Namespace ( include "catalogue-api.serviceAccountTraefikProxy" .) -}}
{{- end -}}