{{/*
Copyright (C) 2026 Telicent Limited
*/}}

{{/* ----------------------------------------------------------------- */}}
{{/* Returns the service/serviceAccount with or without a release name */}}
{{- define "common.discoverService" -}}
{{- $envVal := index . 0 -}}
{{- $serviceVal := index . 1 -}}
{{- $name := default $envVal.Chart.Name $envVal.Values.nameOverride -}}
{{- if or (contains $name $envVal.Release.Name) (eq ($envVal.Values.hosts.enableAutoCorrect) false) -}}
{{- printf "%s" $serviceVal -}}
{{- else -}}
{{- printf "%s-%s" $envVal.Release.Name $serviceVal -}}
{{- end -}}
{{- end -}}

{{/* Returns the *host* ('service:port') */}}
{{- define "common.discoverHost" -}}
{{- $envVal := index . 0 -}}
{{- $hostVal := index . 1 -}}
{{- if $envVal.Values.hosts.enableAutoCorrect -}}
{{- $name := (index (splitList ":" $hostVal) 0 ) -}}
{{- $port := (index (splitList ":" $hostVal) 1 ) -}}
{{- printf "%s.%s:%s" (include "common.discoverService" (list $envVal $name)) $envVal.Release.Namespace $port -}}
{{- else -}}
{{- printf "%s" $hostVal -}}
{{- end -}}
{{- end -}}

{{/* Returns the serviceAccount name */}}
{{- define "common.discoverServiceAccount" -}}
{{- $envVal := index . 0 -}}
{{- $hostVal := index . 1 -}}
{{- $name := (index (splitList ":" $hostVal) 0 ) -}}
{{- if $envVal.Values.hosts.enableAutoCorrect -}}
{{- printf "%s" (include "common.discoverService" (list $envVal $name)) -}}
{{- else -}}
{{- printf "%s" $name -}}
{{- end -}}
{{- end -}}